package com.gayatri.aiassistant.ai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.gayatri.aiassistant.service.AssistAccessibilityService
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * Every phone action the assistant can do. Each function returns a short English sentence that is
 * given back to Gemini, so the assistant can tell the user honestly what happened.
 */
class PhoneActions(private val ctx: Context) {

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun installed(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun run(name: String, a: JSONObject): String = when (name) {
        "make_call" -> makeCall(a.optString("contact"))
        "answer_call" -> answerCall()
        "end_call" -> endCall()
        "send_sms" -> sendSms(a.optString("contact"), a.optString("message"))
        "send_whatsapp" -> sendWhatsApp(a.optString("contact"), a.optString("message"))
        "play_youtube" -> playYoutube(a.optString("query"))
        "set_timer" -> setTimer(a.optInt("seconds", 0), a.optString("label"))
        "set_alarm" -> setAlarm(a.optInt("hour", -1), a.optInt("minute", 0), a.optString("label"))
        "set_volume" -> setVolume(a.optString("direction"), if (a.has("level")) a.optInt("level") else -1)
        "flashlight" -> flashlight(a.optBoolean("on", true))
        "open_app" -> openApp(a.optString("app_name"))
        "open_settings_panel" -> panel(a.optString("kind"))
        "navigate" -> navigate(a.optString("place"))
        "search_web" -> searchWeb(a.optString("query"))
        "set_brightness" -> setBrightness(a.optInt("level", -1))
        else -> "Unknown tool: $name"
    }

    // ---------- contacts ----------

    private fun resolve(c: String): Pair<String, String>? {
        val text = c.trim()
        if (text.isEmpty()) return null
        val digits = text.count { it.isDigit() }
        if (digits >= 5 && text.none { it.isLetter() }) {
            return text to text.filter { it.isDigit() || it == '+' }
        }
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val list = ArrayList<Pair<String, String>>()
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$text%"),
            null
        )
        cur?.use {
            while (it.moveToNext()) {
                list.add((it.getString(0) ?: "") to (it.getString(1) ?: ""))
            }
        }
        return list.firstOrNull { it.first.equals(text, ignoreCase = true) } ?: list.firstOrNull()
    }

    private val notFound =
        "Contact not found (or contacts permission is missing). Retry once with the English spelling of the name, or ask the user for the number."

    // ---------- calls ----------

    @SuppressLint("MissingPermission")
    private fun makeCall(c: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return "Failed: the phone-call permission is not granted."
        val (nm, num) = resolve(c) ?: return notFound
        go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        return "Calling $nm now."
    }

    @SuppressLint("MissingPermission")
    private fun answerCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "Failed: permission to answer calls is not granted."
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        tm.acceptRingingCall()
        return "Answered the ringing call."
    }

    @SuppressLint("MissingPermission")
    private fun endCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "Failed: permission to end calls is not granted."
        if (Build.VERSION.SDK_INT < 28) return "Failed: ending calls needs Android 9 or newer."
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val ok = tm.endCall()
        return if (ok) "Call ended." else "There was no active call to end."
    }

    // ---------- messages ----------

    private fun sendSms(c: String, msg: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return "Failed: the SMS permission is not granted."
        if (msg.isBlank()) return "Failed: the message text is empty."
        val (nm, num) = resolve(c) ?: return notFound
        @Suppress("DEPRECATION")
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
        return "SMS sent to $nm."
    }

    private fun sendWhatsApp(c: String, msg: String): String {
        val (nm, num) = resolve(c) ?: return notFound
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(it) }
            ?: return "Failed: WhatsApp is not installed."
        var d = num.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
        if (d.length == 10) d = "91$d"
        val uri = Uri.parse("https://wa.me/$d?text=" + Uri.encode(msg))
        AssistAccessibilityService.pendingWhatsAppSendUntil = System.currentTimeMillis() + 15000
        go(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
        return if (AssistAccessibilityService.instance != null) {
            "WhatsApp chat with $nm opened and the send button is being pressed automatically."
        } else {
            "WhatsApp chat with $nm opened with the message typed, but the user must press send because accessibility access is off."
        }
    }

    // ---------- media / device ----------

    private fun playYoutube(q: String): String {
        if (q.isBlank()) return "Failed: nothing to search for."
        AssistAccessibilityService.pendingYoutubePlayUntil = System.currentTimeMillis() + 20000
        try {
            go(
                Intent(Intent.ACTION_SEARCH)
                    .setPackage("com.google.android.youtube")
                    .putExtra("query", q)
            )
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        }
        return if (AssistAccessibilityService.instance != null) {
            "YouTube search for '$q' opened and the first video is being played."
        } else {
            "YouTube search for '$q' opened, but the user has to tap a video because accessibility access is off."
        }
    }

    private fun setTimer(seconds: Int, label: String): String {
        if (seconds <= 0) return "Failed: the timer length is missing."
        go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Timer set for $seconds seconds."
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23) return "Failed: the alarm hour is missing."
        go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Alarm set for %02d:%02d.".format(hour, minute)
    }

    private fun setVolume(direction: String, level: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        when {
            level >= 0 -> am.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                (max * level / 100.0).roundToInt().coerceIn(0, max),
                AudioManager.FLAG_SHOW_UI
            )
            direction == "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            direction == "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            direction == "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            direction == "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
            else -> return "Failed: say whether the volume should go up, down, mute, max, or give a level from 0 to 100."
        }
        return "Media volume is now ${am.getStreamVolume(AudioManager.STREAM_MUSIC)} out of $max."
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Failed: this phone has no flashlight."
        cm.setTorchMode(id, on)
        return if (on) "Flashlight is on." else "Flashlight is off."
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
        val q = name.lowercase().trim()
        if (q.isEmpty()) return "Failed: no app name given."
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "Failed: no app named '$name' was found. Try the English name of the app."
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Failed: that app can't be opened."
        go(launch)
        return "Opened ${match.loadLabel(pm)}."
    }

    private fun panel(kind: String): String {
        val k = kind.lowercase()
        val i = when {
            k.contains("blue") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            k.contains("volume") && Build.VERSION.SDK_INT >= 29 -> Intent(Settings.Panel.ACTION_VOLUME)
            Build.VERSION.SDK_INT >= 29 -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            else -> Intent(Settings.ACTION_WIFI_SETTINGS)
        }
        go(i)
        return "Opened the settings panel. Android does not let apps switch Wi-Fi or Bluetooth on or off by themselves, so the user must tap the toggle."
    }

    private fun setBrightness(level: Int): String {
        if (level !in 0..100) return "Failed: give a brightness level from 0 to 100."
        if (!Settings.System.canWrite(ctx)) {
            go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "Failed: the user must first allow 'Modify system settings' for this app on the screen that just opened, then ask again."
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * level / 100.0).roundToInt().coerceIn(1, 255))
        return "Brightness set to $level percent."
    }

    private fun searchWeb(q: String): String {
        if (q.isBlank()) return "Failed: nothing to search for."
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Opened a Google search for '$q' in the browser."
    }

    private fun navigate(place: String): String {
        if (place.isBlank()) return "Failed: no destination given."
        try {
            go(
                Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
                    .setPackage("com.google.android.apps.maps")
            )
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
        }
        return "Navigation to $place opened."
    }
}
