package com.gayatri.aiassistant.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class GeminiError(
    val userMessage: String,
    val code: Int = 0,
    val retryAfterMs: Long = 0L
) : Exception(userMessage)

/** What the user said (text of the transcript or typed text) and what the assistant answers. */
data class Turn(val role: String, val text: String)

/** One thing the user sent: typed text and/or spoken audio clips (WAV) and/or one camera picture. */
data class UserInput(
    val text: String?,
    val audioWav: List<ByteArray> = emptyList(),
    val imageB64: String? = null
)

data class ChatResult(val heard: String, val reply: String, val ignore: Boolean)

class GeminiClient(private val actions: PhoneActions) {

    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

        /** The one stable chat model. No "latest", no "preview": works smoothly on the free key. */
        const val CHAT_MODEL = "gemini-2.5-flash"

        @Volatile
        private var goodChatModel: String? = null

        /** Voice (text to speech) exists only as preview models; the second one is used only if the first is missing. */
        private val ttsModels = listOf("gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview")

        @Volatile
        private var goodTts: String? = null
    }

    private class Raw(val code: Int, val text: String)

    private fun post(model: String, apiKey: String, body: JSONObject): Raw {
        val c = URL("$BASE$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Raw(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun networkError(e: IOException): GeminiError {
        val why = "${e.javaClass.simpleName}: ${e.message ?: "no details"}"
        val hint = when (e) {
            is UnknownHostException -> "इंटरनेट बंद है या Google तक पहुँच नहीं हो रही।"
            is SocketTimeoutException -> "Google ने समय पर जवाब नहीं दिया (नेट बहुत धीमा है)।"
            is SSLException -> "सुरक्षित कनेक्शन (SSL) नहीं बन पाया। फ़ोन की तारीख़/समय या नेट जाँचिए।"
            else -> "नेटवर्क में दिक्कत आई।"
        }
        return GeminiError("$hint\nअसली कारण: $why")
    }

    /** Turns Google's error answer into a message that says the REAL reason, in Hindi plus Google's own words. */
    private fun describe(model: String, r: Raw): GeminiError {
        var status = ""
        var msg = ""
        try {
            val e = JSONObject(r.text).optJSONObject("error")
            if (e != null) {
                status = e.optString("status")
                msg = e.optString("message")
            }
        } catch (e: Exception) {
        }
        if (msg.isEmpty()) msg = r.text.take(300).ifEmpty { "(Google ने कोई कारण नहीं बताया)" }
        val retryMs = Regex("\"retryDelay\"\\s*:\\s*\"(\\d+(?:\\.\\d+)?)s\"").find(r.text)
            ?.groupValues?.get(1)?.toDoubleOrNull()?.let { (it * 1000).toLong() } ?: 0L
        val daily = r.text.contains("PerDay", ignoreCase = true) || msg.contains("per day", ignoreCase = true)
        val hint = when {
            r.code == 400 && (msg.contains("API key", true) || status == "INVALID_ARGUMENT" && msg.contains("key", true)) ->
                "API key गलत है। Profile में key दोबारा डालिए।"
            r.code == 400 && msg.contains("location", true) ->
                "आपके देश/इलाक़े में यह सुविधा अभी उपलब्ध नहीं है।"
            r.code == 400 -> "Google को भेजा गया अनुरोध सही नहीं लगा।"
            r.code == 401 || r.code == 403 ->
                "API key स्वीकार नहीं हुई, या इस key को इस मॉडल की अनुमति नहीं है, या key हटा दी गई है।"
            r.code == 404 -> "यह मॉडल आपकी key पर मिला नहीं।"
            r.code == 429 && daily -> "आज का मुफ़्त कोटा ख़त्म हो गया। कल दोबारा चलेगा, या AI Studio में नई key/बिलिंग देखिए।"
            r.code == 429 -> "बहुत जल्दी-जल्दी अनुरोध हो गए (मुफ़्त key की प्रति मिनट सीमा)। कुछ सेकंड रुककर बोलिए।"
            r.code in 500..599 -> "Google का सर्वर अभी व्यस्त है या ख़राब है। थोड़ी देर बाद कोशिश कीजिए।"
            else -> "कोई अनजानी दिक्कत आई।"
        }
        val raw = "$model • HTTP ${r.code}${if (status.isNotEmpty()) " $status" else ""} • ${msg.take(350)}"
        return GeminiError("$hint\nअसली कारण: $raw", r.code, retryMs)
    }

    /** Calls one model. Waits and retries a short while on "too fast" (429) and "busy" (503). */
    private fun callModel(model: String, apiKey: String, body: JSONObject): JSONObject {
        var attempt = 0
        while (true) {
            val r = try {
                post(model, apiKey, body)
            } catch (e: IOException) {
                throw networkError(e)
            }
            if (r.code in 200..299) {
                return try {
                    JSONObject(r.text)
                } catch (e: Exception) {
                    throw GeminiError("Google का जवाब समझ नहीं आया।\nअसली कारण: ${e.message}")
                }
            }
            val err = describe(model, r)
            val retryable = (r.code == 429 && !r.text.contains("PerDay", ignoreCase = true)) || r.code == 503
            if (retryable && attempt < 2 && err.retryAfterMs <= 9000) {
                attempt++
                Thread.sleep(maxOf(err.retryAfterMs, 1500L * attempt).coerceAtMost(9000L))
                continue
            }
            throw err
        }
    }

    /** Tries the models one by one: if one is missing (404) or its free quota is used up (429), the next one answers. */
    private fun callChatChain(apiKey: String, body: JSONObject): JSONObject {
        val order = listOf(CHAT_MODEL, "gemini-2.5-flash-lite", "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.0-flash")
        val first = goodChatModel
        val list = if (first != null) listOf(first) + order.filter { it != first } else order
        var last: GeminiError? = null
        for (m in list) {
            try {
                val r = callModel(m, apiKey, body)
                goodChatModel = m
                return r
            } catch (e: GeminiError) {
                if (e.code == 404 || e.code == 429 || e.code == 503) {
                    last = e
                    if (e.code != 404 && m == goodChatModel) goodChatModel = null
                } else throw e
            }
        }
        throw last ?: GeminiError("कोई Gemini मॉडल नहीं मिला।")
    }

    private fun finishInfo(res: JSONObject): String {
        val block = res.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        if (block.isNotEmpty()) return "Gemini ने इस संदेश को रोक दिया (blockReason: $block)"
        val fr = res.optJSONArray("candidates")?.optJSONObject(0)?.optString("finishReason").orEmpty()
        return if (fr.isNotEmpty() && fr != "STOP") "Gemini ने जवाब पूरा नहीं दिया (finishReason: $fr)"
        else "Gemini ने कोई जवाब नहीं दिया (खाली उत्तर)"
    }

    suspend fun chat(apiKey: String, system: String, history: List<Turn>, input: UserInput): ChatResult =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw GeminiError("Profile में पहले Gemini API key डालिए।")

            val contents = JSONArray()
            for (t in history) {
                contents.put(
                    JSONObject().put("role", t.role)
                        .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
                )
            }
            val parts = JSONArray()
            for (wav in input.audioWav) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "audio/wav")
                            .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))
                    )
                )
            }
            if (input.imageB64 != null) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", input.imageB64)
                    )
                )
            }
            val typed = input.text
            if (!typed.isNullOrBlank()) {
                parts.put(JSONObject().put("text", typed))
            } else if (input.audioWav.size > 1) {
                parts.put(JSONObject().put("text", "(The user said all the audio clips above, one after another, in one go. Answer them together.)"))
            } else if (input.audioWav.isEmpty()) {
                parts.put(JSONObject().put("text", "(no message)"))
            }
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            repeat(5) {
                val body = JSONObject()
                    .put(
                        "system_instruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                    )
                    .put("contents", contents)
                    .put("tools", tools())
                    .put(
                        "generationConfig",
                        JSONObject()
                            .put("temperature", 0.9)
                            .put("maxOutputTokens", 700)
                            // no long "thinking" pause: the answer comes fast, like a live talk
                            .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                    )

                val res = callChatChain(apiKey, body)
                val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                val rparts = content?.optJSONArray("parts") ?: JSONArray()

                val calls = ArrayList<JSONObject>()
                val sb = StringBuilder()
                for (i in 0 until rparts.length()) {
                    val p = rparts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        calls.add(p.getJSONObject("functionCall"))
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        sb.append(p.getString("text"))
                    }
                }

                if (calls.isEmpty()) {
                    return@withContext parseReply(sb.toString(), finishInfo(res))
                }

                contents.put(JSONObject().put("role", "model").put("parts", rparts))
                val responses = JSONArray()
                for (c in calls) {
                    val name = c.getString("name")
                    val result = try {
                        actions.run(name, c.optJSONObject("args") ?: JSONObject())
                    } catch (e: Exception) {
                        "Failed: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
                    }
                    responses.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name)
                                .put("response", JSONObject().put("result", result))
                        )
                    )
                }
                contents.put(JSONObject().put("role", "user").put("parts", responses))
            }
            ChatResult("", "ठीक है, काम हो गया।", false)
        }

    private fun parseReply(raw: String, whyEmpty: String): ChatResult {
        var text = raw.trim()
        if (text.isEmpty()) throw GeminiError(whyEmpty)
        if (text.contains("[[ignore]]", ignoreCase = true)) return ChatResult("", "", true)
        var heard = ""
        val m = Regex("^\\s*\\[\\[\\s*heard\\s*:(.*?)\\]\\]\\s*", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(text)
        if (m != null) {
            heard = m.groupValues[1].trim()
            text = text.substring(m.range.last + 1).trim()
        }
        text = text.replace(Regex("\\[\\[.*?\\]\\]"), "").trim()
        if (text.isEmpty()) throw GeminiError("Gemini ने सिर्फ़ सुनी हुई बात लिखी, जवाब नहीं दिया।")
        return ChatResult(heard, text, false)
    }

    suspend fun tts(apiKey: String, text: String, voice: String, stylePrefix: String): ByteArray =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", "$stylePrefix: $text"))
                        )
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig",
                            JSONObject().put(
                                "voiceConfig",
                                JSONObject().put(
                                    "prebuiltVoiceConfig",
                                    JSONObject().put("voiceName", voice)
                                )
                            )
                        )
                )
            val order = listOfNotNull(goodTts) + ttsModels.filter { it != goodTts }
            var last: GeminiError? = null
            var res: JSONObject? = null
            for (m in order) {
                try {
                    res = callModel(m, apiKey, body)
                    goodTts = m
                    break
                } catch (e: GeminiError) {
                    if (e.code == 404) {
                        last = e
                        continue
                    }
                    throw e
                }
            }
            if (res == null) throw last ?: GeminiError("आवाज़ वाला मॉडल नहीं मिला।")
            val data = res.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optJSONObject("inlineData")?.optString("data")
            if (data.isNullOrEmpty()) throw GeminiError("आवाज़ नहीं बन पाई।\nअसली कारण: ${finishInfo(res)}")
            Base64.decode(data, Base64.DEFAULT)
        }

    // ---------- tool declarations ----------

    private fun fn(
        name: String,
        desc: String,
        props: List<Triple<String, String, String>> = emptyList(),
        required: List<String> = emptyList()
    ): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject()
            props.forEach { (n, t, d) ->
                p.put(n, JSONObject().put("type", t).put("description", d))
            }
            o.put(
                "parameters",
                JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
            )
        }
        return o
    }

    fun tools(): JSONArray {
        val d = JSONArray()
        d.put(fn("make_call", "Call a person from the user's contacts, or a phone number. If the contact is not found, retry once with the English/Latin spelling of the name.",
            listOf(Triple("contact", "string", "Contact name as the user said it, or a phone number")), listOf("contact")))
        d.put(fn("answer_call", "Answer the phone call that is ringing right now."))
        d.put(fn("end_call", "End or hang up the current phone call."))
        d.put(fn("send_sms", "Send a text message (SMS) to a contact or number.",
            listOf(Triple("contact", "string", "Contact name or number"), Triple("message", "string", "The message text")),
            listOf("contact", "message")))
        d.put(fn("send_whatsapp", "Send a WhatsApp message to a contact or number.",
            listOf(Triple("contact", "string", "Contact name or number"), Triple("message", "string", "The message text")),
            listOf("contact", "message")))
        d.put(fn("play_youtube", "Search YouTube for a video or song and play it.",
            listOf(Triple("query", "string", "What to search for, e.g. the song or video name")), listOf("query")))
        d.put(fn("set_timer", "Start a countdown timer.",
            listOf(Triple("seconds", "integer", "Timer length in seconds"), Triple("label", "string", "Optional label")),
            listOf("seconds")))
        d.put(fn("set_alarm", "Set an alarm clock for a time of day (24-hour).",
            listOf(Triple("hour", "integer", "Hour 0-23"), Triple("minute", "integer", "Minute 0-59"), Triple("label", "string", "Optional label")),
            listOf("hour", "minute")))
        d.put(fn("set_volume", "Change the phone's media volume. Use either a direction or a level.",
            listOf(Triple("direction", "string", "One of: up, down, mute, max"), Triple("level", "integer", "Volume percent 0-100"))))
        d.put(fn("flashlight", "Turn the phone's flashlight (torch) on or off.",
            listOf(Triple("on", "boolean", "true to turn on, false to turn off")), listOf("on")))
        d.put(fn("open_app", "Open an app installed on the phone.",
            listOf(Triple("app_name", "string", "Name of the app in English, e.g. Camera, Gallery, Settings, Instagram")), listOf("app_name")))
        d.put(fn("open_settings_panel", "Open the Wi-Fi, Bluetooth or volume settings panel (the user then taps the switch).",
            listOf(Triple("kind", "string", "One of: wifi, bluetooth, volume")), listOf("kind")))
        d.put(fn("set_brightness", "Set the screen brightness.",
            listOf(Triple("level", "integer", "Brightness percent 0-100")), listOf("level")))
        d.put(fn("search_web", "Open a Google search in the browser for the given words (use this when the user wants to look something up online).",
            listOf(Triple("query", "string", "What to search for")), listOf("query")))
        d.put(fn("navigate", "Start Google Maps navigation to a place.",
            listOf(Triple("place", "string", "Destination name or address")), listOf("place")))
        return JSONArray().put(JSONObject().put("functionDeclarations", d))
    }
}
