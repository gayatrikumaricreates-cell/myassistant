package com.gayatri.aiassistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.compose.ui.graphics.toArgb
import com.gayatri.aiassistant.MainActivity
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.ai.LiveEngine
import com.gayatri.aiassistant.ai.Prompts
import com.gayatri.aiassistant.ai.SpeechIn
import com.gayatri.aiassistant.data.AppSettings
import com.gayatri.aiassistant.data.Perms
import com.gayatri.aiassistant.data.Prefs
import com.gayatri.aiassistant.ui.orbColors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/** Small bridge between the screen and the background service. */
object AppBridge {
    @Volatile
    var foreground: Boolean = false

    @Volatile
    var onWake: (() -> Unit)? = null
}

object WakeMatcher {
    private val consonants = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h",
        'ळ' to "l"
    )
    private val vowels = mapOf(
        'अ' to "a", 'आ' to "a", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u", 'ए' to "e", 'ऐ' to "ai",
        'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऋ' to "ri"
    )
    private val matras = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u", 'े' to "e", 'ै' to "ai",
        'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ृ' to "ri"
    )

    /** Writes Hindi (Devanagari) words in Latin letters, roughly as they sound, so "प्रिया" matches "Priya". */
    private fun latin(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when {
                c == '\u094D' -> {} // halant: no vowel after the consonant
                c == 'ं' || c == 'ँ' || c == 'ः' -> {}
                c == '\u093C' -> {} // nukta
                consonants.containsKey(c) -> sb.append(consonants[c])
                vowels.containsKey(c) -> sb.append(vowels[c])
                matras.containsKey(c) -> sb.append(matras[c])
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun norm(s: String): String =
        latin(s.lowercase())
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** "maya" and "mayaa", "priya" and "pria": drop doubled letters and the soft h/y/w so sounds line up. */
    private fun skeleton(s: String): String =
        s.replace(Regex("(.)\\1+"), "$1").replace("aa", "a").replace("ee", "i").replace("oo", "u")

    private fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** Any word (Hindi or English) written in plain Latin letters, for fuzzy matching of names. */
    fun roman(s: String): String = skeleton(norm(s))

    fun matches(heard: List<String>, wakeName: String): Boolean {
        var core = norm(wakeName)
        for (p in listOf("hey ", "hi ", "hello ", "ok ", "he ", "hey")) {
            if (core.startsWith(p)) core = core.removePrefix(p).trim()
        }
        core = skeleton(core)
        if (core.length < 2) return false
        val tolerance = if (core.length >= 6) 2 else 1
        return heard.any { h ->
            val n = skeleton(norm(h))
            n.contains(core) || n.split(" ").any { w ->
                w.length >= 3 && core.length >= 3 && distance(w, core) <= tolerance
            }
        }
    }
}

/**
 * Keeps listening for the wake name while the app is closed. When it hears the name it shows
 * the glowing ball at the bottom of the screen and starts a conversation.
 */
class WakeService : Service(), Engine.Callback {

    companion object {
        private const val CHANNEL = "wake"
        private const val NOTIF_ID = 7

        @Volatile
        var instance: WakeService? = null

        fun start(ctx: Context) {
            val i = Intent(ctx, WakeService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(ctx, i)
        }

        fun stopIt(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }

        fun pause() {
            instance?.setPaused(true)
        }

        fun resume() {
            instance?.setPaused(false)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var ears: SpeechIn
    private var engine: LiveEngine? = null
    private var overlay: OverlayView? = null
    private var paused = false
    private var inSession = false
    private var vosk: VoskWake? = null
    private var voskFailed = false
    private var muted = false
    private val restart = Runnable { wakeLoop() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        ears = SpeechIn(applicationContext)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Perms.micOk(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        paused = false
        voskFailed = false
        wakeLoop()
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(restart)
        ears.stop()
        vosk?.stop(true)
        vosk = null
        muteBeep(false)
        engine?.stop()
        engine = null
        hideOverlay()
        scope.cancel()
        super.onDestroy()
    }

    // ---------- wake listening ----------

    fun setPaused(p: Boolean) {
        paused = p
        if (p) {
            handler.removeCallbacks(restart)
            ears.stop()
            vosk?.stop()
            muteBeep(false)
        } else if (!inSession) {
            handler.removeCallbacks(restart)
            handler.postDelayed(restart, 400)
        }
    }

    private fun schedule(ms: Long) {
        handler.removeCallbacks(restart)
        handler.postDelayed(restart, ms)
    }

    private fun wakeLoop() {
        handler.removeCallbacks(restart)
        if (paused || inSession) return
        val s = Prefs(this).load()
        if (!s.handsFree) {
            stopSelf()
            return
        }
        if (!voskFailed) {
            // smooth: reads the mic directly, never takes the phone's audio, no blinking, no volume change
            muteBeep(false)
            ears.stop()
            val v = vosk ?: VoskWake(applicationContext).also { vosk = it }
            v.start(
                if (s.wakeName.all { it.code < 128 }) "english" else "hindi", // an English-letter name is heard best by the English model
                s.wakeName,
                onWake = { onWake() },
                onStatus = { msg -> toast(msg) },
                onFail = { msg ->
                    voskFailed = true
                    toast(msg)
                    schedule(300)
                }
            )
            return
        }
        vosk?.stop()
        muteBeep(true)
        val lang = if (s.language == "english") "en-IN" else "hi-IN"
        ears.listen(
            lang,
            onPartial = { list -> if (WakeMatcher.matches(list, s.wakeName)) onWake() },
            onFinal = { list ->
                if (WakeMatcher.matches(list, s.wakeName)) onWake() else schedule(250)
            },
            onFail = { code ->
                when (code) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> schedule(1500)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> schedule(4000)
                    else -> schedule(350)
                }
            }
        )
    }

    private fun toast(msg: String) {
        try {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    /** The recogniser beeps every time it starts; silence the notification/system streams while idle-listening. */
    private fun muteBeep(mute: Boolean) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (mute && !muted && am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
                am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
                muted = true
            } else if (!mute && muted) {
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
                am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
                muted = false
            }
        } catch (e: Exception) {
            muted = false
        }
    }

    // ---------- conversation after wake ----------

    private fun onWake() {
        if (inSession) return
        handler.removeCallbacks(restart)
        ears.stop()
        vosk?.stop()
        muteBeep(false)

        val bridge = AppBridge.onWake
        if (AppBridge.foreground && bridge != null) {
            // The app is open: let the app screen handle the conversation.
            bridge.invoke()
            return
        }

        inSession = true
        val s = Prefs(this).load()
        showOverlay(s)
        engine?.stop()
        val e = LiveEngine(applicationContext, scope, this)
        engine = e
        e.keepAlive = true
        e.begin(Prompts.greeting(s))
    }

    private fun showOverlay(s: AppSettings) {
        if (!Settings.canDrawOverlays(this)) {
            try {
                android.widget.Toast.makeText(
                    applicationContext,
                    "To show the orb, allow 'Display over other apps' (Settings > Phone control).",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
            }
            return
        }
        try {
            val (a, b) = orbColors(s)
            val v = OverlayView(this, a.toArgb(), b.toArgb())
            v.setOnClickListener {
                engine?.stop()
                finishSession()
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            // centre of the ball sits on the middle of the 3 navigation buttons
            lp.y = (-16 * resources.displayMetrics.density).toInt()
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
        } catch (e: Exception) {
            overlay = null
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun finishSession() {
        if (!inSession) return
        inSession = false
        engine = null
        hideOverlay()
        if (!paused) schedule(500)
    }

    // ---------- Engine.Callback ----------

    override fun onState(s: Engine.State) {
        overlay?.setState(s)
    }

    override fun onHeard(text: String, final: Boolean) {
        // overlay shows only the ball, never text
    }

    override fun onReply(text: String) {
    }

    override fun onError(msg: String) {
        // The app is closed, so show the real reason as a message on the screen.
        try {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    override fun onSessionEnd() {
        handler.postDelayed({ finishSession() }, 900)
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Assistant listening", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val s = Prefs(this).load()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("${s.wakeName} is listening")
            .setContentText("Say \"Hey ${s.wakeName}\" to call")
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
