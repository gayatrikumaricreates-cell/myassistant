package com.gayatri.aiassistant.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.data.Perms

/** Bumped by MainActivity.onResume so permission status refreshes after returning from system settings. */
object UiTick {
    var value by mutableIntStateOf(0)
}

@Composable
private fun NavRow(
    icon: ImageVector,
    title: String,
    sub: String,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    Glass(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(17.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(sub, color = C.sub, fontSize = 11.sp)
            }
            trailing()
            Icon(Icons.Rounded.ChevronRight, null, tint = C.sub, modifier = Modifier.size(20.dp))
        }
    }
}

// ---------------------------------------------------------------- Settings (main)

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    var editing by remember { mutableStateOf(false) }
    var wake by remember { mutableStateOf(s.wakeName) }
    val (ca, cb) = orbColors(s)

    SubScreen("Settings", onBack = { vm.route = Route.Home }) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hands-free activation", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Say the wake name even when the app is closed",
                            color = C.sub,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = s.handsFree,
                        onCheckedChange = { vm.setHandsFree(it) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = C.teal,
                            checkedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0x55FFFFFF),
                            uncheckedThumbColor = Color.White,
                            uncheckedBorderColor = Color.Transparent
                        )
                    )
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Smooth listening", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Listens without pausing videos or lowering the volume. Switch off to use the old method.",
                            color = C.sub,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = s.wakeMethod != "classic",
                        onCheckedChange = { vm.setWakeMethod(it) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = C.teal,
                            checkedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0x55FFFFFF),
                            uncheckedThumbColor = Color.White,
                            uncheckedBorderColor = Color.Transparent
                        )
                    )
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                Spacer(Modifier.height(10.dp))
                if (!editing) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Wake name", color = C.sub, fontSize = 10.sp)
                            Text("Hey ${s.wakeName}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Color(0x33FFFFFF))
                                .clickable {
                                    wake = s.wakeName
                                    editing = true
                                }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("Change", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    Text("Type the new wake name", color = C.sub, fontSize = 10.sp)
                    Spacer(Modifier.height(6.dp))
                    AppField(value = wake, onChange = { wake = it }, placeholder = "e.g. Priya, Jarvis, Mitra")
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(C.teal)
                                .clickable {
                                    val n = wake.trim()
                                    if (n.length >= 2) {
                                        vm.update { it.copy(wakeName = n) }
                                        editing = false
                                    } else {
                                        vm.message = "The name needs at least two letters."
                                    }
                                }
                                .padding(horizontal = 16.dp, vertical = 7.dp)
                        ) {
                            Text("Save", color = Color(0xFF062B26), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Color(0x33FFFFFF))
                                .clickable { editing = false }
                                .padding(horizontal = 16.dp, vertical = 7.dp)
                        ) {
                            Text("Cancel", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        NavRow(
            Icons.Rounded.VolumeUp, "Voice",
            "${s.voice} · ${if (Catalog.voice(s.voice).female) "Female" else "Male"}",
            { vm.route = Route.Voice }
        )
        NavRow(
            Icons.Rounded.Palette, "Colors & theme",
            if (s.useMix) "Custom · 2-color mix" else s.theme,
            { vm.route = Route.Colors },
            trailing = {
                Box(
                    Modifier
                        .padding(end = 6.dp)
                        .size(width = 26.dp, height = 14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Brush.horizontalGradient(listOf(ca, cb)))
                )
            }
        )
        NavRow(
            Icons.Rounded.Language, "Language", Catalog.language(s.language).label,
            { vm.route = Route.Language }
        )
        NavRow(
            Icons.Rounded.EmojiEmotions, "Talking style", Catalog.style(s.style).label,
            { vm.route = Route.Style }
        )
        NavRow(
            Icons.Rounded.Shield, "Phone control", "Calls, WhatsApp, Wi-Fi, volume...",
            { vm.route = Route.Phone }
        )
        NavRow(
            Icons.Rounded.ChatBubbleOutline, "Chat history", "Save chats made inside the app",
            { vm.showProfile = true }
        )
    }
}

// ---------------------------------------------------------------- Voice

@Composable
fun VoiceScreen(vm: AppViewModel) {
    val s = vm.settings
    var playing by remember { mutableStateOf<String?>(null) }

    SubScreen("Voice", onBack = {
        vm.stopPreview()
        vm.route = Route.Settings
    }) {
        @Composable
        fun group(label: String, female: Boolean) {
            SectionLabel(label)
            Catalog.voices.filter { it.female == female }.forEach { v ->
                val selected = s.voice == v.id
                Glass(
                    Modifier.fillMaxWidth(),
                    selected = selected,
                    onClick = { vm.update { it.copy(voice = v.id) } }
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val on = playing == v.id
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0x40FFFFFF))
                                .clickable {
                                    if (on) {
                                        vm.stopPreview()
                                        playing = null
                                    } else {
                                        playing = v.id
                                        vm.previewVoice(v.id)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                if (on) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                null, tint = Color.White, modifier = Modifier.size(17.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.id, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(v.desc, color = C.sub, fontSize = 10.sp)
                        }
                        if (selected) Icon(Icons.Rounded.Check, null, tint = C.teal, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        group("FEMALE VOICES", true)
        group("MALE VOICES", false)
        Text(
            "Press ▶ to listen, press the name to choose. A natural human voice needs the API key in Profile.",
            color = C.sub, fontSize = 10.sp, modifier = Modifier.padding(4.dp)
        )
    }
}

// ---------------------------------------------------------------- Colors & theme

@Composable
fun ColorsScreen(vm: AppViewModel) {
    val s = vm.settings
    val (ca, cb) = orbColors(s)

    SubScreen("Colors & theme", onBack = { vm.route = Route.Settings }) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Orb(ca, cb, Modifier.size(150.dp), level = 0.3f, calm = s.mixSpeed == "Calm")
        }

        SectionLabel("THEMES")
        OrbThemes.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { t ->
                    val selected = !s.useMix && s.theme == t.name
                    Glass(
                        Modifier.weight(1f),
                        selected = selected,
                        onClick = { vm.update { it.copy(theme = t.name, useMix = false) } }
                    ) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(t.a, t.b)))
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(t.name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        SectionLabel("MIX YOUR OWN")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DotRow("Color 1", Palette1, if (s.useMix) s.color1 else -1) { i ->
                    vm.update { it.copy(color1 = i, useMix = true) }
                }
                DotRow("Color 2", Palette2, if (s.useMix) s.color2 else -1) { i ->
                    vm.update { it.copy(color2 = i, useMix = true) }
                }
            }
        }

        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Mixing speed", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("How fast colors flow when idle", color = C.sub, fontSize = 10.sp)
                }
                listOf("Calm", "Lively").forEach { m ->
                    val on = s.mixSpeed == m
                    Box(
                        Modifier
                            .padding(start = 6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (on) C.teal else Color(0x33FFFFFF))
                            .clickable { vm.update { it.copy(mixSpeed = m) } }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            m, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            color = if (on) Color(0xFF062B26) else Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DotRow(label: String, colors: List<Color>, selected: Int, onPick: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = C.sub, fontSize = 11.sp, modifier = Modifier.width(56.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {
            colors.forEachIndexed { i, c ->
                Box(
                    Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(c)
                        .then(if (selected == i) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                        .clickable { onPick(i) }
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Language / Style

@Composable
fun LanguageScreen(vm: AppViewModel) {
    SubScreen("Language", onBack = { vm.route = Route.Settings }) {
        Catalog.languages.forEach { l ->
            ChoiceRow(l.label, "", vm.settings.language == l.key) {
                vm.update { it.copy(language = l.key) }
            }
        }
    }
}

@Composable
fun StyleScreen(vm: AppViewModel) {
    SubScreen("Talking style", onBack = { vm.route = Route.Settings }) {
        Catalog.styles.forEach { st ->
            ChoiceRow(st.label, "", vm.settings.style == st.key) {
                vm.update { it.copy(style = st.key) }
            }
        }
    }
}

@Composable
private fun ChoiceRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Glass(Modifier.fillMaxWidth(), selected = selected, onClick = onClick) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (sub.isNotEmpty()) Text(sub, color = C.sub, fontSize = 11.sp)
            }
            if (selected) Icon(Icons.Rounded.Check, null, tint = C.teal, modifier = Modifier.size(18.dp))
        }
    }
}

// ---------------------------------------------------------------- Phone control (permissions)

@Composable
fun PermissionList(onChanged: () -> Unit = {}) {
    val ctx = LocalContext.current
    @Suppress("UNUSED_VARIABLE")
    val tick = UiTick.value
    var local by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE")
    val dep = local

    val runtimeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        local++
        onChanged()
    }

    val items = listOf(
        Triple(
            "Mic, camera, calls, contacts, SMS",
            "To listen to you, see through the live camera, make calls, find numbers by name, read and send messages and see call history",
            Perms.missingRuntime(ctx).isEmpty()
        ) to { runtimeLauncher.launch(Perms.runtime()) },
        Triple(
            "Display over other apps",
            "Shows the glowing ball at the bottom when you call the name with the app closed",
            Perms.overlayOk(ctx)
        ) to {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        },
        Triple(
            "Accessibility (control the screen)",
            "Lets the assistant scroll reels, tap buttons, type and send WhatsApp. Find this app in Settings and turn it on",
            Perms.accessibilityOn(ctx)
        ) to {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        },
        Triple(
            "Read notifications",
            "So the assistant can tell you what notifications came. Switch on 'AI Assistant' on the screen that opens",
            Perms.notificationsOk(ctx)
        ) to {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        },
        Triple(
            "Open every app (installed-apps list)",
            "If a phone hides its apps, allow 'Installed apps' in the screen that opens (Permissions)",
            Perms.appsListOk(ctx)
        ) to {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        },
        Triple(
            "Remove battery restriction",
            "So the phone does not close the app in the background",
            Perms.batteryOk(ctx)
        ) to {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { (info, action) ->
            val (title, sub, ok) = info
            Glass(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(sub, color = C.sub, fontSize = 10.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    if (ok) {
                        Icon(Icons.Rounded.Check, null, tint = C.teal, modifier = Modifier.size(22.dp))
                    } else {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(C.teal)
                                .clickable { action() }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("Allow", color = Color(0xFF062B26), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PhoneScreen(vm: AppViewModel) {
    SubScreen("Phone control", onBack = { vm.route = Route.Settings }) {
        Text(
            "Give the permissions below so every assistant feature works. A green ✓ means it is granted.",
            color = C.sub, fontSize = 11.sp, modifier = Modifier.padding(4.dp)
        )
        PermissionList()
    }
}

// ---------------------------------------------------------------- First-open screen

@Composable
fun OnboardingScreen(vm: AppViewModel) {
    val (ca, cb) = orbColors(vm.settings)
    SubScreenNoBack {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Orb(ca, cb, Modifier.size(170.dp), level = 0.3f)
        }
        Text(
            "Welcome!",
            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            "Give the permissions below one by one so your assistant can do everything. Then add your name and Gemini API key in Profile.",
            color = C.sub, fontSize = 12.sp
        )
        PermissionList()
        Box(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
                .clip(RoundedCornerShape(50))
                .background(C.teal)
                .clickable {
                    vm.finishOnboarding()
                    if (vm.settings.apiKey.isBlank()) vm.showProfile = true
                }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Continue", color = Color(0xFF062B26), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SubScreenNoBack(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBrush)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}
