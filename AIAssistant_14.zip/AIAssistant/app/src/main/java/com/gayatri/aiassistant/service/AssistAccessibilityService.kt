package com.gayatri.aiassistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * The assistant's hands on the screen. It
 *  - presses "Send" in WhatsApp and taps the first YouTube result (automatically, for a few seconds after a request),
 *  - and, when the user asks, reads the screen, taps a button by its words, scrolls/swipes, types text and presses
 *    Back / Home (the screen_* tools).
 */
class AssistAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistAccessibilityService? = null

        @Volatile
        var pendingWhatsAppSendUntil: Long = 0L

        @Volatile
        var pendingYoutubePlayUntil: Long = 0L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        if (pkg.startsWith("com.whatsapp") && now < pendingWhatsAppSendUntil) {
            trySendWhatsApp()
        } else if (pkg == "com.google.android.youtube" && now < pendingYoutubePlayUntil) {
            tryPlayYoutube()
        }
    }

    private fun trySendWhatsApp() {
        val root = rootInActiveWindow ?: return
        var node: AccessibilityNodeInfo? = null
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val found = root.findAccessibilityNodeInfosByViewId(id)
            if (found != null && found.isNotEmpty()) {
                node = found[0]
                break
            }
        }
        if (node == null) {
            node = find(root) {
                val d = it.contentDescription?.toString()?.trim()?.lowercase()
                d == "send" || d == "भेजें"
            }
        }
        if (node != null && clickNodeOrParent(node)) {
            pendingWhatsAppSendUntil = 0L
        }
    }

    private fun tryPlayYoutube() {
        val root = rootInActiveWindow ?: return
        val node = find(root) {
            it.contentDescription?.toString()?.lowercase()?.contains("play video") == true
        }
        if (node != null && clickNodeOrParent(node)) {
            pendingYoutubePlayUntil = 0L
        }
    }

    private fun find(
        n: AccessibilityNodeInfo?,
        depth: Int = 0,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), depth + 1, pred)
            if (r != null) return r
        }
        return null
    }

    private fun clickNodeOrParent(start: AccessibilityNodeInfo?): Boolean {
        var c = start
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable) return c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            c = c.parent
            d++
        }
        return false
    }

    // ---------- screen control used by the screen_* tools ----------

    private fun labelOf(n: AccessibilityNodeInfo): String? {
        val t = n.text?.toString()?.trim()
        if (!t.isNullOrBlank()) return t
        val d = n.contentDescription?.toString()?.trim()
        return if (d.isNullOrBlank()) null else d
    }

    private fun collect(n: AccessibilityNodeInfo?, out: LinkedHashSet<String>, depth: Int) {
        if (n == null || depth > 40 || out.size >= 90) return
        val l = labelOf(n)
        if (l != null) out.add((if (n.isClickable) "[tap] " else "") + l.take(90))
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Failed: the screen cannot be read right now (it may be a protected screen)."
        val items = LinkedHashSet<String>()
        collect(root, items, 0)
        if (items.isEmpty()) return "App ${root.packageName}: nothing readable on the screen (maybe a video, a game or a protected screen)."
        return "App ${root.packageName}. On screen: " + items.joinToString(" | ")
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun tapText(text: String): String {
        val q = text.trim().lowercase()
        if (q.isEmpty()) return "Failed: nothing to tap was named."
        val root = rootInActiveWindow ?: return "Failed: the screen cannot be read right now."
        val node = find(root) { labelOf(it)?.lowercase() == q }
            ?: find(root) { labelOf(it)?.lowercase()?.contains(q) == true }
            ?: return "Failed: nothing on the screen matches '$text'. Use screen_read to see what is there, or scroll and try again."
        if (clickNodeOrParent(node)) return "Tapped '$text'."
        val r = Rect()
        node.getBoundsInScreen(r)
        return if (tapAt(r.exactCenterX(), r.exactCenterY())) "Tapped '$text'." else "Failed: found '$text' but could not tap it."
    }

    fun scroll(direction: String): String {
        if (Build.VERSION.SDK_INT < 24) return "Failed: this Android version cannot swipe."
        val d = direction.lowercase()
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        when {
            d.contains("left") -> { p.moveTo(w * 0.8f, h * 0.5f); p.lineTo(w * 0.2f, h * 0.5f) }
            d.contains("right") -> { p.moveTo(w * 0.2f, h * 0.5f); p.lineTo(w * 0.8f, h * 0.5f) }
            d.contains("up") || d.contains("prev") || d.contains("back") -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.75f) }
            else -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.28f) } // down / next: finger moves up
        }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 260)).build()
        return if (dispatchGesture(g, null, null)) "Swiped $d." else "Failed: the swipe was refused by the phone."
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "Failed: the screen cannot be read right now."
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: find(root) { it.isEditable }
            ?: return "Failed: no text box is on the screen. Tap the search or message box first."
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed the text." else "Failed: the text box refused the text."
    }

    fun key(key: String): String {
        val k = key.lowercase()
        return when {
            k.contains("back") -> if (performGlobalAction(GLOBAL_ACTION_BACK)) "Pressed Back." else "Failed: Back was refused."
            k.contains("home") -> if (performGlobalAction(GLOBAL_ACTION_HOME)) "Went to the home screen." else "Failed: Home was refused."
            k.contains("recent") -> if (performGlobalAction(GLOBAL_ACTION_RECENTS)) "Opened recent apps." else "Failed."
            k.contains("notif") -> if (performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)) "Opened the notification shade." else "Failed."
            k.contains("enter") || k.contains("search") || k.contains("send") -> {
                val root = rootInActiveWindow
                val f = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (f != null && Build.VERSION.SDK_INT >= 30 &&
                    f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                ) "Pressed Enter." else "Failed: could not press Enter; tap the search/send button with screen_tap instead."
            }
            else -> "Failed: unknown key '$key'. Use back, home, recents, notifications or enter."
        }
    }
}
