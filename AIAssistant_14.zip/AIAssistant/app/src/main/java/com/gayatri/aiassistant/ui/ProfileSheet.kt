package com.gayatri.aiassistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gayatri.aiassistant.data.ChatEntry
import com.gayatri.aiassistant.data.SHOW_CHAT_HISTORY

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProfileSheet(vm: AppViewModel) {
    val s = vm.settings
    val (ca, cb) = orbColors(s)
    var armed by remember { mutableStateOf<Long?>(null) }
    val close = { vm.showProfile = false }
    BackHandler(onBack = close)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { close() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(top = 60.dp)
                .imePadding()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Brush.verticalGradient(listOf(C.sheet, Color(0xFF1B1F82))))
                .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {}
                .navigationBarsPadding()
                .padding(horizontal = 18.dp)
                .padding(top = 10.dp, bottom = 16.dp)
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(38.dp)
                    .size(width = 38.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0x55FFFFFF))
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(ca, cb))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        (s.userName.trim().firstOrNull() ?: 'G').uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Profile", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("${s.wakeName} uses this to talk to you personally", color = C.sub, fontSize = 11.sp)
                }
                CircleButton(Icons.Rounded.Close, 32.dp) { close() }
            }

            Column(
                Modifier
                    .weight(1f, fill = false)
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                SectionLabel("YOUR NAME")
                AppField(
                    value = s.userName,
                    onChange = { v -> vm.update { it.copy(userName = v) } },
                    placeholder = "Your name"
                )

                SectionLabel("ABOUT YOU")
                AppField(
                    value = s.about,
                    onChange = { v -> vm.update { it.copy(about = v) } },
                    placeholder = "e.g. I am a teacher, keep answers short, talk in Hindi",
                    singleLine = false,
                    minLines = 2
                )

                SectionLabel("GEMINI API KEY")
                AppField(
                    value = s.apiKey,
                    onChange = { v -> vm.update { it.copy(apiKey = v.trim()) } },
                    placeholder = "Paste the key from Google AI Studio here",
                    password = true
                )
                Text(
                    if (s.apiKey.isBlank()) "Key डालने से पहले असिस्टेंट चालू नहीं होगा।"
                    else "Key सेव हो गई, असिस्टेंट तैयार है।",
                    color = if (s.apiKey.isBlank()) C.sub else C.teal,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                if (SHOW_CHAT_HISTORY) {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionLabel("CHAT HISTORY", Modifier.padding(top = 0.dp))
                    Text("Press & hold to delete", color = C.sub, fontSize = 9.sp)
                }
                Spacer(Modifier.padding(top = 6.dp))
                if (vm.history.isEmpty()) {
                    Text("No chats yet.", color = C.sub, fontSize = 12.sp, modifier = Modifier.padding(4.dp))
                }
                vm.history.forEach { e -> HistoryRow(e, armed == e.id, { armed = if (armed == e.id) null else e.id }) {
                    vm.deleteHistory(e.id)
                    armed = null
                } }

                Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Info, null, tint = C.sub, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Chats started by voice from outside the app are not saved here.",
                        color = C.sub,
                        fontSize = 10.sp
                    )
                }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HistoryRow(e: ChatEntry, armed: Boolean, onLong: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .padding(bottom = 7.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(if (armed) Brush.horizontalGradient(listOf(Color(0xFF8E2F5A), Color(0xFF5A2A7A))) else CardBrush)
            .border(1.dp, C.cardBorder, shape)
            .combinedClickable(onClick = { if (armed) onLong() }, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(e.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
            Text(timeLabel(e.time), color = C.sub, fontSize = 10.sp)
        }
        if (armed) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(C.danger)
                    .clickable { onDelete() }
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.DeleteOutline, null, tint = Color.White, modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(4.dp))
                Text("Delete", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
