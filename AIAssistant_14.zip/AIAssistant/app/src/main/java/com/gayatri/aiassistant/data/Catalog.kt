package com.gayatri.aiassistant.data

data class VoiceOption(
    val id: String,
    val desc: String,
    val female: Boolean,
    val geminiVoice: String,
    val persona: String = ""
)

data class StyleOption(
    val key: String,
    val label: String,
    val prompt: String,
    val ttsPrefix: String
)

data class LanguageOption(
    val key: String,
    val label: String,
    val prompt: String
)

object Catalog {
    val voices = listOf(
        VoiceOption("Aria", "Warm & friendly", true, "Sulafat",
            "Speak with a warm, round, friendly woman's voice at a relaxed medium pace and a smile in the tone."),
        VoiceOption("Meera", "Soft & calm", true, "Achernar",
            "Speak with a very soft, quiet, gentle woman's voice, slowly, almost whispering and soothing."),
        VoiceOption("Kavya", "Cheerful & laughs a lot", true, "Laomedeia",
            "Speak with a bright, bubbly, high-spirited young woman's voice, fast and excited, laughing often."),
        VoiceOption("Nova", "Mature & composed", true, "Gacrux",
            "Speak with a mature, low-pitched, composed and polished woman's voice, slow and authoritative."),
        VoiceOption("Siya", "Young & playful", true, "Leda",
            "Speak with a youthful, light, high-pitched girl's voice, playful and teasing, quick and cheeky."),
        VoiceOption("Arjun", "Deep & heavy", false, "Algenib",
            "Speak with a very deep, low, heavy, slightly gravelly man's voice at a slow, powerful pace."),
        VoiceOption("Dev", "Friendly & easygoing", false, "Achird",
            "Speak with a friendly, casual, medium-pitched man's voice at a relaxed, chatty pace."),
        VoiceOption("Rohan", "Young & energetic", false, "Puck",
            "Speak with a young, high-energy, fast-talking guy's voice, upbeat and lively."),
        VoiceOption("Kabir", "Calm storyteller", false, "Charon",
            "Speak with a calm, smooth, slow storyteller's voice, thoughtful with soft pauses."),
        VoiceOption("Leo", "Funny & excitable", false, "Fenrir",
            "Speak with an excitable, comedic, expressive man's voice, animated, with sudden bursts of laughter.")
    )

    fun voice(id: String): VoiceOption = voices.firstOrNull { it.id == id } ?: voices[0]

    val languages = listOf(
        LanguageOption(
            "mix", "Hindi + English mix",
            "Reply in natural Hinglish: write Hindi in Devanagari script and keep common English words in English letters, the way people really talk. Match the language the user used."
        ),
        LanguageOption(
            "hindi", "Only Hindi",
            "Reply only in simple spoken Hindi written in Devanagari script."
        ),
        LanguageOption(
            "english", "Only English",
            "Reply only in simple spoken English."
        )
    )

    fun language(key: String): LanguageOption = languages.firstOrNull { it.key == key } ?: languages[0]

    val styles = listOf(
        StyleOption(
            "friendly", "Friendly, expressive, laughs",
            "Be like a warm, close friend: expressive, cheerful, show real emotion, and laugh naturally at funny things.",
            "Say in a warm, natural, expressive and friendly human way, like chatting with a close friend"
        ),
        StyleOption(
            "calm", "Calm & gentle",
            "Be calm, gentle and soothing. Speak softly and patiently.",
            "Say in a calm, gentle, soothing human voice"
        ),
        StyleOption(
            "playful", "Playful & funny",
            "Be playful, witty and funny. Make light jokes and laugh often.",
            "Say in a playful, cheerful, laughing human way"
        ),
        StyleOption(
            "crisp", "Short & to the point",
            "Be brief and direct: one or two short sentences, but still warm and human.",
            "Say in a clear, confident, natural human voice"
        )
    )

    fun style(key: String): StyleOption = styles.firstOrNull { it.key == key } ?: styles[0]
}
