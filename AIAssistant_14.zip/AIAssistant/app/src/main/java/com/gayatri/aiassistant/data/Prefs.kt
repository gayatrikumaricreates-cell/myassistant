package com.gayatri.aiassistant.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AppSettings(
    val apiKey: String = "",
    val userName: String = "",
    val about: String = "",
    val wakeName: String = "Priya",
    val handsFree: Boolean = false,
    val voice: String = "Aria",
    val theme: String = "Aurora",
    val useMix: Boolean = false,
    val color1: Int = 0,
    val color2: Int = 0,
    val mixSpeed: String = "Lively",
    val language: String = "mix",
    val style: String = "friendly",
    val wakeMethod: String = "smooth"
)

/** Chat history inside Profile is switched off (the user does not want chats kept). Set to true to bring it back. */
const val SHOW_CHAT_HISTORY = false

data class ChatEntry(val id: Long, val title: String, val time: Long)

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("assistant", Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        apiKey = sp.getString("apiKey", "") ?: "",
        userName = sp.getString("userName", "") ?: "",
        about = sp.getString("about", "") ?: "",
        wakeName = sp.getString("wakeName", "Priya") ?: "Priya",
        handsFree = sp.getBoolean("handsFree", false),
        voice = sp.getString("voice", "Aria") ?: "Aria",
        theme = sp.getString("theme", "Aurora") ?: "Aurora",
        useMix = sp.getBoolean("useMix", false),
        color1 = sp.getInt("color1", 0),
        color2 = sp.getInt("color2", 0),
        mixSpeed = sp.getString("mixSpeed", "Lively") ?: "Lively",
        language = sp.getString("language", "mix") ?: "mix",
        style = sp.getString("style", "friendly") ?: "friendly",
        wakeMethod = sp.getString("wakeMethod", "smooth") ?: "smooth"
    )

    fun save(s: AppSettings) {
        sp.edit()
            .putString("apiKey", s.apiKey.trim())
            .putString("userName", s.userName)
            .putString("about", s.about)
            .putString("wakeName", s.wakeName)
            .putBoolean("handsFree", s.handsFree)
            .putString("voice", s.voice)
            .putString("theme", s.theme)
            .putBoolean("useMix", s.useMix)
            .putInt("color1", s.color1)
            .putInt("color2", s.color2)
            .putString("mixSpeed", s.mixSpeed)
            .putString("language", s.language)
            .putString("style", s.style)
            .putString("wakeMethod", s.wakeMethod)
            .apply()
    }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) {
            sp.edit().putBoolean("onboarded", v).apply()
        }

    fun history(): List<ChatEntry> {
        val arr = try {
            JSONArray(sp.getString("history", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<ChatEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(ChatEntry(o.optLong("id"), o.optString("title"), o.optLong("time")))
        }
        return out
    }

    private fun saveHistory(list: List<ChatEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("time", it.time))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun addHistory(title: String) {
        val now = System.currentTimeMillis()
        val list = history().toMutableList()
        list.add(0, ChatEntry(now, title.take(120), now))
        saveHistory(list.take(60))
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    fun deleteHistory(id: Long) {
        saveHistory(history().filter { it.id != id })
    }
}
