package com.gayatri.aiassistant.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.data.Perms

@Composable
fun HomeScreen(vm: AppViewModel) {
    val s = vm.settings
    val (ca, cb) = orbColors(s)
    val active = vm.state != Engine.State.Idle
    var typing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }

    val ctx = LocalContext.current
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.setCamera(true) else vm.error = "कैमरा चालू नहीं हो सकता क्योंकि कैमरे की अनुमति नहीं दी गई। Settings > Phone control में Allow कीजिए।"
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBrush)
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CircleButton(Icons.Rounded.Person, 40.dp) { vm.showProfile = true }
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color(0x66000000))
                    .border(1.dp, C.cardBorder, RoundedCornerShape(50))
                    .padding(horizontal = 18.dp, vertical = 7.dp)
            ) {
                Text(s.wakeName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            CircleButton(Icons.Rounded.Tune, 40.dp) { vm.route = Route.Settings }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
        if (vm.cameraOn) {
            LiveCameraPreview(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(width = 104.dp, height = 140.dp)
                    .padding(top = 4.dp),
                onFrame = { vm.onFrame(it) },
                onError = { vm.error = it; vm.setCamera(false) }
            )
        }
        Column(
            Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Orb(
                a = ca,
                b = cb,
                modifier = Modifier.size(280.dp),
                level = when (vm.state) {
                    Engine.State.Speaking -> 1f
                    Engine.State.Listening -> 0.7f
                    Engine.State.Thinking -> 0.4f
                    Engine.State.Idle -> 0.1f
                },
                calm = s.mixSpeed == "Calm"
            )

            if (!active && vm.heard.isEmpty() && vm.reply.isEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Tap the mic to talk live, or just say", color = C.sub, fontSize = 12.sp)
                Text(
                    "“Hey ${s.wakeName}”",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            } else {
                Waves(active = vm.state == Engine.State.Listening || vm.state == Engine.State.Speaking, color = ca)
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (vm.heard.isNotEmpty()) {
                        Box(
                            Modifier
                                .align(Alignment.End)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x40FFFFFF))
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(vm.heard, color = C.sub, fontSize = 12.sp)
                        }
                    }
                    if (vm.reply.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            vm.reply,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Text(
                    when (vm.state) {
                        Engine.State.Listening -> "${s.wakeName} is listening..."
                        Engine.State.Thinking -> "${s.wakeName} is thinking..."
                        Engine.State.Speaking -> "${s.wakeName} is speaking..."
                        Engine.State.Idle -> ""
                    },
                    color = C.sub,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        }

        if (typing) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppField(
                    value = draft,
                    onChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = "Type here..."
                )
                CircleButton(Icons.Rounded.Send, 46.dp, tint = C.teal) {
                    val t = draft.trim()
                    if (t.isNotEmpty()) {
                        draft = ""
                        typing = false
                        vm.sendText(t)
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp, top = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleButton(Icons.Rounded.Keyboard, 48.dp) { typing = !typing }

            Box(
                Modifier
                    .size(72.dp)
                    .raisedButton(CircleShape, 6.dp) { vm.toggleMic() }
                    .border(2.dp, ca, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (active) Icons.Rounded.Stop else Icons.Rounded.Mic,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }

            CircleButton(
                if (vm.cameraOn) Icons.Rounded.Videocam else Icons.Rounded.PhotoCamera,
                48.dp,
                tint = if (vm.cameraOn) C.teal else Color.White
            ) {
                if (vm.cameraOn) {
                    vm.setCamera(false)
                } else if (Perms.cameraOk(ctx)) {
                    vm.setCamera(true)
                } else {
                    cameraPermission.launch(android.Manifest.permission.CAMERA)
                }
            }
        }
    }
}
