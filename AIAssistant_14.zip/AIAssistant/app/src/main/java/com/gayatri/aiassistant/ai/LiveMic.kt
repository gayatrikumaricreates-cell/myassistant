package com.gayatri.aiassistant.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.sqrt

/**
 * An always-on microphone for a live talk.
 *
 * It keeps recording the whole time, even while the assistant is speaking (echo is removed by the phone's
 * echo canceller), cuts the sound into sentences by itself, and tells the Engine:
 *  - onSpeechStart: the user began to speak (the Engine stops the assistant's voice = "barge-in")
 *  - onUtterance: the user finished a sentence, here is the sound (WAV)
 */
class LiveMic(private val ctx: Context) {

    interface Listener {
        fun onSpeechStart()
        fun onSpeechAborted()
        fun onUtterance(wav: ByteArray)
        fun onFatal(msg: String)
    }

    companion object {
        const val RATE = 16000
        private const val FRAME = RATE / 50              // 20 ms
        private const val PRE_ROLL_FRAMES = 15           // keep 300 ms before speech was noticed
        private const val END_SILENCE_FRAMES = 42        // 840 ms of quiet ends a sentence
        private const val MAX_FRAMES = 1500              // 30 s safety cut
        private const val MIN_VOICED_FRAMES = 14         // shorter than ~280 ms is a click, not speech
        private const val START_FRAMES = 5               // 100 ms of voice starts a sentence
        private const val START_FRAMES_WHILE_ASSISTANT = 11 // 220 ms needed to interrupt the assistant
        private const val FLOOR = 450.0
        private const val FLOOR_WHILE_ASSISTANT = 1000.0
    }

    @Volatile
    var assistantSpeaking: Boolean = false

    @Volatile
    private var running = false
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())

    val isRunning: Boolean get() = running

    /** Returns null when the microphone started, otherwise the real reason why it did not. */
    fun start(l: Listener): String? {
        if (running) return null
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "माइक की अनुमति नहीं है। Settings > Phone control में 'Allow' दबाइए।"
        }
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return "इस फ़ोन का माइक 16 kHz पर नहीं चल पा रहा (getMinBufferSize=$minBuf)।"
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, FRAME * 2 * 10)
            )
        } catch (e: Exception) {
            return "माइक खुल नहीं पाया।\nअसली कारण: ${e.javaClass.simpleName}: ${e.message}"
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return "माइक शुरू नहीं हो पाया (AudioRecord init failed)। हो सकता है कोई दूसरा ऐप माइक इस्तेमाल कर रहा हो।"
        }
        var aec: AcousticEchoCanceler? = null
        var ns: NoiseSuppressor? = null
        var agc: AutomaticGainControl? = null
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                aec = AcousticEchoCanceler.create(rec.audioSessionId)
                aec?.setEnabled(true)
            }
        } catch (e: Exception) {
        }
        try {
            if (NoiseSuppressor.isAvailable()) {
                ns = NoiseSuppressor.create(rec.audioSessionId)
                ns?.setEnabled(true)
            }
        } catch (e: Exception) {
        }
        try {
            if (AutomaticGainControl.isAvailable()) {
                agc = AutomaticGainControl.create(rec.audioSessionId)
                agc?.setEnabled(true)
            }
        } catch (e: Exception) {
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            return "माइक चालू नहीं हो पाया।\nअसली कारण: ${e.javaClass.simpleName}: ${e.message}"
        }
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            try {
                rec.release()
            } catch (e: Exception) {
            }
            return "माइक किसी और ऐप (जैसे कॉल) के पास है, इसलिए अभी चालू नहीं हो पाया।"
        }
        running = true
        val t = Thread({ loop(rec, aec, ns, agc, l) }, "LiveMic")
        thread = t
        t.start()
        return null
    }

    fun stop() {
        running = false
        val t = thread
        thread = null
        if (t != null && t !== Thread.currentThread()) {
            try {
                t.join(500)
            } catch (e: InterruptedException) {
            }
        }
    }

    private fun rms(b: ShortArray): Double {
        var sum = 0.0
        for (v in b) sum += v.toDouble() * v.toDouble()
        return sqrt(sum / b.size)
    }

    private fun loop(
        rec: AudioRecord,
        aec: AcousticEchoCanceler?,
        ns: NoiseSuppressor?,
        agc: AutomaticGainControl?,
        l: Listener
    ) {
        val buf = ShortArray(FRAME)
        val preRoll = ArrayDeque<ShortArray>()
        val utter = ByteArrayOutputStream()
        var noise = 250.0
        var inSpeech = false
        var loud = 0
        var quiet = 0
        var voiced = 0
        var total = 0
        var deadFrames = 0
        try {
            while (running) {
                var got = 0
                while (got < FRAME && running) {
                    val n = rec.read(buf, got, FRAME - got)
                    if (n < 0) {
                        val code = n
                        running = false
                        main.post { l.onFatal("माइक से आवाज़ पढ़ने में दिक्कत आई (AudioRecord error code $code)।") }
                        return
                    }
                    if (n == 0) Thread.sleep(4)
                    got += n
                }
                if (!running) break

                val level = rms(buf)

                // Real microphones never give perfect silence. If they do for 6 seconds, the phone blocks the mic.
                if (level == 0.0) deadFrames++ else deadFrames = 0
                if (deadFrames > 300) {
                    running = false
                    main.post {
                        l.onFatal("माइक से सिर्फ़ ख़ामोशी आ रही है। कोई दूसरा ऐप माइक इस्तेमाल कर रहा है, या ऐप स्क्रीन से हट जाने पर फ़ोन ने माइक रोक दिया।")
                    }
                    return
                }

                val speaking = assistantSpeaking
                val floor = if (speaking) FLOOR_WHILE_ASSISTANT else FLOOR
                val threshold = max(floor, noise * if (speaking) 4.5 else 3.0)
                val isLoud = level > threshold

                if (!inSpeech) {
                    preRoll.addLast(buf.copyOf())
                    if (preRoll.size > PRE_ROLL_FRAMES) preRoll.removeFirst()
                    if (isLoud) {
                        loud++
                    } else {
                        loud = 0
                        noise = (noise * 0.95 + level * 0.05).coerceAtMost(1500.0)
                    }
                    val need = if (speaking) START_FRAMES_WHILE_ASSISTANT else START_FRAMES
                    if (loud >= need) {
                        inSpeech = true
                        quiet = 0
                        voiced = loud
                        total = preRoll.size
                        utter.reset()
                        for (f in preRoll) writeFrame(utter, f)
                        preRoll.clear()
                        main.post { if (running) l.onSpeechStart() }
                    }
                } else {
                    writeFrame(utter, buf)
                    total++
                    if (isLoud) {
                        quiet = 0
                        voiced++
                    } else {
                        quiet++
                    }
                    if (quiet >= END_SILENCE_FRAMES || total >= MAX_FRAMES) {
                        inSpeech = false
                        loud = 0
                        val keepQuiet = 14
                        val cut = max(0, quiet - keepQuiet) * FRAME * 2
                        val all = utter.toByteArray()
                        val pcm = all.copyOf(max(0, all.size - cut))
                        utter.reset()
                        if (voiced >= MIN_VOICED_FRAMES) {
                            val wav = toWav(pcm)
                            main.post { if (running) l.onUtterance(wav) }
                        } else {
                            main.post { if (running) l.onSpeechAborted() }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (running) {
                running = false
                val why = "${e.javaClass.simpleName}: ${e.message}"
                main.post { l.onFatal("माइक की रिकॉर्डिंग रुक गई।\nअसली कारण: $why") }
            }
        } finally {
            try {
                rec.stop()
            } catch (e: Exception) {
            }
            try {
                rec.release()
            } catch (e: Exception) {
            }
            try {
                aec?.release()
            } catch (e: Exception) {
            }
            try {
                ns?.release()
            } catch (e: Exception) {
            }
            try {
                agc?.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun writeFrame(out: ByteArrayOutputStream, f: ShortArray) {
        val b = ByteArray(f.size * 2)
        for (i in f.indices) {
            b[i * 2] = (f[i].toInt() and 0xFF).toByte()
            b[i * 2 + 1] = ((f[i].toInt() shr 8) and 0xFF).toByte()
        }
        out.write(b, 0, b.size)
    }

    private fun toWav(pcm: ByteArray): ByteArray {
        val h = ByteArray(44)
        fun i32(o: Int, v: Int) {
            h[o] = (v and 0xFF).toByte()
            h[o + 1] = ((v shr 8) and 0xFF).toByte()
            h[o + 2] = ((v shr 16) and 0xFF).toByte()
            h[o + 3] = ((v shr 24) and 0xFF).toByte()
        }
        fun i16(o: Int, v: Int) {
            h[o] = (v and 0xFF).toByte()
            h[o + 1] = ((v shr 8) and 0xFF).toByte()
        }
        "RIFF".forEachIndexed { i, c -> h[i] = c.code.toByte() }
        i32(4, 36 + pcm.size)
        "WAVEfmt ".forEachIndexed { i, c -> h[8 + i] = c.code.toByte() }
        i32(16, 16)
        i16(20, 1)
        i16(22, 1)
        i32(24, RATE)
        i32(28, RATE * 2)
        i16(32, 2)
        i16(34, 16)
        "data".forEachIndexed { i, c -> h[36 + i] = c.code.toByte() }
        i32(40, pcm.size)
        return h + pcm
    }
}
