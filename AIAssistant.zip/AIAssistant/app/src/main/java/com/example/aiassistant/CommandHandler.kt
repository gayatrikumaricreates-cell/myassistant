package com.example.aiassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

/** बोले गए वाक्य को समझकर काम करता है. reply() में वही बोला जाता है जो असिस्टेंट जवाब में कहेगा. */
class CommandHandler(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())

    private val fillers = setOf(
        "खोलो", "खोल", "दो", "पर", "चलाओ", "चला", "बजाओ", "बजा", "सर्च", "खोजो", "खोज",
        "करो", "कर", "search", "play", "open", "को", "का", "की", "के", "में", "मुझे",
        "जरा", "ज़रा", "प्लीज", "please", "ऐप", "app", "लगाओ", "लगा", "कॉल", "काल", "call",
        "फोन", "फ़ोन", "डायल", "से", "बात", "youtube", "यूट्यूब", "यूटयूब", "यू", "ट्यूब",
        "चालू", "दीजिए", "कीजिए", "खोलिए"
    )

    private val knownApps = listOf(
        listOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप", "व्हॉट्सएप") to "com.whatsapp",
        listOf("chrome", "क्रोम") to "com.android.chrome",
        listOf("instagram", "इंस्टाग्राम") to "com.instagram.android",
        listOf("facebook", "फेसबुक") to "com.facebook.katana",
        listOf("telegram", "टेलीग्राम") to "org.telegram.messenger",
        listOf("maps", "मैप्स", "नक्शा") to "com.google.android.apps.maps",
        listOf("gmail", "जीमेल") to "com.google.android.gm"
    )

    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }

    private fun clean(t: String) = t.split(Regex("\\s+"))
        .filter { it.isNotBlank() && it !in fillers }
        .joinToString(" ")

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun installed(pkg: String) = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (_: Exception) {
        false
    }

    private fun launch(pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        start(i)
        return true
    }

    fun handle(raw: String, reply: (String) -> Unit) {
        val t = raw.lowercase(Locale.ROOT).trim()
        try {
            when {
                has(t, "youtube", "यूट्यूब", "यूटयूब", "यू ट्यूब") -> youtube(t, reply)
                has(t, "कॉल", "काल", "call", "फोन", "फ़ोन", "डायल") -> call(t, reply)
                has(t, "कितने बजे", "समय", "टाइम", "time") -> time(reply)
                has(t, "खोल", "open", "चालू") -> openApp(t, reply)
                else -> askAi(raw, reply)
            }
        } catch (e: Exception) {
            reply("माफ़ कीजिए, ये काम नहीं हो पाया")
        }
    }

    // ---------- YouTube ----------
    private fun youtube(t: String, reply: (String) -> Unit) {
        val q = clean(t)
        if (q.isBlank()) {
            if (!launch("com.google.android.youtube")) {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            }
            reply("यूट्यूब खोल रहा हूँ")
        } else {
            val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
            val i = Intent(Intent.ACTION_VIEW, uri)
            if (installed("com.google.android.youtube")) i.setPackage("com.google.android.youtube")
            start(i)
            reply("यूट्यूब पर $q खोज रहा हूँ")
        }
    }

    // ---------- कॉल ----------
    private fun call(t: String, reply: (String) -> Unit) {
        val digits = t.filter { it.isDigit() }
        if (digits.length >= 5) {
            dial(digits, digits, reply)
            return
        }
        val name = clean(t)
        if (name.isBlank()) {
            reply("किसको कॉल लगाऊँ?")
            return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            reply("कॉन्टैक्ट देखने की अनुमति नहीं है")
            return
        }
        var found: Pair<String, String>? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { c ->
            if (c.moveToFirst()) found = c.getString(0) to c.getString(1)
        }
        val f = found
        if (f == null) {
            reply("$name नाम का कॉन्टैक्ट नहीं मिला")
        } else {
            dial(f.second, f.first, reply)
        }
    }

    private fun dial(number: String, label: String, reply: (String) -> Unit) {
        val uri = Uri.fromParts("tel", number, null)
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        start(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        reply("$label को कॉल लगा रहा हूँ")
    }

    // ---------- समय ----------
    private fun time(reply: (String) -> Unit) {
        val c = Calendar.getInstance()
        val h = (c.get(Calendar.HOUR) .let { if (it == 0) 12 else it })
        val m = c.get(Calendar.MINUTE)
        reply("अभी $h बजकर $m मिनट हुए हैं")
    }

    // ---------- ऐप खोलना ----------
    private fun openApp(t: String, reply: (String) -> Unit) {
        val n = clean(t)
        if (n.isBlank()) {
            reply("कौन सा ऐप खोलूँ?")
            return
        }
        if (has(n, "कैमरा", "camera")) {
            start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            reply("कैमरा खोल रहा हूँ")
            return
        }
        if (has(n, "सेटिंग", "settings")) {
            start(Intent(Settings.ACTION_SETTINGS))
            reply("सेटिंग खोल रहा हूँ")
            return
        }
        for ((keys, pkg) in knownApps) {
            if (keys.any { n.contains(it) } && launch(pkg)) {
                reply("${keys.first()} खोल रहा हूँ")
                return
            }
        }
        // इंस्टॉल किए गए ऐप्स के नाम में खोजना
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(n)
        }
        if (hit != null && launch(hit.activityInfo.packageName)) {
            reply("${hit.loadLabel(pm)} खोल रहा हूँ")
        } else {
            reply("$n ऐप नहीं मिला")
        }
    }

    // ---------- बाकी सब सवाल: Google Gemini (AI Studio की key) ----------
    private fun askAi(q: String, reply: (String) -> Unit) {
        val p = Prefs(ctx)
        val key = p.geminiKey
        if (key.isBlank()) {
            reply("ये काम मुझे अभी नहीं आता। सेटिंग में Google AI Studio की key डालिए, तो मैं हर सवाल का जवाब दे सकूँगा।")
            return
        }
        Thread {
            var answer: String
            try {
                val sys = "आप एक हिंदी वॉइस असिस्टेंट हैं। जवाब बहुत छोटा (अधिकतम 2-3 वाक्य), " +
                    "बोलचाल की सरल हिंदी में दें। कोई markdown या चिह्न न लगाएँ।"
                val body = JSONObject()
                    .put(
                        "systemInstruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))
                    )
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put("role", "user").put(
                                "parts", JSONArray().put(JSONObject().put("text", q))
                            )
                        )
                    )
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/${p.geminiModel}:generateContent"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("content-type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                answer = if (code in 200..299) {
                    JSONObject(text)
                        .getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0)
                        .getString("text").trim()
                } else {
                    "एआई से जवाब नहीं मिला, कोड $code"
                }
            } catch (e: Exception) {
                answer = "इंटरनेट या एआई में दिक्कत आ गई"
            }
            main.post { reply(answer) }
        }.start()
    }
}
