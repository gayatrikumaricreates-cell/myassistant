package com.example.aiassistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/** घूमता हुआ चमकदार गोला. active = true होने पर तेज़ घूमता और धड़कता है. */
class OrbView(context: Context) : View(context) {

    private var main = Color.parseColor("#EDB014")
    private var light = Color.parseColor("#F58A3C")
    private var dark = Color.parseColor("#6B2A3A")
    private var angle = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 9000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    var active: Boolean = false
        set(value) {
            field = value
            anim.duration = if (value) 2500L else 9000L
        }

    fun setColors(m: Int, l: Int, d: Int) {
        main = m; light = l; dark = d
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val pulse = if (active) 1f + 0.04f * sin(Math.toRadians(angle * 4.0)).toFloat() else 1f
        val r = min(width, height) / 2f * 0.62f * pulse

        // बाहरी चमक
        paint.shader = RadialGradient(
            cx, cy, r * 1.7f,
            intArrayOf(withAlpha(main, 110), withAlpha(main, 0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.7f, paint)

        // गोला
        paint.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.35f, r * 1.7f,
            intArrayOf(light, main, dark),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)

        // घूमती हुई परत (इसी से "घूमता हुआ" दिखता है)
        canvas.save()
        canvas.rotate(angle, cx, cy)
        paint.shader = SweepGradient(
            cx, cy,
            intArrayOf(0x00FFFFFF, 0x40FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x30000000, 0x00FFFFFF),
            floatArrayOf(0f, 0.15f, 0.35f, 0.6f, 0.8f, 1f)
        )
        canvas.drawCircle(cx, cy, r, paint)
        canvas.restore()

        // ऊपर-बाईं तरफ़ की चमक
        paint.shader = null
        paint.color = withAlpha(Color.WHITE, 150)
        canvas.save()
        canvas.rotate(-35f, cx - r * 0.4f, cy - r * 0.5f)
        canvas.drawOval(
            RectF(cx - r * 0.62f, cy - r * 0.62f, cx - r * 0.18f, cy - r * 0.42f),
            paint
        )
        canvas.restore()
    }
}
