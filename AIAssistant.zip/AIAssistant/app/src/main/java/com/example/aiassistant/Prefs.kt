package com.example.aiassistant

import android.content.Context

data class OrbTheme(
    val name: String,
    val main: String,
    val light: String,
    val dark: String,
    val bg: String
)

val THEMES = listOf(
    OrbTheme("सुनहरा", "#EDB014", "#F58A3C", "#6B2A3A", "#4A2F08"),
    OrbTheme("नीला", "#2E86F5", "#7FD3FF", "#101B5E", "#0A2347"),
    OrbTheme("हरा", "#2ECC71", "#B6F5A8", "#0B4A3A", "#0A3A22"),
    OrbTheme("बैंगनी", "#9B59F5", "#E2B8FF", "#2D1068", "#2A0F4A"),
    OrbTheme("लाल", "#F5413B", "#FFB0A0", "#5E0F1A", "#4A0D12")
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("assistant", Context.MODE_PRIVATE)

    var userName: String
        get() = sp.getString("user", "") ?: ""
        set(v) = sp.edit().putString("user", v).apply()

    var assistantName: String
        get() = sp.getString("assistant", "गायत्री") ?: "गायत्री"
        set(v) = sp.edit().putString("assistant", v).apply()

    var theme: Int
        get() = sp.getInt("theme", 0).coerceIn(0, THEMES.size - 1)
        set(v) = sp.edit().putInt("theme", v).apply()

    var picoKey: String
        get() = sp.getString("pico", "") ?: ""
        set(v) = sp.edit().putString("pico", v).apply()

    var geminiKey: String
        get() = sp.getString("gemini", "") ?: ""
        set(v) = sp.edit().putString("gemini", v).apply()

    var geminiModel: String
        get() = sp.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp.edit().putString("gemini_model", v).apply()

    var running: Boolean
        get() = sp.getBoolean("running", false)
        set(v) = sp.edit().putBoolean("running", v).apply()
}
