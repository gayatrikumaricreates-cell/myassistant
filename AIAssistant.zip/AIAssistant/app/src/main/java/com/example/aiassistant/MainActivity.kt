package com.example.aiassistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var micBtn: TextView
    private lateinit var nameChip: TextView

    private var setup = true
    private var askedRuntime = false
    private var askedOverlay = false
    private var askedBattery = false

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
        applyTheme()
    }

    override fun onResume() {
        super.onResume()
        updateMic()
        if (setup) continueSetup()
    }

    // ---------------- UI ----------------

    private fun circle(text: String, size: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = 22f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#33FFFFFF"))
            setStroke(dp(1), Color.parseColor("#44FFFFFF"))
        }
        minWidth = size
        minHeight = size
    }

    private fun buildUi() {
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        root = FrameLayout(this)

        orb = OrbView(this)
        root.addView(orb, FrameLayout.LayoutParams(dp(320), dp(320), Gravity.CENTER))

        val profileBtn = circle("👤", dp(52))
        profileBtn.setOnClickListener { settingsDialog() }
        root.addView(
            profileBtn,
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(20), dp(52), 0, 0)
            }
        )

        val themeBtn = circle("🎨", dp(52))
        themeBtn.setOnClickListener { themeDialog() }
        root.addView(
            themeBtn,
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(52), dp(20), 0)
            }
        )

        nameChip = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(10), dp(28), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(Color.parseColor("#33FFFFFF"))
                setStroke(dp(1), Color.parseColor("#44FFFFFF"))
            }
        }
        root.addView(
            nameChip,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { setMargins(0, dp(58), 0, 0) }
        )

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
            gravity = Gravity.CENTER
        }
        root.addView(
            status,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { setMargins(0, 0, 0, dp(150)) }
        )

        micBtn = circle("🔇", dp(80))
        micBtn.textSize = 28f
        micBtn.setOnClickListener { toggle() }
        root.addView(
            micBtn,
            FrameLayout.LayoutParams(dp(80), dp(80), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { setMargins(0, 0, 0, dp(50)) }
        )

        setContentView(root)
    }

    private fun applyTheme() {
        val t = THEMES[prefs.theme]
        orb.setColors(Color.parseColor(t.main), Color.parseColor(t.light), Color.parseColor(t.dark))
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor(t.bg), Color.BLACK)
        )
        nameChip.text = prefs.assistantName
        updateMic()
    }

    private fun updateMic() {
        val running = prefs.running
        micBtn.text = if (running) "🎤" else "🔇"
        status.text = if (running) "\"${prefs.assistantName}\" बोलकर जगाइए" else "माइक दबाकर शुरू करें"
        orb.active = running
    }

    // ---------------- चालू / बंद ----------------

    private fun toggle() {
        if (prefs.running) {
            stopService(Intent(this, WakeService::class.java))
            prefs.running = false
        } else {
            if (!permissionsOk()) {
                setup = true
                continueSetup()
                return
            }
            if (prefs.picoKey.isBlank()) {
                Toast.makeText(this, "पहले Picovoice AccessKey डालिए", Toast.LENGTH_LONG).show()
                settingsDialog()
                return
            }
            ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
            prefs.running = true
        }
        updateMic()
    }

    private fun restartServiceIfRunning() {
        if (prefs.running) {
            stopService(Intent(this, WakeService::class.java))
            ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
        }
    }

    // ---------------- अनुमतियाँ (एक-एक करके) ----------------

    private fun runtimePerms(): List<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    private fun missingRuntime() = runtimePerms().filter {
        ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
    }

    private fun permissionsOk() = missingRuntime().isEmpty() && Settings.canDrawOverlays(this)

    private fun continueSetup() {
        val missing = missingRuntime()
        if (missing.isNotEmpty() && !askedRuntime) {
            askedRuntime = true
            requestPermissions(missing.toTypedArray(), 1)
            return
        }
        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            Toast.makeText(
                this, "\"दूसरे ऐप्स के ऊपर दिखाएँ\" चालू कीजिए", Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        setup = false
        if (prefs.picoKey.isBlank()) settingsDialog()
    }

    // ---------------- डायलॉग ----------------

    private fun field(box: LinearLayout, hint: String, value: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine(true)
        }
        box.addView(e)
        return e
    }

    private fun settingsDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(10))
        }
        val userEt = field(box, "आपका नाम", prefs.userName)
        val asstEt = field(box, "असिस्टेंट का नाम (जैसे गायत्री)", prefs.assistantName)
        val picoEt = field(box, "Picovoice AccessKey", prefs.picoKey)
        val geminiEt = field(box, "Google AI Studio key (सवाल-जवाब के लिए)", prefs.geminiKey)
        val modelEt = field(box, "Gemini मॉडल का नाम", prefs.geminiModel)
        val pick = Button(this).apply {
            text = "वेक-वर्ड फ़ाइल (.ppn) चुनें"
            setOnClickListener {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }, 7
                )
            }
        }
        box.addView(pick)
        val hintTv = TextView(this).apply {
            text = "बिना .ppn फ़ाइल के ऐप \"Jarvis\" बोलने पर जागेगा।"
            textSize = 13f
            setPadding(0, dp(8), 0, 0)
        }
        box.addView(hintTv)

        AlertDialog.Builder(this)
            .setTitle("प्रोफ़ाइल और सेटिंग")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("सेव") { _, _ ->
                prefs.userName = userEt.text.toString().trim()
                prefs.assistantName = asstEt.text.toString().trim().ifBlank { "गायत्री" }
                prefs.picoKey = picoEt.text.toString().trim()
                prefs.geminiKey = geminiEt.text.toString().trim()
                prefs.geminiModel = modelEt.text.toString().trim().ifBlank { "gemini-2.5-flash" }
                applyTheme()
                restartServiceIfRunning()
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    private fun themeDialog() {
        AlertDialog.Builder(this)
            .setTitle("रंग चुनें")
            .setItems(THEMES.map { it.name }.toTypedArray()) { _, i ->
                prefs.theme = i
                applyTheme()
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    File(filesDir, "keyword.ppn").outputStream().use { out -> input.copyTo(out) }
                }
                Toast.makeText(this, "वेक-वर्ड फ़ाइल सेव हो गई", Toast.LENGTH_SHORT).show()
                restartServiceIfRunning()
            } catch (e: Exception) {
                Toast.makeText(this, "फ़ाइल सेव नहीं हुई: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
