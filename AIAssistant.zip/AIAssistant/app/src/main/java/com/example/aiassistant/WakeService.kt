package com.example.aiassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import androidx.core.app.ServiceCompat
import java.io.File
import java.util.Locale

/**
 * बैकग्राउंड में हमेशा चलने वाली सर्विस:
 * वेक-वर्ड सुनती है -> नीचे गोला-पैनल दिखाती है -> आपकी बात सुनती है -> काम करती है -> जवाब बोलती है.
 */
class WakeService : Service() {

    companion object {
        const val CH = "assistant"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var porcupine: PorcupineManager? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var overlay: OverlayController
    private lateinit var cmd: CommandHandler
    private lateinit var prefs: Prefs
    private var busy = false
    private var pendingDone: (() -> Unit)? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        overlay = OverlayController(this)
        cmd = CommandHandler(this)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = fireDone()

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = fireDone()
                    override fun onError(utteranceId: String?, errorCode: Int) = fireDone()
                })
                ttsReady = true
            }
        }
    }

    private fun fireDone() {
        handler.post {
            val d = pendingDone
            pendingDone = null
            d?.invoke()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "असिस्टेंट", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("असिस्टेंट चालू है")
            .setContentText("\"${prefs.assistantName}\" बोलकर जगाइए")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        startWake()
        prefs.running = true
        return START_STICKY
    }

    private fun startWake() {
        if (porcupine != null) return
        val key = prefs.picoKey
        if (key.isBlank()) {
            Toast.makeText(this, "पहले सेटिंग में Picovoice AccessKey डालिए", Toast.LENGTH_LONG).show()
            prefs.running = false
            stopSelf()
            return
        }
        try {
            val b = PorcupineManager.Builder()
                .setAccessKey(key)
                .setSensitivity(0.7f)
            val f = File(filesDir, "keyword.ppn")
            if (f.exists()) {
                b.setKeywordPath(f.absolutePath)
            } else {
                // अपनी .ppn फ़ाइल न हो तो शुरुआत के लिए "Jarvis" से जागेगा
                b.setKeyword(Porcupine.BuiltInKeyword.JARVIS)
            }
            porcupine = b.build(this, PorcupineManagerCallback { _ -> onWake() })
            porcupine?.start()
        } catch (e: Exception) {
            Toast.makeText(this, "वेक-वर्ड शुरू नहीं हुआ: ${e.message}", Toast.LENGTH_LONG).show()
            prefs.running = false
            stopSelf()
        }
    }

    private fun onWake() {
        handler.post {
            if (busy) return@post
            busy = true
            try {
                porcupine?.stop()
            } catch (_: Exception) {
            }
            if (Settings.canDrawOverlays(this)) overlay.show()
            val name = prefs.userName
            val greet = if (name.isBlank()) "हाँ, बोलिए, क्या काम करना है?"
            else "हाँ $name, बोलिए क्या काम करना है?"
            overlay.setText(greet)
            speak(greet) { listen() }
        }
    }

    private fun speak(text: String, done: () -> Unit) {
        if (!ttsReady) {
            done()
            return
        }
        pendingDone = done
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            overlay.setText("इस फ़ोन में आवाज़ पहचान उपलब्ध नहीं है")
            finish()
            return
        }
        overlay.setListening(true)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)

        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!p.isNullOrBlank()) overlay.setText("🗣 $p")
            }

            override fun onError(error: Int) {
                overlay.setText("सुनाई नहीं दिया, फिर से बुलाइए")
                finish()
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) {
                    overlay.setText("सुनाई नहीं दिया, फिर से बुलाइए")
                    finish()
                    return
                }
                overlay.setText("🗣 $text")
                overlay.setListening(false)
                cmd.handle(text) { reply ->
                    overlay.setText(reply)
                    speak(reply) { finish() }
                }
            }
        })
        recognizer = r
        r.startListening(intent)
    }

    private fun finish() {
        overlay.setListening(false)
        recognizer?.destroy()
        recognizer = null
        handler.postDelayed({
            overlay.hide()
            try {
                porcupine?.start()
            } catch (_: Exception) {
            }
            busy = false
        }, 700)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            porcupine?.stop()
            porcupine?.delete()
        } catch (_: Exception) {
        }
        porcupine = null
        overlay.hide()
        recognizer?.destroy()
        tts?.shutdown()
        prefs.running = false
        super.onDestroy()
    }
}
