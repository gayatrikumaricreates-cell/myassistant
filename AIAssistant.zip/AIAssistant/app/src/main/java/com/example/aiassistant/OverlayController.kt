package com.example.aiassistant

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** दूसरे ऐप्स के ऊपर, स्क्रीन के नीचे दिखने वाला गोला-पैनल (Siri जैसा). */
class OverlayController(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var orb: OrbView? = null
    private var text: TextView? = null

    private fun dp(x: Int) = (x * ctx.resources.displayMetrics.density).toInt()

    fun show() {
        if (root != null) return
        val t = THEMES[Prefs(ctx).theme]

        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(28))
            val c = dp(32).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101010"))
                cornerRadii = floatArrayOf(c, c, c, c, 0f, 0f, 0f, 0f)
            }
        }
        val o = OrbView(ctx).apply {
            setColors(Color.parseColor(t.main), Color.parseColor(t.light), Color.parseColor(t.dark))
            active = true
        }
        r.addView(o, LinearLayout.LayoutParams(dp(150), dp(150)))

        val tv = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
        }
        r.addView(
            tv,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }

        wm.addView(r, lp)
        root = r
        orb = o
        text = tv
    }

    fun setText(s: String) {
        text?.text = s
    }

    fun setListening(b: Boolean) {
        orb?.active = b
    }

    fun hide() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        orb = null
        text = null
    }
}
