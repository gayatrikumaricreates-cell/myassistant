import java.net.HttpURLConnection
import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The wake-name language file (about 40 MB) is downloaded while the app is BUILT and packed inside the APK,
// so nobody has to wait for a download later. If it cannot be downloaded, the build stops on purpose.
val voskAssets = layout.buildDirectory.dir("generated/voskAssets")
val fetchVosk by tasks.registering {
    val outDir = voskAssets.get().asFile
    outputs.dir(outDir)
    doLast {
        outDir.mkdirs()
        val f = File(outDir, "vosk-model-small-en-in-0.4.zip")
        if (f.exists() && f.length() > 20_000_000L) return@doLast
        var last = ""
        for (attempt in 1..4) {
            try {
                val conn = URL("https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip").openConnection() as HttpURLConnection
                conn.connectTimeout = 30000
                conn.readTimeout = 120000
                conn.instanceFollowRedirects = true
                if (conn.responseCode !in 200..299) throw GradleException("HTTP " + conn.responseCode)
                conn.inputStream.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                if (f.length() > 20_000_000L) return@doLast
                last = "the file was too small (" + f.length() + " bytes)"
            } catch (e: Exception) {
                last = e.toString()
            }
            Thread.sleep(3000)
        }
        f.delete()
        throw GradleException("WAKE MODEL DOWNLOAD FAILED: could not download vosk-model-small-en-in-0.4.zip from alphacephei.com. Reason: " + last)
    }
}

android {
    namespace = "com.gayatri.aiassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gayatri.priyaassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    sourceSets {
        getByName("main").assets.srcDir(files(voskAssets).builtBy(fetchVosk))
    }
    androidResources {
        noCompress += "zip"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchVosk) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // live talk (WebSocket)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // on-phone speech understanding for the "smooth" wake-name listening
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")

    // live camera
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
}
