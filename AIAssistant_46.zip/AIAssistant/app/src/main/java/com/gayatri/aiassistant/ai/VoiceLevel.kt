package com.gayatri.aiassistant.ai

/** How loud the assistant's voice is right now (0..1). The orb grows and shrinks with it while it speaks. */
object VoiceLevel {
    @Volatile
    var v: Float = 0f

    /** Sets the level from a block of 16-bit little-endian sound. */
    fun fromPcm(b: ByteArray, off: Int, len: Int) {
        var sum = 0.0
        var n = 0
        var i = off
        val end = off + len - 1
        while (i < end) {
            val s = (b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)
            sum += s.toDouble() * s
            n++
            i += 2
        }
        if (n == 0) return
        val rms = Math.sqrt(sum / n)
        v = (rms / 5000.0).coerceIn(0.0, 1.0).toFloat()
    }
}
