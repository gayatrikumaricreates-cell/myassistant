package com.gayatri.aiassistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.compose.ui.graphics.toArgb
import com.gayatri.aiassistant.MainActivity
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.ai.LiveEngine
import com.gayatri.aiassistant.ai.GeminiClient
import com.gayatri.aiassistant.ai.PhoneActions
import com.gayatri.aiassistant.ai.Prompts
import com.gayatri.aiassistant.ai.TalkMemory
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.ai.SpeechIn
import com.gayatri.aiassistant.data.AppSettings
import com.gayatri.aiassistant.data.Perms
import com.gayatri.aiassistant.data.Prefs
import com.gayatri.aiassistant.ui.orbColors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/** Small bridge between the screen and the background service. */
object AppBridge {
    @Volatile
    var foreground: Boolean = false

    @Volatile
    var onWake: (() -> Unit)? = null
}

object WakeMatcher {
    private val consonants = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h",
        'ळ' to "l"
    )
    private val vowels = mapOf(
        'अ' to "a", 'आ' to "a", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u", 'ए' to "e", 'ऐ' to "ai",
        'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऋ' to "ri"
    )
    private val matras = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u", 'े' to "e", 'ै' to "ai",
        'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ृ' to "ri"
    )

    /** Writes Hindi (Devanagari) words in Latin letters, roughly as they sound, so "प्रिया" matches "Priya". */
    private fun latin(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when {
                c == '\u094D' -> {} // halant: no vowel after the consonant
                c == 'ं' || c == 'ँ' || c == 'ः' -> {}
                c == '\u093C' -> {} // nukta
                consonants.containsKey(c) -> sb.append(consonants[c])
                vowels.containsKey(c) -> sb.append(vowels[c])
                matras.containsKey(c) -> sb.append(matras[c])
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun norm(s: String): String =
        latin(s.lowercase())
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** "maya" and "mayaa", "priya" and "pria": drop doubled letters and the soft h/y/w so sounds line up. */
    private fun skeleton(s: String): String =
        s.replace(Regex("(.)\\1+"), "$1").replace("aa", "a").replace("ee", "i").replace("oo", "u")

    private fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** Any word (Hindi or English) written in plain Latin letters, for fuzzy matching of names. */
    fun roman(s: String): String = skeleton(norm(s))

    /** Sound-alike form of a word and the edit distance between two such forms (used to pick words from the model). */
    fun skel(s: String): String = skeleton(s.lowercase())

    fun dist(a: String, b: String): Int = distance(a, b)

    fun matches(heard: List<String>, wakeName: String): Boolean {
        var core = norm(wakeName)
        for (p in listOf("hey ", "hi ", "hello ", "ok ", "he ", "hey")) {
            if (core.startsWith(p)) core = core.removePrefix(p).trim()
        }
        core = skeleton(core)
        if (core.length < 2) return false
        val tolerance = 1
        val coreCons = consonantsOf(core)
        return heard.any { h ->
            val n = skeleton(norm(h))
            val glued = n.replace(" ", "") // "or bit" is heard for "orbit"
            val words = n.split(" ").filter { it.isNotEmpty() }
            // a word and its neighbour glued together ("or"+"bit"), so a name split in two is still found
            val pairs = words.zipWithNext { x, y -> x + y }
            n.contains(core) ||
                (core.length >= 4 && glued.contains(core)) ||
                (words + pairs).any { w ->
                    (w.length >= 3 && core.length >= 3 && w[0] == core[0] && distance(w, core) <= tolerance) ||
                        // the same consonants in the same order sound alike ("orbit", "arbit", "urbit")
                        (coreCons.length >= 3 && w.length >= 4 && consonantsOf(w) == coreCons && kotlin.math.abs(w.length - core.length) <= 2 &&
                            (w[0] == core[0] || (w[0] in "aeiou" && core[0] in "aeiou")))
                }
        }
    }

    private fun consonantsOf(s: String): String = s.filter { it !in "aeiouyh " }
}

/**
 * Keeps listening for the wake name while the app is closed. When it hears the name it shows
 * the glowing ball at the bottom of the screen and starts a conversation.
 */
class WakeService : Service(), Engine.Callback {

    companion object {
        private const val CHANNEL = "wake_quiet"
        private const val NOTIF_ID = 7

        @Volatile
        var instance: WakeService? = null

        fun start(ctx: Context) {
            val i = Intent(ctx, WakeService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(ctx, i)
        }

        fun stopIt(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }

        fun pause() {
            instance?.setPaused(true)
        }

        fun resume() {
            instance?.setPaused(false)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var ears: SpeechIn
    private var engine: LiveEngine? = null
    private var overlay: OverlayView? = null
    private var paused = false
    private var inSession = false
    private var vosk: VoskWake? = null
    private var voskFailed = false
    private var muted = false
    private val restart = Runnable { wakeLoop() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        ears = SpeechIn(applicationContext)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Perms.micOk(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        paused = false
        voskFailed = false
        wakeLoop()
        return START_STICKY
    }

    /** The user swiped the app away: the conversation starts fresh next time. */
    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        TalkMemory.clear()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(restart)
        ears.stop()
        vosk?.stop(true)
        vosk = null
        muteBeep(false)
        engine?.stop()
        engine = null
        hideOverlay()
        scope.cancel()
        super.onDestroy()
    }

    // ---------- wake listening ----------

    fun setPaused(p: Boolean) {
        paused = p
        if (p) {
            handler.removeCallbacks(restart)
            ears.stop()
            vosk?.stop()
            muteBeep(false)
        } else if (!inSession) {
            handler.removeCallbacks(restart)
            handler.postDelayed(restart, 400)
        }
    }

    private fun schedule(ms: Long) {
        handler.removeCallbacks(restart)
        handler.postDelayed(restart, ms)
    }

    private val warmTick = object : Runnable {
        override fun run() {
            if (!paused && !inSession) LiveEngine.warm()
            handler.postDelayed(this, 120_000)
        }
    }

    private fun wakeLoop() {
        handler.removeCallbacks(restart)
        if (paused || inSession) return
        val s = Prefs(this).load()
        if (!s.handsFree) {
            stopSelf()
            return
        }
        prepareGreeting()
        LiveEngine.warm()
        handler.removeCallbacks(warmTick)
        handler.postDelayed(warmTick, 120_000)
        if (!voskFailed) {
            // smooth: reads the mic directly, never takes the phone's audio, no blinking, no volume change
            muteBeep(false)
            ears.stop()
            val v = vosk ?: VoskWake(applicationContext).also { vosk = it }
            v.start(
                "english",
                s.wakeName,
                onWake = { onWake() },
                onStatus = { msg -> toast(msg) },
                onFail = { msg ->
                    voskFailed = true
                    toast(msg)
                    schedule(300)
                },
                onHeard = { LiveEngine.warm() }, // any speech nearby: get the connection to Google ready
                learned = Prefs(this).learned(s.wakeName)
            )
            return
        }
        vosk?.stop()
        muteBeep(true)
        val lang = if (s.language == "english") "en-IN" else "hi-IN"
        ears.listen(
            lang,
            onPartial = { list -> if (WakeMatcher.matches(list, s.wakeName)) onWake() },
            onFinal = { list ->
                if (WakeMatcher.matches(list, s.wakeName)) onWake() else schedule(250)
            },
            onFail = { code ->
                when (code) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> schedule(1500)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> schedule(4000)
                    else -> schedule(350)
                }
            }
        )
    }

    private var lastHeardAt = 0L

    /** Shows in the notification what the phone just heard, so you can see the name is being listened for. */
    private fun showHeard(text: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastHeardAt < 700) return
        lastHeardAt = now
        try {
            val s = Prefs(this).load()
            val n = NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("${s.wakeName} is listening")
                .setContentText("Heard: \"${text.take(60)}\"")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setContentIntent(
                    PendingIntent.getActivity(
                        this, 0, Intent(this, MainActivity::class.java),
                        PendingIntent.FLAG_IMMUTABLE
                    )
                )
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    private fun toast(msg: String) {
        try {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    /** The recogniser beeps every time it starts; silence the notification/system streams while idle-listening. */
    private fun muteBeep(mute: Boolean) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (mute && !muted && am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
                am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
                muted = true
            } else if (!mute && muted) {
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
                am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
                muted = false
            }
        } catch (e: Exception) {
            muted = false
        }
    }

    // ---------- conversation after wake ----------

    private fun onWake() {
        if (inSession) return
        handler.removeCallbacks(restart)
        ears.stop()
        vosk?.stop()
        muteBeep(false)

        val bridge = AppBridge.onWake
        if (AppBridge.foreground && bridge != null) {
            // The app is open: let the app screen handle the conversation.
            bridge.invoke()
            return
        }

        inSession = true
        val s = Prefs(this).load()
        showOverlay(s)
        engine?.stop()
        val e = LiveEngine(applicationContext, scope, this)
        engine = e
        e.keepAlive = true
        val pcm = readGreeting(s)
        if (pcm != null) {
            // The greeting is already on the phone (in the chosen Gemini voice), so it speaks at once.
            playLocal(pcm)
            val ms = maxOf(0L, pcm.size / 48 - 100L) // 24 kHz, 16-bit; connect while the last words play
            handler.postDelayed({ if (inSession && engine === e) e.begin(null) }, ms)
        } else {
            // not saved yet: this first greeting is recorded as it plays, so every later wake is instant
            e.greetCapture = greetingFile(s)
            e.begin(Prompts.greeting(s))
        }
    }

    // ---------- instant greeting (made once, kept on the phone) ----------

    private fun greetingFile(s: AppSettings): java.io.File {
        val text = Prompts.greeting(s)
        val key = s.voice.replace(Regex("[^A-Za-z0-9]"), "_") + "_" + text.hashCode().toUInt().toString()
        return java.io.File(java.io.File(cacheDir, "greeting").apply { mkdirs() }, "$key.pcm")
    }

    private fun readGreeting(s: AppSettings): ByteArray? = try {
        val f = greetingFile(s)
        if (f.exists() && f.length() > 2000) f.readBytes() else null
    } catch (e: Exception) { null }

    @Volatile private var preparing = false

    /** Fetches the greeting once in the chosen voice and keeps it. Quiet on failure: the live greeting is the backup. */
    private fun prepareGreeting() {
        if (preparing) return
        val s = Prefs(this).load()
        if (s.apiKey.isBlank() || readGreeting(s) != null) return
        preparing = true
        Thread({
            try {
                val pcm = kotlinx.coroutines.runBlocking {
                    GeminiClient(PhoneActions(applicationContext)).tts(
                        s.apiKey, Prompts.greeting(s), Catalog.voice(s.voice).geminiVoice, ""
                    )
                }
                if (pcm.size > 2000) greetingFile(s).writeBytes(pcm)
            } catch (e: Throwable) {
            } finally {
                preparing = false
            }
        }, "GreetPrep").start()
    }

    private fun playLocal(raw: ByteArray) {
        // 0.2 s of silence first: the phone's speaker wakes up a moment late and would otherwise swallow the first word
        val pcm = ByteArray(9600 + raw.size)
        System.arraycopy(raw, 0, pcm, 9600, raw.size)
        Thread {
            try {
                val t = android.media.AudioTrack.Builder()
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        android.media.AudioFormat.Builder()
                            .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(24000)
                            .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(pcm.size)
                    .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                    .build()
                t.write(pcm, 0, pcm.size)
                t.play()
                Thread.sleep(pcm.size / 48 + 450L)
                t.release()
            } catch (e: Throwable) {
            }
        }.start()
    }

    private fun showOverlay(s: AppSettings) {
        if (!Settings.canDrawOverlays(this)) {
            try {
                android.widget.Toast.makeText(
                    applicationContext,
                    "To show the orb, allow 'Display over other apps' (Settings > Phone control).",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
            }
            return
        }
        try {
            val (a, b) = orbColors(s)
            val v = OverlayView(this, a.toArgb(), b.toArgb())
            v.setOnClickListener {
                engine?.stop()
                finishSession()
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            // centre of the ball sits on the middle of the 3 navigation buttons
            lp.y = (-16 * resources.displayMetrics.density).toInt()
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
        } catch (e: Exception) {
            overlay = null
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun finishSession() {
        if (!inSession) return
        inSession = false
        engine = null
        hideOverlay()
        if (!paused) schedule(500)
    }

    // ---------- Engine.Callback ----------

    override fun onState(s: Engine.State) {
        overlay?.setState(s)
    }

    override fun onHeard(text: String, final: Boolean) {
        // overlay shows only the ball, never text
    }

    override fun onReply(text: String) {
    }

    override fun onError(msg: String) {
        // The app is closed, so show the real reason as a message on the screen.
        try {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    override fun onSessionEnd() {
        handler.postDelayed({ finishSession() }, 900)
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Assistant", NotificationManager.IMPORTANCE_MIN)
        )
    }

    private fun buildNotification(): Notification {
        val s = Prefs(this).load()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(s.wakeName)
            .setSilent(true)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }
}
