package com.gayatri.aiassistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Makes any shape look like a physical, raised button: a domed face on a dark ledge.
 * When pressed, the face slides down smoothly onto the ledge, and springs back on release.
 */
@Composable
fun Modifier.raisedButton(
    shape: Shape,
    ledge: Dp = 5.dp,
    enabled: Boolean = true,
    onClick: () -> Unit
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val dy by animateDpAsState(
        targetValue = if (pressed) ledge - 1.dp else 0.dp,
        animationSpec = tween(durationMillis = 140, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)),
        label = "press"
    )
    return this
        .offset { IntOffset(0, dy.roundToPx()) }
        .drawBehind {
            val o = shape.createOutline(size, layoutDirection, this)
            val l = (ledge - dy).toPx()
            translate(0f, l + 6.dp.toPx()) { drawOutline(o, Color(0x66000000)) }
            translate(0f, l) { drawOutline(o, C.ledge) }
        }
        .clip(shape)
        .background(Brush.verticalGradient(listOf(C.faceTop, C.faceBottom)))
        .drawBehind {
            drawRect(
                brush = Brush.radialGradient(
                    listOf(C.teal.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(size.width / 2f, 0f),
                    radius = size.maxDimension * 0.75f
                )
            )
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color.Transparent, Color(0x55000000)),
                    startY = size.height * 0.6f,
                    endY = size.height
                )
            )
        }
        .border(1.dp, Brush.verticalGradient(listOf(C.teal.copy(alpha = 0.40f), C.teal.copy(alpha = 0.05f))), shape)
        .clickable(interactionSource = src, indication = null, enabled = enabled) { onClick() }
}

/** A rounded card. With [onClick] it becomes a raised, pressable button-card. */
@Composable
fun Glass(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    selected: Boolean = false,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    if (onClick != null) {
        val m = modifier
            .raisedButton(shape, 5.dp, onClick = onClick)
            .then(if (selected) Modifier.border(2.dp, C.teal, shape) else Modifier)
        Box(m) { content() }
    } else {
        val m = modifier
            .clip(shape)
            .background(CardBrush)
            .border(1.dp, C.cardBorder, shape)
        Box(m) { content() }
    }
}

@Composable
fun CircleButton(
    icon: ImageVector,
    size: Dp,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier
            .size(size)
            .raisedButton(CircleShape, if (size < 44.dp) 3.dp else 5.dp, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.46f))
    }
}

/** Screen with a back button and a title, used for Settings and its sub-screens. */
@Composable
fun SubScreen(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler(onBack = onBack)
    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBrush)
            .systemBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleButton(Icons.Rounded.ChevronLeft, 38.dp) { onBack() }
            Spacer(Modifier.width(12.dp))
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(top = 8.dp, start = 4.dp),
        color = C.sub,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp
    )
}

@Composable
fun AppField(
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    singleLine: Boolean = true,
    minLines: Int = 1,
    password: Boolean = false
) {
    TextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.fillMaxWidth(),
        singleLine = singleLine,
        minLines = minLines,
        placeholder = { Text(placeholder, color = C.sub.copy(alpha = 0.6f), fontSize = 13.sp) },
        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        shape = RoundedCornerShape(12.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = C.field,
            unfocusedContainerColor = C.field,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = C.teal,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        )
    )
}

fun timeLabel(t: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = t }
    val hm = SimpleDateFormat("HH:mm", Locale.ENGLISH).format(Date(t))
    val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
    now.add(Calendar.DAY_OF_YEAR, -1)
    val yesterday = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
    return when {
        sameDay -> "Today · $hm"
        yesterday -> "Yesterday · $hm"
        else -> SimpleDateFormat("EEE", Locale.ENGLISH).format(Date(t)) + " · " + hm
    }
}
