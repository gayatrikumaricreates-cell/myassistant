package com.gayatri.aiassistant.ai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.CalendarContract
import android.provider.CallLog
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.gayatri.aiassistant.service.WakeMatcher
import com.gayatri.aiassistant.service.NotificationStore
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.gayatri.aiassistant.service.AssistAccessibilityService
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * Every phone action the assistant can do. Each function returns a short English sentence that is
 * given back to Gemini, so the assistant can tell the user honestly what happened.
 */
class PhoneActions(private val ctx: Context) {

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun installed(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun run(name: String, a: JSONObject): String = when (name) {
        "make_call" -> if (a.optBoolean("confirmed", false)) makeCall(a.optString("contact")) else askFirst("call", a.optString("contact"), null)
        "answer_call" -> answerCall()
        "end_call" -> endCall()
        "send_sms" -> if (a.optBoolean("confirmed", false)) sendSms(a.optString("contact"), a.optString("message")) else askFirst("send an SMS to", a.optString("contact"), a.optString("message"))
        "send_whatsapp" -> if (a.optBoolean("confirmed", false)) sendWhatsApp(a.optString("contact"), a.optString("message")) else askFirst("send a WhatsApp message to", a.optString("contact"), a.optString("message"))
        "play_youtube" -> playYoutube(a.optString("query"))
        "set_timer" -> setTimer(a.optInt("seconds", 0), a.optString("label"))
        "set_alarm" -> setAlarm(a.optInt("hour", -1), a.optInt("minute", 0), a.optString("label"))
        "set_volume" -> setVolume(a.optString("direction"), if (a.has("level")) a.optInt("level") else -1)
        "flashlight" -> flashlight(a.optBoolean("on", true))
        "open_app" -> openApp(a.optString("app_name"))
        "open_settings_panel" -> panel(a.optString("kind"))
        "navigate" -> navigate(a.optString("place"))
        "search_web" -> searchWeb(a.optString("query"))
        "set_brightness" -> setBrightness(a.optInt("level", -1))
        "read_sms" -> readSms(a.optString("query"), a.optInt("limit", 5))
        "read_call_log" -> readCalls(a.optString("kind"), a.optInt("limit", 5))
        "contact_info" -> contactInfo(a.optString("name"))
        "get_battery" -> battery()
        "media_control" -> media(a.optString("action"))
        "add_calendar_event" -> addEvent(a.optString("title"), a.optString("date"), a.optString("time"), a.optInt("duration_minutes", 60))
        "read_notifications" -> readNotifications(a.optInt("limit", 6))
        "screen_read" -> screenDo { it.readScreen() }
        "screen_tap" -> screenDo { it.tapText(a.optString("text")) }
        "screen_scroll" -> screenDo { it.scroll(a.optString("direction"), a.optString("amount"), a.optInt("times", 1)) }
        "screen_type" -> screenDo { it.typeText(a.optString("text")) }
        "screen_key" -> screenDo { it.key(a.optString("key")) }
        else -> "Unknown tool: $name"
    }

    // ---------- contacts ----------

    private fun resolve(c: String): Pair<String, String>? {
        val text = c.trim()
        if (text.isEmpty()) return null
        val digits = text.count { it.isDigit() }
        if (digits >= 5 && text.none { it.isLetter() }) {
            return text to text.filter { it.isDigit() || it == '+' }
        }
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val list = ArrayList<Pair<String, String>>()
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$text%"),
            null
        )
        cur?.use {
            while (it.moveToNext()) {
                list.add((it.getString(0) ?: "") to (it.getString(1) ?: ""))
            }
        }
        return list.firstOrNull { it.first.equals(text, ignoreCase = true) } ?: list.firstOrNull()
    }

    /** Nothing is dialled or sent yet: the assistant must read this back to the user and get a clear yes first. */
    private fun askFirst(what: String, contact: String, message: String?): String {
        val r = resolve(contact) ?: return notFound
        val spaced = r.second.filter { it.isDigit() || it == '+' }.toList().joinToString(" ")
        val msg = if (message != null) " The message is: \"$message\"." else ""
        return "NOT DONE YET. You are about to $what ${r.first}, number $spaced.$msg Now say this out loud to the user: the name, the number read slowly digit by digit${if (message != null) ", and the message" else ""}. Then ask \"Should I go ahead?\" and wait. Only if the user clearly says yes, call the same tool again with the same arguments and confirmed=true. If they correct something, use the corrected value and confirm again."
    }

    private val notFound =
        "Contact not found (or contacts permission is missing). Retry once with the English spelling of the name, or ask the user for the number."

    // ---------- calls ----------

    @SuppressLint("MissingPermission")
    private fun makeCall(c: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return "Failed: the phone-call permission is not granted."
        val (nm, num) = resolve(c) ?: return notFound
        go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        return "Calling $nm now."
    }

    @SuppressLint("MissingPermission")
    private fun answerCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "Failed: permission to answer calls is not granted."
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        tm.acceptRingingCall()
        return "Answered the ringing call."
    }

    @SuppressLint("MissingPermission")
    private fun endCall(): String {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "Failed: permission to end calls is not granted."
        if (Build.VERSION.SDK_INT < 28) return "Failed: ending calls needs Android 9 or newer."
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val ok = tm.endCall()
        return if (ok) "Call ended." else "There was no active call to end."
    }

    // ---------- messages ----------

    private fun sendSms(c: String, msg: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return "Failed: the SMS permission is not granted."
        if (msg.isBlank()) return "Failed: the message text is empty."
        val (nm, num) = resolve(c) ?: return notFound
        @Suppress("DEPRECATION")
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
        return "SMS sent to $nm."
    }

    private fun sendWhatsApp(c: String, msg: String): String {
        val (nm, num) = resolve(c) ?: return notFound
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(it) }
            ?: return "Failed: WhatsApp is not installed."
        var d = num.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
        if (d.length == 10) d = "91$d"
        val uri = Uri.parse("https://wa.me/$d?text=" + Uri.encode(msg))
        AssistAccessibilityService.pendingWhatsAppSendUntil = System.currentTimeMillis() + 15000
        go(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
        return if (AssistAccessibilityService.instance != null) {
            "WhatsApp chat with $nm opened and the send button is being pressed automatically."
        } else {
            "WhatsApp chat with $nm opened with the message typed, but the user must press send because accessibility access is off."
        }
    }

    // ---------- media / device ----------

    private fun playYoutube(q: String): String {
        if (q.isBlank()) return "Failed: nothing to search for."
        AssistAccessibilityService.pendingYoutubePlayUntil = System.currentTimeMillis() + 20000
        try {
            go(
                Intent(Intent.ACTION_SEARCH)
                    .setPackage("com.google.android.youtube")
                    .putExtra("query", q)
            )
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        }
        return if (AssistAccessibilityService.instance != null) {
            "YouTube search for '$q' opened and the first video is being played."
        } else {
            "YouTube search for '$q' opened, but the user has to tap a video because accessibility access is off."
        }
    }

    private fun setTimer(seconds: Int, label: String): String {
        if (seconds <= 0) return "Failed: the timer length is missing."
        go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Timer set for $seconds seconds."
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23) return "Failed: the alarm hour is missing."
        go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Alarm set for %02d:%02d.".format(hour, minute)
    }

    private fun setVolume(direction: String, level: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        when {
            level >= 0 -> am.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                (max * level / 100.0).roundToInt().coerceIn(0, max),
                AudioManager.FLAG_SHOW_UI
            )
            direction == "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            direction == "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            direction == "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            direction == "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
            else -> return "Failed: say whether the volume should go up, down, mute, max, or give a level from 0 to 100."
        }
        return "Media volume is now ${am.getStreamVolume(AudioManager.STREAM_MUSIC)} out of $max."
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Failed: this phone has no flashlight."
        cm.setTorchMode(id, on)
        return if (on) "Flashlight is on." else "Flashlight is off."
    }

    // ---------- opening any app ----------

    private val knownApps: Map<String, List<String>> = mapOf(
        "gemini" to listOf("com.google.android.apps.bard"),
        "claude" to listOf("com.anthropic.claude"),
        "chatgpt" to listOf("com.openai.chatgpt"),
        "hotstar" to listOf("in.startv.hotstar", "in.startv.hotstar.dplus"),
        "jiohotstar" to listOf("in.startv.hotstar", "in.startv.hotstar.dplus"),
        "instagram" to listOf("com.instagram.android"),
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "youtube" to listOf("com.google.android.youtube"),
        "facebook" to listOf("com.facebook.katana"),
        "telegram" to listOf("org.telegram.messenger"),
        "snapchat" to listOf("com.snapchat.android"),
        "spotify" to listOf("com.spotify.music"),
        "netflix" to listOf("com.netflix.mediaclient"),
        "amazon" to listOf("in.amazon.mShop.android.shopping"),
        "flipkart" to listOf("com.flipkart.android"),
        "meesho" to listOf("com.meesho.supply"),
        "paytm" to listOf("net.one97.paytm"),
        "phonepe" to listOf("com.phonepe.app"),
        "gpay" to listOf("com.google.android.apps.nbu.paisa.user"),
        "googlepay" to listOf("com.google.android.apps.nbu.paisa.user"),
        "maps" to listOf("com.google.android.apps.maps"),
        "chrome" to listOf("com.android.chrome"),
        "gmail" to listOf("com.google.android.gm"),
        "photos" to listOf("com.google.android.apps.photos"),
        "messages" to listOf("com.google.android.apps.messaging"),
        "deepseek" to listOf("com.deepseek.chat"),
        "linkedin" to listOf("com.linkedin.android"),
        "pinterest" to listOf("com.pinterest"),
        "canva" to listOf("com.canva.editor")
    )

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private class AppCand(val label: String, val key: String, val pkg: String)

    private fun openApp(name: String): String {
        val raw = name.trim()
        if (raw.isEmpty()) return "Failed: no app name given."
        val pm = ctx.packageManager
        val q = WakeMatcher.roman(raw).replace(" ", "")
        val apps = try {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        } catch (e: Exception) {
            emptyList()
        }
        val cands = apps.map {
            val l = it.loadLabel(pm).toString()
            AppCand(l, WakeMatcher.roman(l).replace(" ", ""), it.activityInfo.packageName)
        }
        var best: AppCand? = cands.firstOrNull { it.key == q }
        if (best == null && q.length >= 3) {
            best = cands.firstOrNull { it.key.length >= 3 && (it.key.contains(q) || (q.length >= 4 && q.contains(it.key))) }
        }
        if (best == null && q.length >= 3) {
            var bestD = Int.MAX_VALUE
            for (c in cands) {
                if (c.key.length < 3) continue
                val d = lev(c.key, q)
                if (d <= maxOf(1, q.length / 4) && d < bestD) {
                    bestD = d
                    best = c
                }
            }
        }
        if (best == null && q.length >= 4) best = cands.firstOrNull { it.pkg.lowercase().contains(q) }
        val found = best
        if (found != null) {
            val li = pm.getLaunchIntentForPackage(found.pkg)
            if (li != null) {
                go(li)
                return "Opened ${found.label}."
            }
        }
        for ((k, pkgs) in knownApps) {
            if (k == q || (q.length >= 4 && (k.contains(q) || q.contains(k)))) {
                for (p in pkgs) {
                    val li = try {
                        pm.getLaunchIntentForPackage(p)
                    } catch (e: Exception) {
                        null
                    }
                    if (li != null) {
                        go(li)
                        return "Opened $k."
                    }
                }
            }
        }
        if (cands.size < 8) {
            return "Failed: this phone is hiding its list of installed apps from the assistant, and '$raw' could not be opened. Tell the user to open App info > Permissions of this assistant and allow 'Installed apps' (Xiaomi: 'Get installed apps list'), then ask again."
        }
        val sample = cands.map { it.label }.distinct().sorted().take(70).joinToString(", ")
        return "Failed: no installed app looks like '$raw'. Installed apps include: $sample. If one of these matches, retry with its exact name; otherwise tell the user the app is not installed."
    }

    // ---------- messages, calls, contacts ----------

    private fun fmt(t: Long): String = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH).format(Date(t))

    private fun nameFor(number: String): String {
        if (number.isBlank() || !has(Manifest.permission.READ_CONTACTS)) return number
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: number
        } catch (e: Exception) {
            number
        }
    }

    private fun readSms(query: String, limit: Int): String {
        if (!has(Manifest.permission.READ_SMS)) {
            return needPerm("read text messages", "Read SMS / Messages")
        }
        val q = query.trim().lowercase()
        val numQ = if (q.isNotEmpty()) resolve(query)?.second?.filter { it.isDigit() }?.takeLast(10) else null
        val max = limit.coerceIn(1, 8)
        val out = ArrayList<String>()
        val cur = try {
            ctx.contentResolver.query(
                Uri.parse("content://sms/inbox"),
                arrayOf("address", "body", "date"),
                null, null, "date DESC"
            )
        } catch (e: Exception) {
            null
        }
        if (cur == null) return needPerm("read text messages", "Read SMS / Messages (on Xiaomi also under Other permissions)")
        cur.use {
            var scanned = 0
            while (it.moveToNext() && out.size < max && scanned < 1500) {
                scanned++
                val addr = it.getString(0) ?: ""
                val body = it.getString(1) ?: ""
                val date = it.getLong(2)
                val ok = q.isEmpty() ||
                    addr.lowercase().contains(q) ||
                    body.lowercase().contains(q) ||
                    (numQ != null && numQ.length >= 6 && addr.filter { c -> c.isDigit() }.endsWith(numQ))
                if (ok) out.add("From ${nameFor(addr)} on ${fmt(date)}: ${body.take(240)}")
            }
        }
        return if (out.isEmpty()) "No matching text messages were found." else out.joinToString("\n")
    }

    private fun readCalls(kind: String, limit: Int): String {
        if (!has(Manifest.permission.READ_CALL_LOG)) {
            return needPerm("read the call history", "Call logs / Phone")
        }
        val missedOnly = kind.lowercase().contains("miss")
        val max = limit.coerceIn(1, 10)
        val out = ArrayList<String>()
        val cur = try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )
        } catch (e: Exception) {
            null
        }
        if (cur == null) return "Failed: could not open the call history."
        cur.use {
            var scanned = 0
            while (it.moveToNext() && out.size < max && scanned < 300) {
                scanned++
                val num = it.getString(0) ?: ""
                val cached = it.getString(1)
                val type = it.getInt(2)
                if (missedOnly && type != CallLog.Calls.MISSED_TYPE) continue
                val kindName = when (type) {
                    CallLog.Calls.INCOMING_TYPE -> "incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                    CallLog.Calls.MISSED_TYPE -> "missed"
                    else -> "other"
                }
                val who = if (!cached.isNullOrBlank()) cached else nameFor(num).ifBlank { "unknown number" }
                out.add("$kindName call, $who, ${fmt(it.getLong(3))}")
            }
        }
        return if (out.isEmpty()) "No such calls found." else out.joinToString("\n")
    }

    private fun contactInfo(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return "Failed: contacts permission is not granted."
        val r = resolve(name) ?: return notFound
        return "${r.first}: ${r.second}"
    }

    // ---------- phone state ----------

    private fun battery(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Failed: could not read the battery."
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return "Battery is $pct percent and ${if (charging) "charging" else "not charging"}."
    }

    private fun media(action: String): String {
        val a = action.lowercase()
        val code = when {
            a.contains("next") -> KeyEvent.KEYCODE_MEDIA_NEXT
            a.contains("prev") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            a.contains("stop") -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Sent the media key: $a."
    }

    private fun addEvent(title: String, date: String, time: String, minutes: Int): String {
        val parsed = try {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).parse("${date.trim()} ${time.trim()}")
        } catch (e: Exception) {
            null
        }
        if (parsed == null) return "Failed: give the date as YYYY-MM-DD and the time as HH:MM in 24-hour format."
        val start = parsed.time
        val i = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title.ifBlank { "Reminder" })
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + maxOf(minutes, 5) * 60_000L)
        go(i)
        return "Opened the calendar with the event filled in. The user only has to tap Save."
    }

    private fun readNotifications(limit: Int): String {
        if (!NotificationStore.connected) {
            go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return "Failed: notification access is off. I opened the screen; the user must switch on 'AI Assistant' there, then ask again."
        }
        val list = NotificationStore.recent(limit.coerceIn(1, 10))
        return if (list.isEmpty()) "There are no recent notifications." else list.joinToString("\n")
    }

    // ---------- screen control (accessibility) ----------

    private fun screenDo(f: (AssistAccessibilityService) -> String): String {
        val svc = AssistAccessibilityService.instance
            ?: return accessibilityOff()
        return try {
            f(svc)
        } catch (e: Exception) {
            "Failed: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
        }
    }

    /** Opens this app's permission page and tells the assistant exactly what to say, once. */
    private fun needPerm(what: String, label: String): String {
        try {
            go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        } catch (e: Exception) {
        }
        return "Failed: the phone is not letting this app $what. I have opened the app's permission page. Tell the user ONCE, briefly: open Permissions and allow '$label', then ask again."
    }

    private fun accessibilityOff(): String {
        val stuck = com.gayatri.aiassistant.data.Perms.accessibilityOn(ctx)
        try {
            go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
        }
        return if (stuck) {
            "Failed: Android shows the 'AI Assistant' accessibility switch as ON, but the phone has stopped the service (it is stuck). I have opened the Accessibility page. Tell the user ONCE, briefly: switch 'AI Assistant' OFF and then ON again, then ask again. Do not say that it is not enabled."
        } else {
            "Failed: the accessibility service 'AI Assistant' is not switched on. I have opened the Accessibility page. Tell the user ONCE, briefly: find 'AI Assistant' in the list and switch it on."
        }
    }

    private fun panel(kind: String): String {
        val k = kind.lowercase()
        val i = when {
            k.contains("blue") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            k.contains("volume") && Build.VERSION.SDK_INT >= 29 -> Intent(Settings.Panel.ACTION_VOLUME)
            Build.VERSION.SDK_INT >= 29 -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            else -> Intent(Settings.ACTION_WIFI_SETTINGS)
        }
        go(i)
        return "Opened the settings panel. Android does not let apps switch Wi-Fi or Bluetooth on or off by themselves, so the user must tap the toggle."
    }

    private fun setBrightness(level: Int): String {
        if (level !in 0..100) return "Failed: give a brightness level from 0 to 100."
        if (!Settings.System.canWrite(ctx)) {
            go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "Failed: the user must first allow 'Modify system settings' for this app on the screen that just opened, then ask again."
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * level / 100.0).roundToInt().coerceIn(1, 255))
        return "Brightness set to $level percent."
    }

    private fun searchWeb(q: String): String {
        if (q.isBlank()) return "Failed: nothing to search for."
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Opened a Google search for '$q' in the browser."
    }

    private fun navigate(place: String): String {
        if (place.isBlank()) return "Failed: no destination given."
        try {
            go(
                Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
                    .setPackage("com.google.android.apps.maps")
            )
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
        }
        return "Navigation to $place opened."
    }
}
