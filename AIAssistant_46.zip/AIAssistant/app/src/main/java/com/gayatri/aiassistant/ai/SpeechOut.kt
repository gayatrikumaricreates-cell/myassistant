package com.gayatri.aiassistant.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.gayatri.aiassistant.data.Catalog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Speaks text with a natural Gemini voice. If Gemini voice is not possible (no key, no internet),
 * it falls back to the phone's own Hindi voice so the assistant never goes silent.
 */
class SpeechOut(private val ctx: Context, private val gemini: GeminiClient) {

    private var job: Job? = null
    private var track: AudioTrack? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    /** Called with the real reason when the Gemini voice could not be used and the phone's own voice speaks instead. */
    var onNotice: ((String) -> Unit)? = null

    @Volatile
    private var voiceBlockedUntil = 0L
    private var lastNoticeAt = 0L

    fun speak(
        scope: CoroutineScope,
        text: String,
        voiceId: String,
        stylePrefix: String,
        apiKey: String,
        onDone: () -> Unit
    ) {
        stop()
        val clean = text.replace(Regex("[*#_`~>]"), "").trim()
        if (clean.isEmpty()) {
            onDone()
            return
        }
        job = scope.launch {
            try {
                val chunks = split(clean)
                val gv = Catalog.voice(voiceId).geminiVoice
                var spoken = 0
                if (apiKey.isNotBlank() && System.currentTimeMillis() >= voiceBlockedUntil) {
                    try {
                        supervisorScope {
                            var next: Deferred<ByteArray>? =
                                async { gemini.tts(apiKey, chunks[0], gv, stylePrefix) }
                            for (i in chunks.indices) {
                                val pcm = next!!.await()
                                next = if (i + 1 < chunks.size) {
                                    async { gemini.tts(apiKey, chunks[i + 1], gv, stylePrefix) }
                                } else null
                                play(pcm)
                                spoken = i + 1
                            }
                        }
                    } catch (e: GeminiError) {
                        // The Gemini voice failed: remember why, rest it for a while, and use the phone's own voice.
                        val rest = if (e.code == 429) maxOf(e.retryAfterMs, 20000L) else 8000L
                        voiceBlockedUntil = System.currentTimeMillis() + rest
                        val now = System.currentTimeMillis()
                        if (now - lastNoticeAt > 45000) {
                            lastNoticeAt = now
                            onNotice?.invoke("The natural Gemini voice could not play, so the phone's own voice is used for now.\n" + e.userMessage)
                        }
                    }
                }
                if (spoken < chunks.size) {
                    fallbackSpeak(chunks.drop(spoken).joinToString(" "))
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                releaseTrack()
            }
            onDone()
        }
    }

    /**
     * Plays a short voice sample. Each sample is fetched from Gemini only once and then kept on the phone,
     * so listening again costs nothing and never hits the free daily limit.
     */
    fun preview(scope: CoroutineScope, text: String, voiceId: String, apiKey: String) {
        stop()
        job = scope.launch {
            try {
                val f = java.io.File(
                    java.io.File(ctx.cacheDir, "voice_samples").apply { mkdirs() },
                    voiceId.replace(Regex("[^A-Za-z0-9_]"), "_") + "_" + (text.hashCode().toUInt().toString()) + ".pcm"
                )
                if (f.exists() && f.length() > 2000) {
                    play(f.readBytes())
                } else if (apiKey.isBlank()) {
                    onNotice?.invoke("First add your Gemini API key in Profile.")
                } else {
                    try {
                        val pcm = withContext(Dispatchers.IO) { gemini.tts(apiKey, text, Catalog.voice(voiceId).geminiVoice, "") }
                        if (pcm.isNotEmpty()) {
                            try { f.writeBytes(pcm) } catch (e: Exception) { }
                            play(pcm)
                        }
                    } catch (e: GeminiError) {
                        onNotice?.invoke(
                            if (e.code == 429) "The free Gemini key has reached its limit for voice samples for now. Voices still work normally in conversation. Each sample is saved after it plays once, so try this one again a little later."
                            else e.userMessage
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                releaseTrack()
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        releaseTrack()
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
    }

    private fun releaseTrack() {
        val t = track
        track = null
        if (t != null) {
            try {
                t.stop()
            } catch (e: Exception) {
            }
            try {
                t.release()
            } catch (e: Exception) {
            }
        }
    }

    private suspend fun play(pcm: ByteArray) = withContext(Dispatchers.IO) {
        if (pcm.isEmpty()) return@withContext
        val frames = pcm.size / 2
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        t.write(pcm, 0, pcm.size)
        t.play()
        while (isActive && t.playbackHeadPosition < frames - 120) {
            delay(40)
        }
        delay(120)
        try {
            t.stop()
        } catch (e: Exception) {
        }
        try {
            t.release()
        } catch (e: Exception) {
        }
        if (track === t) track = null
    }

    private suspend fun ensureTts(): TextToSpeech? = suspendCancellableCoroutine { cont ->
        val existing = tts
        if (existing != null && ttsReady) {
            cont.resume(existing)
        } else {
            var holder: TextToSpeech? = null
            holder = TextToSpeech(ctx) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    holder?.language = Locale("hi", "IN")
                    tts = holder
                    ttsReady = true
                    if (cont.isActive) cont.resume(holder)
                } else {
                    if (cont.isActive) cont.resume(null)
                }
            }
        }
    }

    private suspend fun fallbackSpeak(text: String) {
        val engine = ensureTts() ?: return
        suspendCancellableCoroutine<Unit> { cont ->
            val id = "u" + System.nanoTime()
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (cont.isActive) cont.resume(Unit)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (cont.isActive) cont.resume(Unit)
                }
            })
            cont.invokeOnCancellation {
                try {
                    engine.stop()
                } catch (e: Exception) {
                }
            }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    private fun split(t: String): List<String> {
        val parts = t.split(Regex("(?<=[।.!?\\n])\\s*")).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (p in parts) {
            if (cur.length + p.length > 420 && cur.isNotEmpty()) {
                out.add(cur.toString().trim())
                cur = StringBuilder()
            }
            cur.append(p).append(' ')
        }
        if (cur.isNotBlank()) out.add(cur.toString().trim())
        return if (out.isEmpty()) listOf(t) else out
    }
}
