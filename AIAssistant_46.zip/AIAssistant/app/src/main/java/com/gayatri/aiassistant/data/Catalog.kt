package com.gayatri.aiassistant.data

data class VoiceOption(
    val id: String,
    val desc: String,
    val traits: String,
    val female: Boolean,
    val geminiVoice: String,
    val persona: String = "",
    val sample: String = ""
)

data class StyleOption(
    val key: String,
    val label: String,
    val prompt: String,
    val ttsPrefix: String
)

data class LanguageOption(
    val key: String,
    val label: String,
    val prompt: String
)

object Catalog {
    val voices = listOf(
        VoiceOption("Aria", "Warm & friendly", "Warm · Round", true, "Sulafat",
            "",
            "हाय{user}, मैं Aria हूँ। बताइए, आज मैं आपकी क्या मदद करूँ? हा हा, मुझे तो आपसे बात करके मज़ा आता है।"),
        VoiceOption("Meera", "Soft & gentle", "Soft · Airy", true, "Achernar",
            "",
            "नमस्ते{user}... मैं Meera हूँ। आराम से बात कीजिए, मैं यहीं हूँ, सब सुन रही हूँ।"),
        VoiceOption("Kavya", "Bright & cheerful", "Bright · Clear", true, "Laomedeia",
            "",
            "अरे वाह{user}! मैं Kavya हूँ! हे हे, चलिए आज कुछ मज़ेदार करते हैं, बोलिए बोलिए!"),
        VoiceOption("Nova", "Mature & confident", "Low · Polished", true, "Gacrux",
            "",
            "नमस्कार{user}। मैं Nova हूँ। आप जो भी काम बताएँगे, मैं उसे सलीक़े से कर दूँगी।"),
        VoiceOption("Siya", "Young & light", "Light · Youthful", true, "Leda",
            "",
            "हेलो हेलो{user}! मैं Siya हूँ। हम्म, आज क्या शरारत करनी है? हे हे हे!"),
        VoiceOption("Arjun", "Deep & powerful", "Deep · Gravelly", false, "Algenib",
            "",
            "नमस्ते{user}। मैं Arjun हूँ। हुक्म कीजिए, काम हो जाएगा।"),
        VoiceOption("Dev", "Friendly & easygoing", "Casual · Natural", false, "Achird",
            "",
            "हाय{user}, मैं Dev हूँ। अरे यार, बताइए क्या चल रहा है? आराम से बात करते हैं।"),
        VoiceOption("Rohan", "Young & clear", "Young · Clear", false, "Puck",
            "",
            "हे{user}! मैं Rohan हूँ! चलो चलो, जल्दी बताओ क्या करना है, मैं तैयार हूँ!"),
        VoiceOption("Kabir", "Smooth & calm", "Smooth · Calm", false, "Charon",
            "",
            "नमस्ते{user}... मैं Kabir हूँ। बैठिए, आराम से बात करते हैं। हर बात की अपनी एक कहानी होती है।"),
        VoiceOption("Leo", "Expressive & warm", "Expressive · Warm", false, "Fenrir",
            "",
            "ओए{user}! मैं Leo हूँ! हा हा हा, तैयार हो जाइए, आज तो हँसी का तूफ़ान आने वाला है!")
    )

    fun voice(id: String): VoiceOption = voices.firstOrNull { it.id == id } ?: voices[0]

    val languages = listOf(
        LanguageOption(
            "mix", "Hindi + English mix",
            "Reply in natural Hinglish: write Hindi in Devanagari script and keep common English words in English letters, the way people really talk. Match the language the user used."
        ),
        LanguageOption(
            "hindi", "Only Hindi",
            "Reply only in simple spoken Hindi written in Devanagari script."
        ),
        LanguageOption(
            "english", "Only English",
            "Reply only in simple spoken English."
        )
    )

    fun language(key: String): LanguageOption = languages.firstOrNull { it.key == key } ?: languages[0]

    val styles = listOf(
        StyleOption(
            "friendly", "Friendly, expressive, laughs",
            "Be like a warm, close friend: expressive, cheerful, show real emotion, and laugh naturally at funny things.",
            "Say in a warm, natural, expressive and friendly human way, like chatting with a close friend"
        ),
        StyleOption(
            "calm", "Calm & gentle",
            "Be calm, gentle and soothing. Speak softly and patiently.",
            "Say in a calm, gentle, soothing human voice"
        ),
        StyleOption(
            "playful", "Playful & funny",
            "Be playful, witty and funny. Make light jokes and laugh often.",
            "Say in a playful, cheerful, laughing human way"
        ),
        StyleOption(
            "crisp", "Short & to the point",
            "Be brief and direct: one or two short sentences, but still warm and human.",
            "Say in a clear, confident, natural human voice"
        )
    )

    fun style(key: String): StyleOption = styles.firstOrNull { it.key == key } ?: styles[0]
}
