package com.gayatri.aiassistant.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.Gravity
import androidx.core.graphics.ColorUtils
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import com.gayatri.aiassistant.ai.Engine
import kotlin.math.sin

/** The glowing ball drawn with plain Android graphics (used in the floating overlay). */
class OrbView(ctx: Context, private val ca: Int, private val cb: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    var amp = 0.04f
    var fast = false
    var speaking = false
    private var vl = 0f
    private val clip = Path()
    private val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 7000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (84 * resources.displayMetrics.density).toInt()
        setMeasuredDimension(s, s)
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = w / 2f
        val target = if (speaking) com.gayatri.aiassistant.ai.VoiceLevel.v else 0f
        vl += (target - vl) * 0.35f
        val r = w * 0.34f * (1f + (if (speaking) amp * 0.3f else amp) * sin(t * 6.2831855f * 3f) + 0.16f * vl)
        val mix = ColorUtils.blendARGB(ca, cb, 0.5f)
        val ca2 = ColorUtils.blendARGB(ca, Color.WHITE, 0.55f)
        val cb2 = ColorUtils.blendARGB(cb, Color.WHITE, 0.55f)
        val spin = if (fast) 2.2f else 1f

        // outer glow
        paint.shader = RadialGradient(
            cx, cy, w * 0.5f,
            intArrayOf(withAlpha(ca, 140), withAlpha(cb, 60), Color.TRANSPARENT),
            floatArrayOf(0.55f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, w * 0.5f, paint)

        clip.reset()
        clip.addCircle(cx, cy, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)

        paint.shader = null
        paint.color = mix
        canvas.drawCircle(cx, cy, r, paint)

        canvas.save()
        canvas.rotate(t * 360f * spin, cx, cy)
        paint.shader = SweepGradient(cx, cy, intArrayOf(ca, cb, ca2, cb2, ca), null)
        canvas.drawCircle(cx, cy, r * 1.5f, paint)
        canvas.restore()

        paint.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(withAlpha(mix, 217), withAlpha(mix, 64), Color.TRANSPARENT),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)

        canvas.save()
        canvas.rotate(-t * 360f * spin * 0.7f, cx, cy)
        paint.shader = SweepGradient(
            cx, cy,
            intArrayOf(withAlpha(cb2, 150), withAlpha(ca, 20), withAlpha(cb, 150), withAlpha(ca2, 20), withAlpha(cb2, 150)),
            null
        )
        paint.xfermode = screen
        canvas.drawCircle(cx, cy, r * 1.5f, paint)
        paint.xfermode = null
        canvas.restore()

        // shade for a round, 3D feel
        paint.shader = RadialGradient(
            cx - r * 0.25f, cy - r * 0.3f, r * 1.45f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, 0x59020B0D, 0xB3020B0D.toInt()),
            floatArrayOf(0f, 0.45f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)
        canvas.restore()

        // glass rim
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w * 0.01f
        paint.color = 0x66FFFFFF
        canvas.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.FILL

        // gloss highlight + small bright spot
        paint.shader = RadialGradient(
            cx - r * 0.4f, cy - r * 0.6f, r * 0.42f,
            intArrayOf(0xE6FFFFFF.toInt(), 0x40FFFFFF, Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.save()
        canvas.rotate(-30f, cx - r * 0.4f, cy - r * 0.6f)
        canvas.drawOval(RectF(cx - r * 0.72f, cy - r * 0.8f, cx - r * 0.08f, cy - r * 0.4f), paint)
        canvas.restore()
        paint.shader = null
        paint.color = 0xF2FFFFFF.toInt()
        canvas.drawCircle(cx - r * 0.5f, cy - r * 0.62f, r * 0.055f, paint)
    }
}

/** Floating view: ONLY the glowing ball, no text, no panel. Shown above the middle nav button. */
class OverlayView(ctx: Context, ca: Int, cb: Int) : LinearLayout(ctx) {
    private val orb = OrbView(ctx, ca, cb)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(orb)
    }

    @Suppress("UNUSED_PARAMETER")
    fun setText(text: String) {
        // intentionally empty: the overlay never shows text
    }

    fun setState(s: Engine.State) {
        orb.amp = when (s) {
            Engine.State.Speaking -> 0.12f
            Engine.State.Listening -> 0.08f
            Engine.State.Thinking -> 0.05f
            Engine.State.Idle -> 0.03f
        }
        orb.fast = s == Engine.State.Speaking
        orb.speaking = s == Engine.State.Speaking
    }
}
