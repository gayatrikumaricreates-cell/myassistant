package com.gayatri.aiassistant.ai

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Thin wrapper around Android's SpeechRecognizer. Must be used from the main thread. */
class SpeechIn(private val ctx: Context) {
    private var rec: SpeechRecognizer? = null

    // The system plays a "ting" when listening starts and stops. We silence the sound streams for
    // that moment, so the assistant listens quietly like other voice assistants.
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val mutedByUs = HashSet<Int>()
    private val unmuteRun = Runnable { unmuteNow() }
    private val quietStreams = intArrayOf(
        AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_SYSTEM
    )

    private fun muteNow() {
        handler.removeCallbacks(unmuteRun)
        for (st in quietStreams) {
            try {
                if (!am.isStreamMute(st)) {
                    am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, 0)
                    mutedByUs.add(st)
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun unmuteNow() {
        for (st in mutedByUs.toList()) {
            try {
                am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0)
            } catch (e: Exception) {
            }
        }
        mutedByUs.clear()
    }

    private fun unmuteSoon(ms: Long) {
        if (mutedByUs.isEmpty()) return
        handler.removeCallbacks(unmuteRun)
        handler.postDelayed(unmuteRun, ms)
    }

    val available: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun listen(
        lang: String,
        onPartial: (List<String>) -> Unit,
        onFinal: (List<String>) -> Unit,
        onFail: (Int) -> Unit
    ) {
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                unmuteSoon(450)
                onFail(error)
            }

            override fun onResults(results: Bundle?) {
                val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                unmuteSoon(450)
                onFinal(l)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (l != null && l.isNotEmpty()) onPartial(l)
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        muteNow()
        r.startListening(intent)
    }

    fun stop() {
        unmuteSoon(450)
        rec?.let {
            try {
                it.cancel()
            } catch (e: Exception) {
            }
            try {
                it.destroy()
            } catch (e: Exception) {
            }
        }
        rec = null
    }
}
