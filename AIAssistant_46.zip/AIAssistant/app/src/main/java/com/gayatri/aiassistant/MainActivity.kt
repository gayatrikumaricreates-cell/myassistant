package com.gayatri.aiassistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.gayatri.aiassistant.ui.C
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.gayatri.aiassistant.data.Perms
import com.gayatri.aiassistant.data.Prefs
import com.gayatri.aiassistant.service.AppBridge
import com.gayatri.aiassistant.ui.AppViewModel
import com.gayatri.aiassistant.ui.ColorsScreen
import com.gayatri.aiassistant.ui.HomeScreen
import com.gayatri.aiassistant.ui.LanguageScreen
import com.gayatri.aiassistant.ui.OnboardingScreen
import com.gayatri.aiassistant.ui.PhoneScreen
import com.gayatri.aiassistant.ui.ProfileSheet
import com.gayatri.aiassistant.ui.Route
import com.gayatri.aiassistant.ui.SettingsScreen
import com.gayatri.aiassistant.ui.StyleScreen
import com.gayatri.aiassistant.ui.UiTick
import com.gayatri.aiassistant.ui.VoiceScreen

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    private val firstAsk = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        UiTick.value++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // The very first time the app opens, ask for every normal permission straight away.
        if (!Prefs(this).onboarded) {
            val missing = Perms.missingRuntime(this)
            if (missing.isNotEmpty()) firstAsk.launch(missing.toTypedArray())
        }

        com.gayatri.aiassistant.ai.IntroSound.prepare()

        setContent {
            MaterialTheme {
                Root(vm)
            }
        }
    }

    private var stoppedAt = 0L

    override fun onStart() {
        super.onStart()
        // A real "opening" of the app (first start, or coming back after a little while), not a quick return from a permission screen.
        val now = System.currentTimeMillis()
        if (stoppedAt == 0L || now - stoppedAt > 15_000L) vm.introTick++
    }

    override fun onDestroy() {
        // Closing the app completely (back button / finishing) starts the conversation fresh next time.
        if (isFinishing) com.gayatri.aiassistant.ai.TalkMemory.clear()
        super.onDestroy()
    }

    override fun onStop() {
        stoppedAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        AppBridge.foreground = true
        UiTick.value++
        vm.ensureServiceIfNeeded()
    }

    override fun onPause() {
        AppBridge.foreground = false
        super.onPause()
    }
}

@Composable
private fun Root(vm: AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(vm.message) {
        vm.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (!vm.onboarded) {
            OnboardingScreen(vm)
        } else {
            when (vm.route) {
                Route.Home -> HomeScreen(vm)
                Route.Settings -> SettingsScreen(vm)
                Route.Voice -> VoiceScreen(vm)
                Route.Colors -> ColorsScreen(vm)
                Route.Language -> LanguageScreen(vm)
                Route.Style -> StyleScreen(vm)
                Route.Phone -> PhoneScreen(vm)
            }
        }
        if (vm.showProfile) ProfileSheet(vm)

        // Real reason of any problem (Gemini, key, internet, microphone, camera...) stays here until closed.
        vm.error?.let { msg ->
            LaunchedEffect(msg) {
                delay(30000)
                if (vm.error == msg) vm.error = null
            }
            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(C.sheet)
                    .border(1.dp, C.danger, RoundedCornerShape(16.dp))
                    .clickable { vm.error = null }
                    .padding(14.dp)
            ) {
                Text("⚠ What went wrong", color = C.danger, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                    Text(msg, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Text("Tap here to close", color = C.sub, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}
