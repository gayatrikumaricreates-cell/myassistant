package com.gayatri.aiassistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Length of the opening animation in milliseconds. */
const val INTRO_MS = 4800

fun seg(t: Float, a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)
fun smooth(x: Float): Float = x * x * (3f - 2f * x)
fun outCubic(x: Float): Float = 1f - (1f - x) * (1f - x) * (1f - x)
fun outBack(x: Float): Float {
    val c1 = 1.2f
    val c3 = c1 + 1f
    val y = x - 1f
    return 1f + c3 * y * y * y + c1 * y * y
}

/** Lets a button rise gently from below and fade in, starting at [start] ms. */
fun GraphicsLayerScope.rise(t: Float, start: Float, dist: Float) {
    val x = seg(t, start, start + 600f)
    alpha = smooth(x)
    translationY = dist * (1f - outCubic(x))
}

/** A soft bump that rises and falls around [c] (used for the heartbeat pulses). */
fun bump(t: Float, c: Float, w: Float): Float {
    val d = abs(t - c) / w
    return if (d >= 1f) 0f else {
        val k = 1f - d
        k * k * (3f - 2f * k)
    }
}

private class Speck(val ang: Float, val dist: Float, val size: Float, val swirl: Float, val delay: Float)

private val specks: List<Speck> = List(90) { i ->
    val r = java.util.Random(i * 131L + 7L)
    Speck(
        ang = r.nextFloat() * 6.2832f,
        dist = 0.55f + r.nextFloat() * 0.6f,
        size = 0.8f + r.nextFloat() * 2.0f,
        swirl = 0.8f + r.nextFloat() * 1.4f,
        delay = r.nextFloat() * 0.25f
    )
}

private val ringStarts = floatArrayOf(1350f, 2200f, 2700f, 3200f)
private val ringAmps = floatArrayOf(0.55f, 0.36f, 0.30f, 0.24f)

/**
 * Light that gathers into the ball, a glow behind it and thin rings that leave it with every pulse.
 * It is drawn over the whole screen in the two colours of the chosen theme.
 */
@Composable
fun IntroCanvas(clock: () -> Float, center: () -> Offset, orbRadius: Float, a: Color, b: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val ms = clock()
        val c = center()
        if (ms >= INTRO_MS || c == Offset.Zero) return@Canvas
        val dp = 1.dp.toPx()
        val maxR = hypot(size.width, size.height) / 2f

        // soft glow behind the ball
        val g = smooth(seg(ms, 0f, 1100f)) * (1f - 0.6f * smooth(seg(ms, 4200f, 4800f)))
        val gr = orbRadius * (1.4f + 1.2f * g)
        drawCircle(
            brush = Brush.radialGradient(listOf(a.copy(alpha = 0.30f * g), Color.Transparent), c, gr),
            radius = gr,
            center = c
        )

        // light specks gathering into the middle
        val fadeIn = seg(ms, 100f, 500f)
        for ((i, s) in specks.withIndex()) {
            val p = smooth(seg(ms, 250f + s.delay * 900f, 1350f + s.delay * 200f))
            if (p >= 1f || fadeIn <= 0f) continue
            val dist = (s.dist * maxR) * (1f - p) + orbRadius * 0.25f * (1f - p)
            val ang = s.ang + s.swirl * p * 1.3f
            val pos = Offset(c.x + cos(ang) * dist, c.y + sin(ang) * dist)
            val alpha = fadeIn * (1f - smooth(seg(p, 0.8f, 1f))) * 0.9f
            val col = (if (i % 2 == 0) a else b).copy(alpha = alpha)
            drawCircle(col, radius = s.size * dp * (1f + 0.6f * p), center = pos)
        }

        // rings leaving the ball: one when it forms, then one with each heartbeat
        for (k in ringStarts.indices) {
            val age = (ms - ringStarts[k]) / 1100f
            if (age < 0f || age > 1f) continue
            val r = orbRadius * (1.02f + 1.0f * outCubic(age))
            val alpha = ringAmps[k] * (1f - age) * (1f - age)
            drawCircle(
                color = (if (k % 2 == 0) a else b).copy(alpha = alpha),
                radius = r,
                center = c,
                style = Stroke(width = (2.6f - 1.6f * age) * dp)
            )
        }
    }
}
