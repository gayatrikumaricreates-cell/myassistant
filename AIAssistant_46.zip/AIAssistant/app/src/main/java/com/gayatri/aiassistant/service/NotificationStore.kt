package com.gayatri.aiassistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** The newest notifications, kept only in memory so the assistant can read them out when asked. */
object NotificationStore {
    @Volatile
    var connected: Boolean = false

    private val items = ArrayList<String>()

    @Synchronized
    fun add(line: String) {
        items.remove(line)
        items.add(0, line)
        while (items.size > 30) items.removeAt(items.size - 1)
    }

    @Synchronized
    fun recent(n: Int): List<String> = items.take(n)
}

class AssistNotificationService : NotificationListenerService() {

    private fun describe(sbn: StatusBarNotification): String? {
        if (sbn.packageName == packageName) return null
        val n = sbn.notification ?: return null
        val extras = n.extras ?: return null
        val title = extras.getCharSequence("android.title")?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString()?.trim().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return null
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        return "$app: $title ${text.take(160)}".trim()
    }

    override fun onListenerConnected() {
        NotificationStore.connected = true
        try {
            activeNotifications?.forEach { sbn -> describe(sbn)?.let { NotificationStore.add(it) } }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        NotificationStore.connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        describe(sbn)?.let { NotificationStore.add(it) }
    }
}
