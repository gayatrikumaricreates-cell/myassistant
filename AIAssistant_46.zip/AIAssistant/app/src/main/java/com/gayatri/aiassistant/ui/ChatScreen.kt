package com.gayatri.aiassistant.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.gayatri.aiassistant.ai.SpeechIn
import com.gayatri.aiassistant.service.WakeService
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.data.Perms

private fun orbLevel(st: Engine.State): Float = when (st) {
    Engine.State.Speaking -> 1f
    Engine.State.Listening -> 0.7f
    Engine.State.Thinking -> 0.4f
    Engine.State.Idle -> 0.1f
}

/**
 * The chat view: the ball sits small in the top corner and the talk appears as messages.
 * With the live camera on, the screen splits: the ball in the middle on top, the camera below.
 */
@Composable
fun ChatScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(false) }
    BackHandler {
        if (menu) menu = false else if (vm.cameraOn) vm.setCamera(false) else vm.chatMode = false
    }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.attach(uri)
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.attach(uri)
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.setCamera(true) else vm.error = "The camera cannot start because camera permission is not given. Tap Allow in Settings > Phone control."
    }
    val startLive = {
        if (Perms.cameraOk(ctx)) vm.setCamera(true) else camPerm.launch(android.Manifest.permission.CAMERA)
    }

    Box(Modifier.fillMaxSize()) {
        if (vm.cameraOn) {
            LiveSplit(vm, front) { front = !front }
        } else {
            ChatBody(vm, onPlus = { menu = !menu })
        }

        if (menu) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) { detectTapGestures { menu = false } }
            )
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .systemBarsPadding()
                    .imePadding()
                    .padding(start = 18.dp, bottom = 74.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(CardBrush)
                    .border(1.dp, C.cardBorder, RoundedCornerShape(20.dp))
                    .padding(vertical = 6.dp)
            ) {
                MenuItem(Icons.Rounded.Image, "Photos & videos") {
                    menu = false
                    pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                }
                MenuItem(Icons.Rounded.AttachFile, "Files (PDF, text...)") {
                    menu = false
                    pickFile.launch(arrayOf("*/*"))
                }
                MenuItem(Icons.Rounded.Videocam, "Live (talk + camera)") {
                    menu = false
                    startLive()
                }
            }
        }
    }
}

@Composable
private fun MenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .widthIn(min = 230.dp)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = C.teal, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChatBody(vm: AppViewModel, onPlus: () -> Unit) {
    val s = vm.settings
    val (ca, cb) = orbColors(s)
    val ctx = LocalContext.current
    var draft by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val speech = remember { SpeechIn(ctx) }
    val flag = remember { booleanArrayOf(false) }
    flag[0] = listening
    DisposableEffect(Unit) {
        onDispose {
            speech.stop()
            if (flag[0]) WakeService.resume()
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(vm.chatLog.size) {
        if (vm.chatLog.isNotEmpty()) listState.animateScrollToItem(vm.chatLog.size - 1)
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CircleButton(Icons.Rounded.Close, 34.dp) { vm.chatMode = false }
            CircleButton(Icons.Rounded.Tune, 40.dp) { vm.route = Route.Settings }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Orb(
                a = ca,
                b = cb,
                modifier = Modifier.size(84.dp),
                level = if (vm.busy) 0.4f else if (listening) 0.7f else 0.1f,
                calm = s.mixSpeed == "Calm",
                speaking = false
            )
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text(s.wakeName, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(
                    when {
                        vm.busy -> "Thinking..."
                        listening -> "Listening to you..."
                        else -> "Type or speak your message"
                    },
                    color = C.sub,
                    fontSize = 12.sp
                )
            }
        }

        if (vm.chatLog.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    "Type your message below.\nTap + to share a photo, video or file, or to go Live with the camera.\nSay \"chat band karo\" to go back to the ball.",
                    color = C.sub,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(vm.chatLog.toList()) { i, m ->
                    Bubble(m, ca, cb, reading = vm.readingIdx == i) { vm.readAloud(i, m.text) }
                }
            }
        }

        val att = vm.attachment
        if (att != null) {
            val shape = RoundedCornerShape(14.dp)
            Row(
                Modifier
                    .padding(top = 8.dp)
                    .clip(shape)
                    .background(CardBrush)
                    .border(1.dp, C.cardBorder, shape)
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (att.thumb != null) {
                    Image(
                        bitmap = att.thumb,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                    )
                } else {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(C.chip),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.AttachFile, null, tint = C.teal, modifier = Modifier.size(20.dp))
                    }
                }
                Text(
                    att.name,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 10.dp).widthIn(max = 190.dp)
                )
                CircleButton(Icons.Rounded.Close, 28.dp) { vm.clearAttachment() }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CircleButton(Icons.Rounded.Add, 42.dp) { onPlus() }
            AppField(
                value = draft,
                onChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = "Type here..."
            )
            CircleButton(Icons.Rounded.Send, 42.dp, tint = C.teal) {
                val t = draft.trim()
                if (listening) {
                    speech.stop()
                    listening = false
                    WakeService.resume()
                }
                if (vm.attachment != null) {
                    draft = ""
                    vm.sendWithAttachment(t)
                } else if (t.isNotEmpty()) {
                    draft = ""
                    vm.sendChat(t)
                }
            }
            // Speak into the box: the words appear while you talk; check them, then tap send.
            CircleButton(if (listening) Icons.Rounded.Stop else Icons.Rounded.Mic, 42.dp, tint = if (listening) C.teal else Color.White) {
                if (listening) {
                    speech.stop()
                    listening = false
                    WakeService.resume()
                } else if (!Perms.micOk(ctx)) {
                    vm.error = "The microphone cannot start because microphone permission is not given. Allow it in Settings > Phone control."
                } else {
                    vm.stopVoice()
                    WakeService.pause()
                    val base = if (draft.isBlank()) "" else draft.trimEnd() + " "
                    listening = true
                    speech.listen(
                        "hi-IN",
                        onPartial = { l -> draft = base + l[0] },
                        onFinal = { l ->
                            if (l.isNotEmpty()) draft = base + l[0]
                            listening = false
                            WakeService.resume()
                        },
                        onFail = {
                            listening = false
                            WakeService.resume()
                        }
                    )
                }
            }
        }
    }
}

/** Live: the ball in the middle on top, the live camera below with cut, LIVE and flip buttons. */
@Composable
private fun LiveSplit(vm: AppViewModel, front: Boolean, onFlip: () -> Unit) {
    val s = vm.settings
    val (ca, cb) = orbColors(s)
    val tr = rememberInfiniteTransition(label = "live")
    val pulse by tr.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val glow by tr.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Orb(
                    a = ca,
                    b = cb,
                    modifier = Modifier.size(190.dp),
                    level = orbLevel(vm.state),
                    calm = s.mixSpeed == "Calm",
                    speaking = vm.state == Engine.State.Speaking
                )
                Text(
                    when (vm.state) {
                        Engine.State.Listening -> "Listening..."
                        Engine.State.Thinking -> "Thinking..."
                        Engine.State.Speaking -> "Speaking..."
                        Engine.State.Idle -> "Tap LIVE to talk"
                    },
                    color = C.sub,
                    fontSize = 12.sp
                )
                if (vm.reply.isNotEmpty()) {
                    Column(
                        Modifier
                            .padding(top = 8.dp)
                            .height(70.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(vm.reply, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }

        Box(
            Modifier
                .weight(1.15f)
                .fillMaxWidth()
        ) {
            LiveCameraPreview(
                modifier = Modifier.fillMaxSize(),
                onFrame = { vm.onFrame(it) },
                onError = { vm.error = it; vm.setCamera(false) },
                front = front
            )
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 22.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircleButton(Icons.Rounded.Close, 48.dp) { vm.setCamera(false) }
                Box(
                    Modifier
                        .size(72.dp)
                        .graphicsLayer {
                            val k = if (vm.muted) 1f else pulse
                            scaleX = k
                            scaleY = k
                        }
                        .raisedButton(CircleShape, 6.dp) { vm.toggleMute() }
                        .border(2.dp, if (vm.muted) C.danger else ca, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (vm.muted) "MUTED" else "LIVE",
                        color = if (vm.muted) C.danger else C.teal,
                        fontSize = if (vm.muted) 11.sp else 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.graphicsLayer { alpha = if (vm.muted) 1f else glow }
                    )
                }
                CircleButton(Icons.Rounded.FlipCameraAndroid, 48.dp) { onFlip() }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg, ca: Color, cb: Color, reading: Boolean, onRead: () -> Unit) {
    val clip = LocalClipboardManager.current
    val shape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (m.mine) 18.dp else 4.dp,
        bottomEnd = if (m.mine) 4.dp else 18.dp
    )
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
        Box(
            Modifier
                .widthIn(max = 290.dp)
                .clip(shape)
                .background(
                    if (m.mine) Brush.horizontalGradient(listOf(ca.copy(alpha = 0.30f), cb.copy(alpha = 0.30f)))
                    else CardBrush
                )
                .border(1.dp, if (m.mine) ca.copy(alpha = 0.55f) else C.cardBorder, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            SelectionContainer {
                Text(m.text, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
        Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            if (!m.mine) {
                Box(
                    Modifier.size(34.dp).clip(CircleShape).clickable { onRead() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (reading) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                        null,
                        tint = if (reading) C.teal else C.sub,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Box(
                Modifier.size(34.dp).clip(CircleShape).clickable { clip.setText(AnnotatedString(m.text)) },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.ContentCopy, null, tint = C.sub, modifier = Modifier.size(16.dp))
            }
        }
    }
}
