package com.gayatri.aiassistant.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class GeminiError(
    val userMessage: String,
    val code: Int = 0,
    val retryAfterMs: Long = 0L
) : Exception(userMessage)

/** What the user said (text of the transcript or typed text) and what the assistant answers. */
data class Turn(val role: String, val text: String)

/** One thing the user sent: typed text and/or spoken audio clips (WAV) and/or one camera picture. */
data class UserInput(
    val text: String?,
    val audioWav: List<ByteArray> = emptyList(),
    val imageB64: String? = null
)

data class ChatResult(val heard: String, val reply: String, val ignore: Boolean)

class GeminiClient(private val actions: PhoneActions) {

    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

        /** The one stable chat model. No "latest", no "preview": works smoothly on the free key. */
        const val CHAT_MODEL = "gemini-2.5-flash"

        @Volatile
        private var goodChatModel: String? = null

        /** Voice (text to speech) exists only as preview models; the second one is used only if the first is missing. */
        private val ttsModels = listOf("gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview", "gemini-2.5-pro-preview-tts")

        @Volatile
        private var goodTts: String? = null
    }

    private class Raw(val code: Int, val text: String)

    private fun post(model: String, apiKey: String, body: JSONObject): Raw {
        val c = URL("$BASE$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Raw(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun networkError(e: IOException): GeminiError {
        val why = "${e.javaClass.simpleName}: ${e.message ?: "no details"}"
        val hint = when (e) {
            is UnknownHostException -> "The internet is off or Google cannot be reached."
            is SocketTimeoutException -> "Google did not answer in time (the internet is very slow)."
            is SSLException -> "A secure connection (SSL) could not be made. Check the phone's date/time or internet."
            else -> "A network problem happened."
        }
        return GeminiError("$hint\nReason: $why")
    }

    /** Turns Google's error answer into a message that says the REAL reason, in Hindi plus Google's own words. */
    private fun describe(model: String, r: Raw): GeminiError {
        var status = ""
        var msg = ""
        try {
            val e = JSONObject(r.text).optJSONObject("error")
            if (e != null) {
                status = e.optString("status")
                msg = e.optString("message")
            }
        } catch (e: Exception) {
        }
        if (msg.isEmpty()) msg = r.text.take(300).ifEmpty { "(Google gave no reason)" }
        val retryMs = Regex("\"retryDelay\"\\s*:\\s*\"(\\d+(?:\\.\\d+)?)s\"").find(r.text)
            ?.groupValues?.get(1)?.toDoubleOrNull()?.let { (it * 1000).toLong() } ?: 0L
        val daily = r.text.contains("PerDay", ignoreCase = true) || msg.contains("per day", ignoreCase = true)
        val hint = when {
            r.code == 400 && (msg.contains("API key", true) || status == "INVALID_ARGUMENT" && msg.contains("key", true)) ->
                "The API key is wrong. Enter the key again in Profile."
            r.code == 400 && msg.contains("location", true) ->
                "This feature is not available in your country/region yet."
            r.code == 400 -> "Google did not accept the request that was sent."
            r.code == 401 || r.code == 403 ->
                "The API key was not accepted, or it has no permission for this model, or it was removed."
            r.code == 404 -> "This model was not found for your key."
            r.code == 429 && daily -> "Today's free quota is finished. It works again tomorrow, or check a new key/billing in AI Studio."
            r.code == 429 -> "Too many requests too quickly (free key per-minute limit). Wait a few seconds and speak again."
            r.code in 500..599 -> "Google's server is busy or down. Try again in a little while."
            else -> "An unknown problem happened."
        }
        val raw = "$model • HTTP ${r.code}${if (status.isNotEmpty()) " $status" else ""} • ${msg.take(350)}"
        return GeminiError("$hint\nReason: $raw", r.code, retryMs)
    }

    /** Calls one model. Waits and retries a short while on "too fast" (429) and "busy" (503). */
    private fun callModel(model: String, apiKey: String, body: JSONObject): JSONObject {
        var attempt = 0
        while (true) {
            val r = try {
                post(model, apiKey, body)
            } catch (e: IOException) {
                throw networkError(e)
            }
            if (r.code in 200..299) {
                return try {
                    JSONObject(r.text)
                } catch (e: Exception) {
                    throw GeminiError("Could not understand Google's answer.\nReason: ${e.message}")
                }
            }
            // Some models do not know the "thinking" setting: ask again at once without it.
            if (r.code == 400 && r.text.contains("thinking", ignoreCase = true) &&
                body.optJSONObject("generationConfig")?.has("thinkingConfig") == true
            ) {
                val b2 = JSONObject(body.toString())
                b2.optJSONObject("generationConfig")?.remove("thinkingConfig")
                return callModel(model, apiKey, b2)
            }
            val err = describe(model, r)
            val retryable = (r.code == 429 && !r.text.contains("PerDay", ignoreCase = true)) || r.code == 503
            if (retryable && attempt < 1 && err.retryAfterMs <= 4000) {
                attempt++
                Thread.sleep(maxOf(err.retryAfterMs, 1200L).coerceAtMost(3000L))
                continue
            }
            throw err
        }
    }

    /** Tries the models one by one: if one is missing (404) or its free quota is used up (429), the next one answers. */
    private fun callChatChain(apiKey: String, body: JSONObject): JSONObject {
        val order = listOf(CHAT_MODEL, "gemini-2.5-flash-lite", "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.0-flash")
        val first = goodChatModel
        val list = if (first != null) listOf(first) + order.filter { it != first } else order
        var firstErr: GeminiError? = null
        for (m in list) {
            try {
                val r = callModel(m, apiKey, body)
                goodChatModel = m
                return r
            } catch (e: GeminiError) {
                val keyProblem = e.code == 401 || e.code == 403 || e.userMessage.contains("API key is wrong")
                if (keyProblem) throw e
                if (e.code == 400 || e.code == 404 || e.code == 429 || e.code == 503) {
                    // keep the FIRST problem: it belongs to the main model and says the real reason
                    if (firstErr == null) firstErr = e
                    if (e.code != 404 && m == goodChatModel) goodChatModel = null
                } else throw e
            }
        }
        throw firstErr ?: GeminiError("No Gemini model was found.")
    }

    private fun finishInfo(res: JSONObject): String {
        val block = res.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        if (block.isNotEmpty()) return "Gemini blocked this message (blockReason: $block)"
        val fr = res.optJSONArray("candidates")?.optJSONObject(0)?.optString("finishReason").orEmpty()
        return if (fr.isNotEmpty() && fr != "STOP") "Gemini did not finish the answer (finishReason: $fr)"
        else "Gemini gave no answer (empty reply)"
    }

    suspend fun chat(apiKey: String, system: String, history: List<Turn>, input: UserInput): ChatResult =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw GeminiError("First add your Gemini API key in Profile.")

            val contents = JSONArray()
            for (t in history) {
                contents.put(
                    JSONObject().put("role", t.role)
                        .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
                )
            }
            val parts = JSONArray()
            for (wav in input.audioWav) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "audio/wav")
                            .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))
                    )
                )
            }
            if (input.imageB64 != null) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", input.imageB64)
                    )
                )
            }
            val typed = input.text
            if (!typed.isNullOrBlank()) {
                parts.put(JSONObject().put("text", typed))
            } else if (input.audioWav.size > 1) {
                parts.put(JSONObject().put("text", "(The user said all the audio clips above, one after another, in one go. Answer them together.)"))
            } else if (input.audioWav.isEmpty()) {
                parts.put(JSONObject().put("text", "(no message)"))
            }
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            repeat(5) {
                val body = JSONObject()
                    .put(
                        "system_instruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                    )
                    .put("contents", contents)
                    .put("tools", tools())
                    .put(
                        "generationConfig",
                        JSONObject()
                            .put("temperature", 0.9)
                            .put("maxOutputTokens", 700)
                            // no long "thinking" pause: the answer comes fast, like a live talk
                            .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                    )

                val res = callChatChain(apiKey, body)
                val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                val rparts = content?.optJSONArray("parts") ?: JSONArray()

                val calls = ArrayList<JSONObject>()
                val sb = StringBuilder()
                for (i in 0 until rparts.length()) {
                    val p = rparts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        calls.add(p.getJSONObject("functionCall"))
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        sb.append(p.getString("text"))
                    }
                }

                if (calls.isEmpty()) {
                    return@withContext parseReply(sb.toString(), finishInfo(res))
                }

                contents.put(JSONObject().put("role", "model").put("parts", rparts))
                val responses = JSONArray()
                for (c in calls) {
                    val name = c.getString("name")
                    val result = try {
                        actions.run(name, c.optJSONObject("args") ?: JSONObject())
                    } catch (e: Exception) {
                        "Failed: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
                    }
                    responses.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name)
                                .put("response", JSONObject().put("result", result))
                        )
                    )
                }
                contents.put(JSONObject().put("role", "user").put("parts", responses))
            }
            ChatResult("", "Okay, done.", false)
        }

    /** The user shares one photo, video or file (PDF, text...) in the chat; Gemini reads it and answers in words. */
    suspend fun analyzeFile(apiKey: String, system: String, question: String, data: ByteArray, mime: String): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw GeminiError("First add your Gemini API key in Profile.")
            val parts = JSONArray()
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", mime).put("data", Base64.encodeToString(data, Base64.NO_WRAP))
                )
            )
            parts.put(
                JSONObject().put(
                    "text",
                    if (question.isBlank()) "Please look at this and tell me briefly what it is and the important points." else question
                )
            )
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.7)
                        .put("maxOutputTokens", 1500)
                        .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                )
            val res = callChatChain(apiKey, body)
            val rparts = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
            val sb = StringBuilder()
            for (i in 0 until rparts.length()) {
                val p = rparts.getJSONObject(i)
                if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
            }
            val t = sb.toString().trim()
            if (t.isEmpty()) throw GeminiError(finishInfo(res))
            t
        }

    private fun parseReply(raw: String, whyEmpty: String): ChatResult {
        var text = raw.trim()
        if (text.isEmpty()) throw GeminiError(whyEmpty)
        if (text.contains("[[ignore]]", ignoreCase = true)) return ChatResult("", "", true)
        var heard = ""
        val m = Regex("^\\s*\\[\\[\\s*heard\\s*:(.*?)\\]\\]\\s*", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(text)
        if (m != null) {
            heard = m.groupValues[1].trim()
            text = text.substring(m.range.last + 1).trim()
        }
        text = text.replace(Regex("\\[\\[.*?\\]\\]"), "").trim()
        if (text.isEmpty()) throw GeminiError("Gemini only wrote what it heard and gave no answer.")
        return ChatResult(heard, text, false)
    }

    suspend fun tts(apiKey: String, text: String, voice: String, stylePrefix: String): ByteArray =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", "$stylePrefix: $text"))
                        )
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig",
                            JSONObject().put(
                                "voiceConfig",
                                JSONObject().put(
                                    "prebuiltVoiceConfig",
                                    JSONObject().put("voiceName", voice)
                                )
                            )
                        )
                )
            val order = listOfNotNull(goodTts) + ttsModels.filter { it != goodTts }
            var last: GeminiError? = null
            var res: JSONObject? = null
            for (m in order) {
                try {
                    res = callModel(m, apiKey, body)
                    goodTts = m
                    break
                } catch (e: GeminiError) {
                    if (e.code == 404) {
                        last = e
                        continue
                    }
                    throw e
                }
            }
            if (res == null) throw last ?: GeminiError("No voice model was found.")
            val data = res.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optJSONObject("inlineData")?.optString("data")
            if (data.isNullOrEmpty()) throw GeminiError("The voice could not be made.\nReason: ${finishInfo(res)}")
            Base64.decode(data, Base64.DEFAULT)
        }

    // ---------- tool declarations ----------

    private fun fn(
        name: String,
        desc: String,
        props: List<Triple<String, String, String>> = emptyList(),
        required: List<String> = emptyList()
    ): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject()
            props.forEach { (n, t, d) ->
                p.put(n, JSONObject().put("type", t).put("description", d))
            }
            o.put(
                "parameters",
                JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
            )
        }
        return o
    }

    fun tools(): JSONArray {
        val d = JSONArray()
        d.put(fn("make_call", "Call a person from the user's contacts, or a phone number. First call it WITHOUT confirmed to look the person up (nothing is dialled); read the name and number back to the user and ask if you should go ahead; only after they clearly say yes call it again with confirmed=true. If the contact is not found, retry once with the English/Latin spelling of the name.",
            listOf(Triple("contact", "string", "Contact name as the user said it, or a phone number"), Triple("confirmed", "boolean", "true ONLY after the user clearly said yes to the name/number you read out")), listOf("contact")))
        d.put(fn("answer_call", "Answer the phone call that is ringing right now."))
        d.put(fn("end_call", "End or hang up the current phone call."))
        d.put(fn("send_sms", "Send a text message (SMS) to a contact or number. Call it first WITHOUT confirmed (nothing is sent); read the receiver and the message back and ask if you should send; only after a clear yes call again with confirmed=true.",
            listOf(Triple("contact", "string", "Contact name or number"), Triple("message", "string", "The message text"), Triple("confirmed", "boolean", "true ONLY after the user clearly said yes")),
            listOf("contact", "message")))
        d.put(fn("send_whatsapp", "Send a WhatsApp message to a contact or number. Call it first WITHOUT confirmed (nothing is sent); read the receiver and the message back and ask if you should send; only after a clear yes call again with confirmed=true.",
            listOf(Triple("contact", "string", "Contact name or number"), Triple("message", "string", "The message text"), Triple("confirmed", "boolean", "true ONLY after the user clearly said yes")),
            listOf("contact", "message")))
        d.put(fn("play_youtube", "Search YouTube for a video or song and play it.",
            listOf(Triple("query", "string", "What to search for, e.g. the song or video name")), listOf("query")))
        d.put(fn("set_timer", "Start a countdown timer.",
            listOf(Triple("seconds", "integer", "Timer length in seconds"), Triple("label", "string", "Optional label")),
            listOf("seconds")))
        d.put(fn("set_alarm", "Set an alarm clock for a time of day (24-hour).",
            listOf(Triple("hour", "integer", "Hour 0-23"), Triple("minute", "integer", "Minute 0-59"), Triple("label", "string", "Optional label")),
            listOf("hour", "minute")))
        d.put(fn("set_volume", "Change the phone's media volume. Use either a direction or a level.",
            listOf(Triple("direction", "string", "One of: up, down, mute, max"), Triple("level", "integer", "Volume percent 0-100"))))
        d.put(fn("read_sms", "Read the user's text messages (SMS inbox). Use it when they want to find or read a message: pass a word, a sender name/number, or leave empty for the newest messages. WhatsApp messages cannot be read, only normal SMS.",
            listOf(Triple("query", "string", "Word, sender name or number to search for; empty for the newest"), Triple("limit", "integer", "How many messages, 1 to 8 (default 5)"))))
        d.put(fn("read_call_log", "Read the user's recent calls. kind is 'missed' for missed calls or 'all' for every recent call.",
            listOf(Triple("kind", "string", "missed or all"), Triple("limit", "integer", "How many calls, 1 to 10 (default 5)"))))
        d.put(fn("contact_info", "Find the phone number of a person in the user's contacts.",
            listOf(Triple("name", "string", "Contact name as the user said it")), listOf("name")))
        d.put(fn("get_battery", "Tell the phone's battery level and whether it is charging."))
        d.put(fn("media_control", "Control music/video playing on the phone: play_pause, next, previous or stop.",
            listOf(Triple("action", "string", "play_pause, next, previous or stop")), listOf("action")))
        d.put(fn("add_calendar_event", "Open the calendar with a new event filled in (the user only taps Save). Date as YYYY-MM-DD, time as HH:MM in 24-hour format.",
            listOf(Triple("title", "string", "Event title"), Triple("date", "string", "YYYY-MM-DD"), Triple("time", "string", "HH:MM, 24-hour"), Triple("duration_minutes", "integer", "Length in minutes (default 60)")),
            listOf("title", "date", "time")))
        d.put(fn("read_notifications", "Read out the newest notifications on the phone (which app, who, what).",
            listOf(Triple("limit", "integer", "How many, 1 to 10 (default 6)"))))
        d.put(fn("screen_read", "Read what is on the phone screen right now (texts and buttons marked [tap]). Use it before tapping so you know the exact words."))
        d.put(fn("screen_tap", "Tap a button, tab, video or item on the current screen by the words written on it (works in any app, e.g. Like, Search, an episode title).",
            listOf(Triple("text", "string", "The visible text or label of the thing to tap")), listOf("text")))
        d.put(fn("screen_scroll", "Swipe the current screen exactly the way the user asked. amount='next_video' is one full-screen flick for Instagram Reels, YouTube Shorts and similar (moves to the next/previous video). amount='page' scrolls a normal page, feed or list by about one screen. amount='small' scrolls only a little. Use times to repeat. Choose from the user's words and the app on screen: 'next reel/short/video' = next_video; 'scroll down' in a list or feed = page; 'a little / thoda' = small.",
            listOf(Triple("direction", "string", "down, up, left or right (down = next video or later content)"), Triple("amount", "string", "next_video, page or small"), Triple("times", "integer", "how many times, default 1")), listOf("direction")))
        d.put(fn("screen_type", "Type text into the text box on the current screen (search box, message box). Tap the box first if needed.",
            listOf(Triple("text", "string", "The text to type")), listOf("text")))
        d.put(fn("screen_key", "Press a system key: back, home, recents, notifications, or enter (to run a search).",
            listOf(Triple("key", "string", "back, home, recents, notifications or enter")), listOf("key")))
        d.put(fn("dismiss", "Call this when the user tells you to go away, leave, step aside or says their work with you is done (for example 'चले जाओ', 'हट जाओ', 'मेरा काम हो गया', 'you can go now'). Afterwards say ONE very short goodbye."))
        d.put(fn("turn_off_listening", "Call this only when the user says to switch yourself off completely / stop listening for good (for example 'पूरी तरह बंद हो जाओ', 'अब सुनना बंद करो'). Afterwards say ONE very short goodbye."))
        d.put(fn("flashlight", "Turn the phone's flashlight (torch) on or off.",
            listOf(Triple("on", "boolean", "true to turn on, false to turn off")), listOf("on")))
        d.put(fn("open_app", "Open ANY app installed on the phone (Gemini, Claude, ChatGPT, JioHotstar, Instagram, Netflix, Paytm, Gmail, Camera ...). Pass the app name in English as written on its icon, even if the user said it in Hindi. If the result says it was not found, retry with another spelling or one of the installed names it lists.",
            listOf(Triple("app_name", "string", "Name of the app in English, e.g. Camera, Gallery, Settings, Instagram")), listOf("app_name")))
        d.put(fn("open_settings_panel", "Open the Wi-Fi, Bluetooth or volume settings panel (the user then taps the switch).",
            listOf(Triple("kind", "string", "One of: wifi, bluetooth, volume")), listOf("kind")))
        d.put(fn("set_brightness", "Set the screen brightness.",
            listOf(Triple("level", "integer", "Brightness percent 0-100")), listOf("level")))
        d.put(fn("search_web", "Open a Google search in the browser for the given words (use this when the user wants to look something up online).",
            listOf(Triple("query", "string", "What to search for")), listOf("query")))
        d.put(fn("navigate", "Start Google Maps navigation to a place.",
            listOf(Triple("place", "string", "Destination name or address")), listOf("place")))
        return JSONArray().put(JSONObject().put("functionDeclarations", d))
    }
}
