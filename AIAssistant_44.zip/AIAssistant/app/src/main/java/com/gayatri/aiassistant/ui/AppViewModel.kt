package com.gayatri.aiassistant.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.ai.LiveEngine
import com.gayatri.aiassistant.ai.GeminiClient
import com.gayatri.aiassistant.ai.PhoneActions
import com.gayatri.aiassistant.ai.Prompts
import com.gayatri.aiassistant.ai.SpeechOut
import com.gayatri.aiassistant.data.AppSettings
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.data.ChatEntry
import com.gayatri.aiassistant.data.SHOW_CHAT_HISTORY
import com.gayatri.aiassistant.data.Perms
import com.gayatri.aiassistant.data.Prefs
import com.gayatri.aiassistant.service.AppBridge
import com.gayatri.aiassistant.service.WakeService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/** A photo, video or file waiting to be sent in the chat. */
class Attachment(val name: String, val mime: String, val bytes: ByteArray, val thumb: ImageBitmap?)

/** One line of the chat view. */
class ChatMsg(val mine: Boolean, val text: String)

enum class Route { Home, Settings, Voice, Colors, Language, Style, Phone }

class AppViewModel(private val app: Application) : AndroidViewModel(app), Engine.Callback {

    private val prefs = Prefs(app)

    var settings by mutableStateOf(prefs.load().also { C.apply(orbColors(it).first, orbColors(it).second) })
        private set
    var history by mutableStateOf(prefs.history())
        private set
    var onboarded by mutableStateOf(prefs.onboarded)
    var route by mutableStateOf(Route.Home)

    /** Counts every time the app is opened; the home screen plays its opening animation once per count. */
    var introTick by mutableStateOf(0)
    var introShown = -1
    var state by mutableStateOf(Engine.State.Idle)
        private set
    var heard by mutableStateOf("")
        private set
    var reply by mutableStateOf("")
        private set
    var message by mutableStateOf<String?>(null)

    /** The real reason of the last problem (shown in a banner on the screen until the user closes it). */
    var error by mutableStateOf<String?>(null)
    var cameraOn by mutableStateOf(false)
        private set

    @Volatile
    private var latestFrame: String? = null
    var showProfile by mutableStateOf(false)

    // ---------- mute, chat view, photo, key check ----------

    /** True while the microphone is muted: the phone still listens, but nothing reaches the assistant. */
    var muted by mutableStateOf(false)
        private set

    fun toggleMute() {
        muted = !muted
        LiveEngine.muted = muted
    }

    /** The chat view: the ball moves to the top corner and the talk is shown as messages. Lives only while the app lives. */
    var chatMode by mutableStateOf(false)
    val chatLog = androidx.compose.runtime.mutableStateListOf<ChatMsg>()

    private fun addChat(mine: Boolean, text: String) {
        if (text.isBlank()) return
        chatLog.add(ChatMsg(mine, text.trim()))
        while (chatLog.size > 200) chatLog.removeAt(0)
    }

    private fun wantsChat(t: String): Boolean {
        val x = t.lowercase()
        if (x.contains("whatsapp") || x.contains("व्हाट्सएप") || x.contains("व्हाट्सऐप") || x.contains("वाट्सएप")) return false
        val words = listOf(
            "chat kar", "chat on", "chat mode", "chat box", "chatbox", "chat khol", "chat open", "chat shuru", "chat start",
            "let's chat", "lets chat", "want to chat", "wanna chat", "type kar", "typing mode", "text mode",
            "likh kar baat", "likhkar baat", "चैट", "टाइप"
        )
        return words.any { x.contains(it) }
    }

    private fun wantsVoice(t: String): Boolean {
        val x = t.lowercase()
        val words = listOf(
            "chat band", "chat close", "chat off", "chat hata", "voice mode", "bol ke baat", "bolke baat", "bol kar baat",
            "चैट बंद", "चैट बन्द", "चैट हटा", "बोलकर बात", "बोल कर बात", "बोलके बात", "वॉइस मोड", "वॉयस मोड"
        )
        return words.any { x.contains(it) }
    }

    var attachment by mutableStateOf<Attachment?>(null)
        private set

    /** True while the assistant is reading a shared file. */
    var busy by mutableStateOf(false)
        private set

    fun clearAttachment() {
        attachment = null
    }

    fun attach(uri: android.net.Uri) {
        scope.launch(Dispatchers.IO) {
            try {
                val cr = app.contentResolver
                var name = "file"
                var size = -1L
                cr.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: "file"
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                if (size > 14_000_000L) {
                    withContext(Dispatchers.Main) { message = "That file is too big (limit about 14 MB). Pick a smaller one." }
                    return@launch
                }
                var mime = cr.getType(uri) ?: ""
                if (mime.isBlank() || mime == "application/octet-stream") {
                    mime = when (name.substringAfterLast('.', "").lowercase()) {
                        "pdf" -> "application/pdf"
                        "txt" -> "text/plain"
                        "csv" -> "text/csv"
                        "jpg", "jpeg" -> "image/jpeg"
                        "png" -> "image/png"
                        "webp" -> "image/webp"
                        "mp4" -> "video/mp4"
                        "mp3" -> "audio/mpeg"
                        else -> "application/octet-stream"
                    }
                }
                val bytes = cr.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null || bytes.isEmpty()) {
                    withContext(Dispatchers.Main) { message = "Could not open that file." }
                    return@launch
                }
                if (bytes.size > 14_000_000) {
                    withContext(Dispatchers.Main) { message = "That file is too big (limit about 14 MB). Pick a smaller one." }
                    return@launch
                }
                var thumb: ImageBitmap? = null
                if (mime.startsWith("image/")) {
                    try {
                        val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 6 }
                        thumb = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)?.asImageBitmap()
                    } catch (e: Throwable) {
                    }
                }
                val a = Attachment(name, mime, bytes, thumb)
                withContext(Dispatchers.Main) { attachment = a }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { message = "Could not open that file." }
            }
        }
    }

    /** Sends the waiting photo, video or file (with the typed words, if any) to Gemini and shows the answer in the chat. */
    fun sendWithAttachment(text: String) {
        val a = attachment ?: return
        if (settings.apiKey.isBlank()) {
            message = "First add your Gemini API key in Profile."
            showProfile = true
            return
        }
        attachment = null
        busy = true
        addChat(true, (if (text.isBlank()) "" else text.trim() + "\n") + "\uD83D\uDCCE " + a.name)
        val s = settings
        val who = if (s.userName.isBlank()) "the user" else s.userName.trim()
        val system = "You are ${s.wakeName}, a warm, friendly personal assistant of $who. $who shares a photo, video or file. " +
            "Answer in the same language the user writes in (Hindi, Hinglish or English). Be clear and brief, no long lectures."
        scope.launch {
            try {
                val r = GeminiClient(PhoneActions(app)).analyzeFile(s.apiKey, system, text, a.bytes, a.mime)
                addChat(false, r)
                com.gayatri.aiassistant.ai.TalkMemory.add("User", "(shared ${a.name}) $text")
                com.gayatri.aiassistant.ai.TalkMemory.add("Assistant", r.take(600))
            } catch (e: com.gayatri.aiassistant.ai.GeminiError) {
                error = e.userMessage
            } catch (e: Exception) {
                error = "Could not read the file.\nReason: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
            } finally {
                busy = false
            }
        }
    }

    /** The profile photo (kept only on this phone). */
    var photo by mutableStateOf<ImageBitmap?>(null)
        private set
    private val photoFile = java.io.File(app.filesDir, "profile_photo.jpg")

    private fun loadPhoto() {
        photo = try {
            if (photoFile.exists()) android.graphics.BitmapFactory.decodeFile(photoFile.path)?.asImageBitmap() else null
        } catch (e: Throwable) {
            null
        }
    }

    fun setPhoto(uri: android.net.Uri) {
        scope.launch(Dispatchers.IO) {
            try {
                val cr = app.contentResolver
                val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
                val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                val src = cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@launch
                var turn = 0f
                try {
                    cr.openInputStream(uri)?.use {
                        when (android.media.ExifInterface(it).getAttributeInt(
                            android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL
                        )) {
                            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> turn = 90f
                            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> turn = 180f
                            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> turn = 270f
                        }
                    }
                } catch (e: Throwable) {
                }
                val m = android.graphics.Matrix().apply { postRotate(turn) }
                val rot = android.graphics.Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
                val side = minOf(rot.width, rot.height)
                val sq = android.graphics.Bitmap.createBitmap(rot, (rot.width - side) / 2, (rot.height - side) / 2, side, side)
                val out = android.graphics.Bitmap.createScaledBitmap(sq, 384, 384, true)
                java.io.FileOutputStream(photoFile).use { out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
                withContext(Dispatchers.Main) { photo = out.asImageBitmap() }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { message = "Could not use that photo. Try another one." }
            }
        }
    }

    fun removePhoto() {
        try {
            photoFile.delete()
        } catch (e: Throwable) {
        }
        photo = null
    }

    /** Result of checking the Gemini key: 0 no key, 1 checking, 2 correct, 3 wrong, 4 could not check (no internet). */
    var keyStatus by mutableStateOf(0)
        private set
    private var keyJob: kotlinx.coroutines.Job? = null

    fun checkKey(key: String) {
        keyJob?.cancel()
        val k = key.trim()
        if (k.isBlank()) {
            keyStatus = 0
            return
        }
        keyStatus = 1
        keyJob = scope.launch {
            delay(700)
            keyStatus = withContext(Dispatchers.IO) { probeKey(k) }
        }
    }

    private fun probeKey(k: String): Int {
        if (k.any { it.code < 33 || it.code > 126 }) return 3
        return try {
            val c = java.net.URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1").openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("x-goog-api-key", k)
            val code = c.responseCode
            c.disconnect()
            when (code) {
                200 -> 2
                400, 401, 403 -> 3
                else -> 4
            }
        } catch (e: Exception) {
            4
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val engine = LiveEngine(app, scope, this)
    private val previewOut = SpeechOut(app, GeminiClient(PhoneActions(app)))

    init {
        LiveEngine.muted = false
        loadPhoto()
        if (!SHOW_CHAT_HISTORY) {
            prefs.clearHistory()
            history = emptyList()
        }
        previewOut.onNotice = { error = it }
        AppBridge.onWake = {
            if (state == Engine.State.Idle) startSession(Prompts.greeting(settings))
        }
    }

    // ---------- settings ----------

    fun update(block: (AppSettings) -> AppSettings) {
        settings = block(settings)
        prefs.save(settings)
        retheme()
    }

    /** Recolours the whole app from the chosen orb colours. */
    private fun retheme() {
        val (a, b) = orbColors(settings)
        C.apply(a, b)
    }

    private fun reload() {
        settings = prefs.load()
        retheme()
    }

    fun finishOnboarding() {
        prefs.onboarded = true
        onboarded = true
    }

    fun setHandsFree(on: Boolean) {
        if (on) {
            if (!Perms.micOk(app) || !Perms.overlayOk(app)) {
                message = "For hands-free, first allow the microphone and 'Display over other apps'. Opening Phone control."
                route = Route.Phone
                return
            }
            update { it.copy(handsFree = true) }
            WakeService.start(app)
        } else {
            update { it.copy(handsFree = false) }
            WakeService.stopIt(app)
        }
    }

    /** Start the background listener again after the app opens, if the user had switched it on. */
    fun ensureServiceIfNeeded() {
        reload() // the assistant may have switched hands-free off while the app was closed
        if (settings.handsFree && Perms.micOk(app) && WakeService.instance == null) {
            try {
                WakeService.start(app)
            } catch (e: Exception) {
            }
        }
    }

    fun deleteHistory(id: Long) {
        prefs.deleteHistory(id)
        history = prefs.history()
    }

    // ---------- conversation ----------

    private fun startSession(greeting: String?) {
        if (settings.apiKey.isBlank()) {
            message = "First add your Gemini API key in Profile."
            showProfile = true
            return
        }
        previewOut.stop()
        WakeService.pause()
        heard = ""
        reply = ""
        engine.begin(greeting)
    }

    fun toggleMic() {
        if (state != Engine.State.Idle) {
            engine.stop()
        } else {
            startSession(null)
        }
    }

    fun sendText(text: String) {
        if (settings.apiKey.isBlank()) {
            message = "First add your Gemini API key in Profile."
            showProfile = true
            return
        }
        WakeService.pause()
        previewOut.stop()
        heard = text
        reply = ""
        addChat(true, text)
        engine.sendText(text)
    }

    fun onFrame(b64: String) {
        latestFrame = b64
        if (cameraOn) engine.sendFrame(b64)
    }

    /** Turns the live camera on or off. The talk keeps going; with the camera on, the assistant sees what it sees. */
    fun setCamera(on: Boolean) {
        if (on) {
            if (settings.apiKey.isBlank()) {
                message = "First add your Gemini API key in Profile."
                showProfile = true
                return
            }
            latestFrame = null
            cameraOn = true
            if (state == Engine.State.Idle) startSession(null)
        } else {
            cameraOn = false
            latestFrame = null
            engine.cameraOff()
        }
    }

    fun previewVoice(id: String) {
        if (state != Engine.State.Idle) engine.stop()
        val s = settings
        val name = if (s.userName.isBlank()) "" else " ${s.userName.trim()}"
        previewOut.preview(scope, Catalog.voice(id).sample.replace("{user}", name), id, s.apiKey)
    }

    /** Status of "Teach the name" (empty when idle). */
    var teaching by mutableStateOf("")
        private set

    /** The user says the wake name a few times; we keep how this phone's listener wrote it, so any name works. */
    fun teachName() {
        if (!Perms.micOk(app)) {
            message = "Allow the microphone first (Settings > Phone control)."
            return
        }
        if (teaching.startsWith("Listening")) return
        val s = settings
        com.gayatri.aiassistant.service.WakeService.pause()
        teaching = "Listening for 9 seconds... say \"${s.wakeName}\" 3 times, clearly, with a short pause each time."
        com.gayatri.aiassistant.service.VoskWake(app).learn(9) { list, err ->
            val keep = list.map { it.trim().lowercase() }
                .filter { it != "[unk]" && it.length >= 3 && it.split(" ").size <= 3 && it.all { c -> c in 'a'..'z' || c == ' ' } }
                .distinct()
            if (keep.isNotEmpty()) prefs.setLearned(s.wakeName, keep)
            teaching = when {
                err != null -> "Could not listen: $err"
                keep.isEmpty() -> "I could not catch it. I heard: ${list.joinToString().ifBlank { "nothing" }}. Try again, a little closer to the phone."
                else -> "Learned how \"${s.wakeName}\" sounds: ${keep.joinToString(", ")}. Hands-free will use this."
            }
            com.gayatri.aiassistant.service.WakeService.resume()
        }
    }

    fun stopPreview() {
        previewOut.stop()
    }

    // ---------- Engine.Callback ----------

    override fun onState(s: Engine.State) {
        state = s
    }

    override fun onHeard(text: String, final: Boolean) {
        heard = text
        if (final && text.isNotBlank()) {
            reply = ""
            addChat(true, text)
            if (chatMode) {
                if (wantsVoice(text)) chatMode = false
            } else if (wantsChat(text)) {
                chatMode = true
            }
            if (SHOW_CHAT_HISTORY) {
                prefs.addHistory(text)
                history = prefs.history()
            }
        }
    }

    override fun onReply(text: String) {
        reply = text
        addChat(false, text)
    }

    override fun onError(msg: String) {
        error = msg
    }

    override fun onSessionEnd() {
        reload()
        cameraOn = false
        latestFrame = null
        WakeService.resume()
    }

    override fun onCleared() {
        engine.stop()
        previewOut.stop()
        AppBridge.onWake = null
        scope.cancel()
        super.onCleared()
    }
}
