package com.gayatri.aiassistant.ai

/**
 * What was said in this conversation, kept only while the app is alive (never saved to storage).
 * If the user stops the mic and starts it again, the assistant gets this back and continues the same talk.
 * It is cleared when the app is closed completely.
 */
object TalkMemory {
    private const val MAX_TURNS = 24
    private const val MAX_CHARS = 3500
    private val turns = ArrayList<Pair<String, String>>()

    @Synchronized
    fun add(who: String, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        turns.add(who to t.take(500))
        while (turns.size > MAX_TURNS) turns.removeAt(0)
    }

    @Synchronized
    fun clear() {
        turns.clear()
    }

    /** Text for the assistant's instructions; empty when nothing was said yet. */
    @Synchronized
    fun render(): String {
        if (turns.isEmpty()) return ""
        val sb = StringBuilder()
        for (i in turns.indices.reversed()) {
            val line = turns[i].first + ": " + turns[i].second + "\n"
            if (sb.length + line.length > MAX_CHARS) break
            sb.insert(0, line)
        }
        return "\n\nThis is the same ongoing conversation. The user paused the mic and came back, so you have not forgotten anything. " +
            "Here is what was said just before (oldest first). Continue naturally from it and use it when they refer back to it " +
            "(\"that\", \"him\", \"what I said\"). Do not greet again as if it were a new talk and do not read this list out.\n" + sb
    }
}
