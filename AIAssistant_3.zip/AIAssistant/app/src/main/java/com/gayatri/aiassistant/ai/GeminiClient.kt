package com.gayatri.aiassistant.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class GeminiError(val userMessage: String) : Exception(userMessage)

data class Turn(val role: String, val text: String, val imageB64: String? = null)

class GeminiClient(private val actions: PhoneActions) {

    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
        private val chatModels = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-flash-lite")
        private val ttsModels = listOf("gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview")

        @Volatile
        private var goodChat: String? = null

        @Volatile
        private var goodTts: String? = null
    }

    private fun post(model: String, apiKey: String, body: JSONObject): Pair<Int, String> {
        val c = URL("$BASE$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private fun mapError(code: Int, text: String): GeminiError = when {
        code == 400 && text.contains("API key", ignoreCase = true) ->
            GeminiError("The API key looks wrong. Enter it again in Profile.")
        code == 401 || code == 403 ->
            GeminiError("The API key was not accepted. Check it in Profile.")
        code == 429 ->
            GeminiError("Too many requests right now, try again in a little while.")
        code >= 500 ->
            GeminiError("Gemini is not responding, try again in a little while.")
        else -> GeminiError("Something went wrong (code $code).")
    }

    private fun callWithFallback(
        models: List<String>,
        preferred: String?,
        apiKey: String,
        body: JSONObject,
        remember: (String) -> Unit
    ): JSONObject {
        val order = listOfNotNull(preferred) + models.filter { it != preferred }
        var last: GeminiError? = null
        for (m in order) {
            val (code, text) = try {
                post(m, apiKey, body)
            } catch (e: IOException) {
                throw GeminiError("The internet seems to be down.")
            }
            if (code in 200..299) {
                remember(m)
                return JSONObject(text)
            }
            if (code == 404 || (code == 400 && text.contains("not found", ignoreCase = true))) {
                last = mapError(code, text)
                continue
            }
            throw mapError(code, text)
        }
        throw last ?: GeminiError("No Gemini model was found.")
    }

    suspend fun chat(apiKey: String, system: String, turns: List<Turn>): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw GeminiError("Add your Gemini API key in Profile first.")

            val contents = JSONArray()
            for (t in turns) {
                val parts = JSONArray()
                parts.put(JSONObject().put("text", t.text))
                if (t.imageB64 != null) {
                    parts.put(
                        JSONObject().put(
                            "inline_data",
                            JSONObject().put("mime_type", "image/jpeg").put("data", t.imageB64)
                        )
                    )
                }
                contents.put(JSONObject().put("role", t.role).put("parts", parts))
            }

            repeat(5) {
                val body = JSONObject()
                    .put(
                        "system_instruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                    )
                    .put("contents", contents)
                    .put("tools", tools())
                    .put("generationConfig", JSONObject().put("temperature", 0.9))

                val res = callWithFallback(chatModels, goodChat, apiKey, body) { goodChat = it }
                val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                val parts = content?.optJSONArray("parts") ?: JSONArray()

                val calls = ArrayList<JSONObject>()
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        calls.add(p.getJSONObject("functionCall"))
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        sb.append(p.getString("text"))
                    }
                }

                if (calls.isEmpty()) {
                    val out = sb.toString().trim()
                    if (out.isEmpty()) throw GeminiError("Empty reply, please say it once more.")
                    return@withContext out
                }

                contents.put(JSONObject().put("role", "model").put("parts", parts))
                val responses = JSONArray()
                for (c in calls) {
                    val name = c.getString("name")
                    val result = try {
                        actions.run(name, c.optJSONObject("args") ?: JSONObject())
                    } catch (e: Exception) {
                        "Failed: ${e.message ?: e.javaClass.simpleName}"
                    }
                    responses.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name)
                                .put("response", JSONObject().put("result", result))
                        )
                    )
                }
                contents.put(JSONObject().put("role", "user").put("parts", responses))
            }
            "ठीक है, काम हो गया।"
        }

    suspend fun tts(apiKey: String, text: String, voice: String, stylePrefix: String): ByteArray =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", "$stylePrefix: $text"))
                        )
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig",
                            JSONObject().put(
                                "voiceConfig",
                                JSONObject().put(
                                    "prebuiltVoiceConfig",
                                    JSONObject().put("voiceName", voice)
                                )
                            )
                        )
                )
            val res = callWithFallback(ttsModels, goodTts, apiKey, body) { goodTts = it }
            val data = res.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optJSONObject("inlineData")?.optString("data")
            if (data.isNullOrEmpty()) throw GeminiError("Could not create the voice.")
            Base64.decode(data, Base64.DEFAULT)
        }

    // ---------- tool declarations ----------

    private fun fn(
        name: String,
        desc: String,
        props: List<Triple<String, String, String>> = emptyList(),
        required: List<String> = emptyList()
    ): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject()
            props.forEach { (n, t, d) ->
                p.put(n, JSONObject().put("type", t).put("description", d))
            }
            o.put(
                "parameters",
                JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
            )
        }
        return o
    }

    private fun tools(): JSONArray {
        val d = JSONArray()
        d.put(fn("make_call", "Call a person from the user's contacts, or a phone number. If the contact is not found, retry once with the English/Latin spelling of the name.",
            listOf(Triple("contact", "string", "Contact name as the user said it, or a phone number")), listOf("contact")))
        d.put(fn("answer_call", "Answer the phone call that is ringing right now."))
        d.put(fn("end_call", "End or hang up the current phone call."))
        d.put(fn("send_sms", "Send a text message (SMS) to a contact or number.",
            listOf(Triple("contact", "string", "Contact name or number"), Triple("message", "string", "The message text")),
            listOf("contact", "message")))
        d.put(fn("send_whatsapp", "Send a WhatsApp message to a contact or number.",
            listOf(Triple("contact", "string", "Contact name or number"), Triple("message", "string", "The message text")),
            listOf("contact", "message")))
        d.put(fn("play_youtube", "Search YouTube for a video or song and play it.",
            listOf(Triple("query", "string", "What to search for, e.g. the song or video name")), listOf("query")))
        d.put(fn("set_timer", "Start a countdown timer.",
            listOf(Triple("seconds", "integer", "Timer length in seconds"), Triple("label", "string", "Optional label")),
            listOf("seconds")))
        d.put(fn("set_alarm", "Set an alarm clock for a time of day (24-hour).",
            listOf(Triple("hour", "integer", "Hour 0-23"), Triple("minute", "integer", "Minute 0-59"), Triple("label", "string", "Optional label")),
            listOf("hour", "minute")))
        d.put(fn("set_volume", "Change the phone's media volume. Use either a direction or a level.",
            listOf(Triple("direction", "string", "One of: up, down, mute, max"), Triple("level", "integer", "Volume percent 0-100"))))
        d.put(fn("flashlight", "Turn the phone's flashlight (torch) on or off.",
            listOf(Triple("on", "boolean", "true to turn on, false to turn off")), listOf("on")))
        d.put(fn("open_app", "Open an app installed on the phone.",
            listOf(Triple("app_name", "string", "Name of the app in English, e.g. Camera, Gallery, Settings, Instagram")), listOf("app_name")))
        d.put(fn("open_settings_panel", "Open the Wi-Fi, Bluetooth or volume settings panel (the user then taps the switch).",
            listOf(Triple("kind", "string", "One of: wifi, bluetooth, volume")), listOf("kind")))
        d.put(fn("set_brightness", "Set the screen brightness.",
            listOf(Triple("level", "integer", "Brightness percent 0-100")), listOf("level")))
        d.put(fn("navigate", "Start Google Maps navigation to a place.",
            listOf(Triple("place", "string", "Destination name or address")), listOf("place")))
        return JSONArray().put(JSONObject().put("functionDeclarations", d))
    }
}
