package com.gayatri.aiassistant.ui

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.gayatri.aiassistant.data.AppSettings

object C {
    val bgTop = Color(0xFF080B35)
    val bgMid = Color(0xFF14187A)
    val bgBottom = Color(0xFF2B2596)
    val cardTop = Color(0xFF4C51C9)
    val cardBottom = Color(0xFF3238A8)
    val cardBorder = Color(0x33FFFFFF)
    val teal = Color(0xFF2EE6C5)
    val sub = Color(0xFFB4B9F2)
    val danger = Color(0xFFE0456A)
    val field = Color(0xFF161A63)
    val sheet = Color(0xFF2A2F9B)
}

val ScreenBrush = Brush.verticalGradient(listOf(C.bgTop, C.bgMid, C.bgBottom))
val CardBrush = Brush.verticalGradient(listOf(C.cardTop, C.cardBottom))

data class OrbTheme(val name: String, val a: Color, val b: Color)

val OrbThemes = listOf(
    OrbTheme("Aurora", Color(0xFF3FE0C5), Color(0xFFB7A4F5)),
    OrbTheme("Sunset Gold", Color(0xFFFFB347), Color(0xFFFF7A59)),
    OrbTheme("Ocean", Color(0xFF4FC3F7), Color(0xFF5C6BFF)),
    OrbTheme("Orchid", Color(0xFFF48FD0), Color(0xFF9B6BFF)),
    OrbTheme("Emerald", Color(0xFF5CE08A), Color(0xFFC8F560)),
    OrbTheme("Crimson", Color(0xFFFF5E62), Color(0xFFFFA06B))
)

val Palette1 = listOf(
    Color(0xFF2EE6C5), Color(0xFFFFB84D), Color(0xFF3EC8F5),
    Color(0xFF9B6BFF), Color(0xFF4CD964), Color(0xFFFF4D5E)
)

val Palette2 = listOf(
    Color(0xFF8E6BFF), Color(0xFFFF6A3D), Color(0xFF3D6BFF),
    Color(0xFFFF5CAF), Color(0xFFC8F03C), Color(0xFFFF9A4D)
)

fun orbColors(s: AppSettings): Pair<Color, Color> =
    if (s.useMix) {
        Palette1[s.color1.coerceIn(0, Palette1.size - 1)] to Palette2[s.color2.coerceIn(0, Palette2.size - 1)]
    } else {
        val t = OrbThemes.firstOrNull { it.name == s.theme } ?: OrbThemes[0]
        t.a to t.b
    }
