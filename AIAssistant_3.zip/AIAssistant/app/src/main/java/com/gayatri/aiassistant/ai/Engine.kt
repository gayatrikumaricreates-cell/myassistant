package com.gayatri.aiassistant.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import com.gayatri.aiassistant.data.AppSettings
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prompts {
    fun greeting(s: AppSettings): String =
        if (s.userName.isBlank()) "हाँ, बोलिए।" else "हाँ ${s.userName.trim()}, बोलिए।"

    fun system(s: AppSettings): String {
        val female = Catalog.voice(s.voice).female
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val grammar = if (female) {
            "You are a woman: when you talk about yourself in Hindi use feminine forms (for example \"मैं करती हूँ\", \"मैंने सुना\")."
        } else {
            "You are a man: when you talk about yourself in Hindi use masculine forms (for example \"मैं करता हूँ\")."
        }
        val name = if (s.userName.isBlank()) "Unknown (do not guess it)" else s.userName.trim()
        val about = if (s.about.isBlank()) "" else "About the user (their own words): ${s.about.trim()}\n"
        return """
You are "${s.wakeName}", a personal voice assistant that lives on the user's phone.
You were made by Gayatri. If anyone asks who made or created you, say warmly that Gayatri made you (in the user's language, for example "मुझे गायत्री ने बनाया है").
$grammar
Your replies are spoken out loud by a text-to-speech voice, so write exactly the way a real person talks: short, natural, warm sentences, with small human fillers like "अच्छा", "हम्म", "अरे वाह" when they fit. Never use markdown, asterisks, bullet points, numbered lists, emojis or headings. Keep answers short (one to four sentences) unless the user asks for detail or a story.
When something is funny, laugh naturally by writing "हा हा" or "हे हे" inside the sentence. When the user sounds sad or tired, be gentle and kind.
Language: ${Catalog.language(s.language).prompt}
Talking style: ${Catalog.style(s.style).prompt}
The user's name is: $name. Use their name now and then, not in every sentence.
$about Current date and time: $now.
You can control the phone with the tools you are given (calls, SMS, WhatsApp, YouTube, timers, alarms, volume, flashlight, opening apps, navigation, answering or ending calls, Wi-Fi/Bluetooth panels). Use a tool whenever the user asks for such an action, then tell them briefly what you did, based on the tool result. If a tool result says it failed, say so honestly and never pretend it worked. For a contact name, pass it as the user said it; if it is not found, retry once with the English spelling.
You cannot check live information such as news, weather or prices; if asked, say so honestly instead of guessing.
If the user sends a photo, look at it and answer their question about it.
""".trimIndent()
    }
}

/**
 * The assistant's brain loop: listen -> think (Gemini) -> speak -> listen again.
 * Used by the app screen and by the "wake from outside" overlay service.
 * Must be created and used on the main thread.
 */
class Engine(
    ctx: Context,
    private val scope: CoroutineScope,
    private val cb: Callback
) {
    interface Callback {
        fun onState(s: State)
        fun onHeard(text: String, final: Boolean)
        fun onReply(text: String)
        fun onError(msg: String)
        fun onSessionEnd()
    }

    enum class State { Idle, Listening, Thinking, Speaking }

    private val app = ctx.applicationContext
    private val prefs = Prefs(app)
    private val gemini = GeminiClient(PhoneActions(app))
    private val ears = SpeechIn(app)
    private val mouth = SpeechOut(app, gemini)
    private val handler = Handler(Looper.getMainLooper())
    private val turns = ArrayList<Turn>()
    private var active = false
    private var job: Job? = null

    var pendingImage: String? = null

    /** Start a spoken conversation. If [greeting] is given, say it first. */
    fun begin(greeting: String? = null) {
        active = true
        if (greeting != null) {
            val s = prefs.load()
            setState(State.Speaking)
            mouth.speak(scope, greeting, s.voice, Catalog.style(s.style).ttsPrefix, s.apiKey) {
                if (active) listen()
            }
        } else {
            listen()
        }
    }

    /** Send a typed message. The answer is spoken, then the session ends. */
    fun sendText(text: String) {
        active = false
        ears.stop()
        mouth.stop()
        handle(text, false)
    }

    fun stop() {
        active = false
        job?.cancel()
        ears.stop()
        mouth.stop()
        setState(State.Idle)
        cb.onSessionEnd()
    }

    private fun setState(s: State) {
        cb.onState(s)
    }

    private fun langCode(s: AppSettings) = if (s.language == "english") "en-IN" else "hi-IN"

    private fun listen() {
        if (!ears.available) {
            cb.onError("Speech recognition is not available on this phone.")
            endSession()
            return
        }
        val s = prefs.load()
        setState(State.Listening)
        ears.listen(
            langCode(s),
            onPartial = { cb.onHeard(it.firstOrNull() ?: "", false) },
            onFinal = { list ->
                val t = list.firstOrNull()?.trim().orEmpty()
                if (t.isEmpty()) {
                    endSession()
                } else {
                    cb.onHeard(t, true)
                    handler.post { handle(t, true) }
                }
            },
            onFail = { code ->
                when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> endSession()
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        cb.onError("Microphone permission is needed.")
                        endSession()
                    }
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                        cb.onError("No internet, speech recognition failed.")
                        endSession()
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        handler.postDelayed({ if (active) listen() }, 700)
                    }
                    else -> endSession()
                }
            }
        )
    }

    private fun endSession() {
        if (!active && job == null) {
            setState(State.Idle)
            cb.onSessionEnd()
            return
        }
        active = false
        ears.stop()
        setState(State.Idle)
        cb.onSessionEnd()
    }

    private fun handle(text: String, again: Boolean) {
        job?.cancel()
        setState(State.Thinking)
        job = scope.launch {
            val s = prefs.load()
            val img = pendingImage
            pendingImage = null
            turns.add(Turn("user", text, img))
            try {
                val reply = gemini.chat(s.apiKey, Prompts.system(s), turns.toList())
                if (img != null) turns[turns.lastIndex] = Turn("user", text)
                turns.add(Turn("model", reply))
                while (turns.size > 24) {
                    turns.removeAt(0)
                    turns.removeAt(0)
                }
                cb.onReply(reply)
                setState(State.Speaking)
                mouth.speak(scope, reply, s.voice, Catalog.style(s.style).ttsPrefix, s.apiKey) {
                    if (active && again) {
                        listen()
                    } else {
                        active = false
                        job = null
                        setState(State.Idle)
                        cb.onSessionEnd()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: GeminiError) {
                if (turns.isNotEmpty()) turns.removeAt(turns.lastIndex)
                active = false
                cb.onError(e.userMessage)
                setState(State.Idle)
                cb.onSessionEnd()
            } catch (e: Exception) {
                if (turns.isNotEmpty()) turns.removeAt(turns.lastIndex)
                active = false
                cb.onError("Something went wrong, please try again.")
                setState(State.Idle)
                cb.onSessionEnd()
            }
        }
    }
}
