package com.gayatri.aiassistant.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Small helper that does two things only, and only for a few seconds after the assistant asks:
 *  - presses the "Send" button in WhatsApp after the assistant typed a message
 *  - taps the first video in YouTube search results
 * It is limited to WhatsApp and YouTube in accessibility_service_config.xml.
 */
class AssistAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistAccessibilityService? = null

        @Volatile
        var pendingWhatsAppSendUntil: Long = 0L

        @Volatile
        var pendingYoutubePlayUntil: Long = 0L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        if (pkg.startsWith("com.whatsapp") && now < pendingWhatsAppSendUntil) {
            trySendWhatsApp()
        } else if (pkg == "com.google.android.youtube" && now < pendingYoutubePlayUntil) {
            tryPlayYoutube()
        }
    }

    private fun trySendWhatsApp() {
        val root = rootInActiveWindow ?: return
        var node: AccessibilityNodeInfo? = null
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val found = root.findAccessibilityNodeInfosByViewId(id)
            if (found != null && found.isNotEmpty()) {
                node = found[0]
                break
            }
        }
        if (node == null) {
            node = find(root) {
                val d = it.contentDescription?.toString()?.trim()?.lowercase()
                d == "send" || d == "भेजें"
            }
        }
        if (node != null && clickNodeOrParent(node)) {
            pendingWhatsAppSendUntil = 0L
        }
    }

    private fun tryPlayYoutube() {
        val root = rootInActiveWindow ?: return
        val node = find(root) {
            it.contentDescription?.toString()?.lowercase()?.contains("play video") == true
        }
        if (node != null && clickNodeOrParent(node)) {
            pendingYoutubePlayUntil = 0L
        }
    }

    private fun find(
        n: AccessibilityNodeInfo?,
        depth: Int = 0,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), depth + 1, pred)
            if (r != null) return r
        }
        return null
    }

    private fun clickNodeOrParent(start: AccessibilityNodeInfo?): Boolean {
        var c = start
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable) return c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            c = c.parent
            d++
        }
        return false
    }
}
