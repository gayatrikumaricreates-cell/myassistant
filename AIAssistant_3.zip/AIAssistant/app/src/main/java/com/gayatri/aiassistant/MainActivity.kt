package com.gayatri.aiassistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.gayatri.aiassistant.data.Perms
import com.gayatri.aiassistant.data.Prefs
import com.gayatri.aiassistant.service.AppBridge
import com.gayatri.aiassistant.ui.AppViewModel
import com.gayatri.aiassistant.ui.ColorsScreen
import com.gayatri.aiassistant.ui.HomeScreen
import com.gayatri.aiassistant.ui.LanguageScreen
import com.gayatri.aiassistant.ui.OnboardingScreen
import com.gayatri.aiassistant.ui.PhoneScreen
import com.gayatri.aiassistant.ui.ProfileSheet
import com.gayatri.aiassistant.ui.Route
import com.gayatri.aiassistant.ui.SettingsScreen
import com.gayatri.aiassistant.ui.StyleScreen
import com.gayatri.aiassistant.ui.UiTick
import com.gayatri.aiassistant.ui.VoiceScreen

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    private val firstAsk = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        UiTick.value++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // The very first time the app opens, ask for every normal permission straight away.
        if (!Prefs(this).onboarded) {
            val missing = Perms.missingRuntime(this)
            if (missing.isNotEmpty()) firstAsk.launch(missing.toTypedArray())
        }

        setContent {
            MaterialTheme {
                Root(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AppBridge.foreground = true
        UiTick.value++
        vm.ensureServiceIfNeeded()
    }

    override fun onPause() {
        AppBridge.foreground = false
        super.onPause()
    }
}

@Composable
private fun Root(vm: AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(vm.message) {
        vm.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (!vm.onboarded) {
            OnboardingScreen(vm)
        } else {
            when (vm.route) {
                Route.Home -> HomeScreen(vm)
                Route.Settings -> SettingsScreen(vm)
                Route.Voice -> VoiceScreen(vm)
                Route.Colors -> ColorsScreen(vm)
                Route.Language -> LanguageScreen(vm)
                Route.Style -> StyleScreen(vm)
                Route.Phone -> PhoneScreen(vm)
            }
        }
        if (vm.showProfile) ProfileSheet(vm)
    }
}
