package com.gayatri.aiassistant.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/** The glowing glass ball: two colours keep flowing into each other, with a glossy shaded surface. */
@Composable
fun Orb(
    a: Color,
    b: Color,
    modifier: Modifier = Modifier,
    level: Float = 0.1f,
    calm: Boolean = false
) {
    val fast = level > 0.2f
    val tr = rememberInfiniteTransition(label = "orb")
    val angle by tr.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(if (calm) 14000 else if (fast) 3200 else 6000, easing = LinearEasing)
        ),
        label = "angle"
    )
    val angle2 by tr.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            tween(if (calm) 19000 else if (fast) 4400 else 8500, easing = LinearEasing)
        ),
        label = "angle2"
    )
    val pulse by tr.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val amp by animateFloatAsState(targetValue = level, label = "amp")

    val a2 = lerp(a, Color.White, 0.55f)
    val b2 = lerp(b, Color.White, 0.55f)
    val mid = lerp(a, b, 0.5f)

    Canvas(modifier) {
        val w = size.minDimension
        val c = center
        val r = w * 0.36f * (1f + (0.015f + 0.06f * amp) * pulse)

        // outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(a.copy(alpha = 0.50f), b.copy(alpha = 0.22f), Color.Transparent),
                center = c,
                radius = w * 0.5f
            ),
            radius = w * 0.5f,
            center = c
        )

        val clip = Path().apply { addOval(Rect(c, r)) }
        clipPath(clip) {
            drawCircle(color = mid, radius = r, center = c)

            // flow 1
            rotate(angle, pivot = c) {
                drawCircle(
                    brush = Brush.sweepGradient(listOf(a, b, a2, b2, a), center = c),
                    radius = r * 1.5f,
                    center = c
                )
            }
            // soften the pinwheel into a smooth mix
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(mid.copy(alpha = 0.85f), mid.copy(alpha = 0.25f), Color.Transparent),
                    center = c,
                    radius = r * 0.95f
                ),
                radius = r,
                center = c
            )
            // flow 2 (opposite direction)
            rotate(angle2, pivot = c) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(b2.copy(alpha = 0.7f), a.copy(alpha = 0.1f), b.copy(alpha = 0.7f), a2.copy(alpha = 0.1f), b2.copy(alpha = 0.7f)),
                        center = c
                    ),
                    radius = r * 1.5f,
                    center = c,
                    blendMode = BlendMode.Screen
                )
            }
            // glow that wanders inside
            val wx = c.x + r * 0.35f * kotlin.math.cos(Math.toRadians(angle.toDouble() * 2)).toFloat()
            val wy = c.y + r * 0.30f * kotlin.math.sin(Math.toRadians(angle.toDouble() * 2)).toFloat()
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(a2.copy(alpha = 0.75f), Color.Transparent),
                    center = Offset(wx, wy),
                    radius = r * 0.7f
                ),
                radius = r,
                center = c,
                blendMode = BlendMode.Screen
            )
            // shade: dark toward the lower right, gives a round 3D feel
            drawCircle(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color.Transparent,
                        0.45f to Color.Transparent,
                        0.8f to Color(0xFF05061E).copy(alpha = 0.35f),
                        1f to Color(0xFF05061E).copy(alpha = 0.7f)
                    ),
                    center = Offset(c.x - r * 0.25f, c.y - r * 0.3f),
                    radius = r * 1.45f
                ),
                radius = r,
                center = c
            )
            // coloured bounce light at the bottom
            drawOval(
                brush = Brush.radialGradient(
                    listOf(b2.copy(alpha = 0.55f), Color.Transparent),
                    center = Offset(c.x, c.y + r * 0.92f),
                    radius = r * 0.7f
                ),
                topLeft = Offset(c.x - r * 0.7f, c.y + r * 0.55f),
                size = Size(r * 1.4f, r * 0.6f)
            )
        }

        // thin glass rim
        drawCircle(
            brush = Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.25f)),
                start = Offset(c.x - r, c.y - r),
                end = Offset(c.x + r, c.y + r)
            ),
            radius = r,
            center = c,
            style = Stroke(width = w * 0.008f)
        )

        // glossy highlight + small bright spot
        rotate(-30f, pivot = Offset(c.x - r * 0.4f, c.y - r * 0.6f)) {
            drawOval(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.25f), Color.Transparent),
                    center = Offset(c.x - r * 0.4f, c.y - r * 0.6f),
                    radius = r * 0.42f
                ),
                topLeft = Offset(c.x - r * 0.72f, c.y - r * 0.8f),
                size = Size(r * 0.64f, r * 0.4f)
            )
        }
        drawCircle(
            color = Color.White.copy(alpha = 0.95f),
            radius = r * 0.055f,
            center = Offset(c.x - r * 0.5f, c.y - r * 0.62f)
        )
    }
}

/** The small sound-wave bars under the ball. */
@Composable
fun Waves(active: Boolean, color: Color, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "waves")
    Row(
        modifier.height(28.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until 9) {
            val h by tr.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(450 + i * 60, easing = LinearEasing), RepeatMode.Reverse),
                label = "bar$i"
            )
            Box(
                Modifier
                    .width(3.dp)
                    .height((28f * (if (active) h else 0.2f)).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}
