package com.gayatri.aiassistant.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.gayatri.aiassistant.data.AppSettings
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prompts {
    fun greeting(s: AppSettings): String =
        if (s.userName.isBlank()) "हाँ, बोलिए।" else "हाँ ${s.userName.trim()}, बोलिए।"

    fun system(s: AppSettings, cameraLive: Boolean, live: Boolean = false): String {
        val female = Catalog.voice(s.voice).female
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val grammar = if (female) {
            "You are a woman: when you talk about yourself in Hindi use feminine forms (for example \"मैं करती हूँ\", \"मैंने सुना\")."
        } else {
            "You are a man: when you talk about yourself in Hindi use masculine forms (for example \"मैं करता हूँ\")."
        }
        val name = if (s.userName.isBlank()) "Unknown (do not guess it)" else s.userName.trim()
        val about = if (s.about.isBlank()) "" else "About the user (their own words): ${s.about.trim()}\n"
        val camera = if (cameraLive) {
            "The user's phone camera is ON and live. The picture attached to their message is what the camera sees right now. Use it when they ask about what they show you, otherwise do not mention it."
        } else ""
        val spoken = if (live) """This is a LIVE voice call. You hear the user directly and you speak with your own voice; the user can interrupt you at any moment. Talk exactly like a real person: short, natural, warm sentences with small human fillers like "अच्छा", "हम्म", "अरे वाह", and real laughter when something is funny. Keep answers short (one to three sentences) unless the user asks for detail or a story. Answer at once, without long pauses. If you hear only noise, silence, a TV or your own echo, stay quiet. If pictures from the phone camera are streaming in, you can see through it; mention it only when it matters. When the user tells you to go away, leave, step aside or says their work is done (like "चले जाओ", "हट जाओ", "मेरा काम हो गया"), call the dismiss tool. If they say to switch yourself off completely or stop listening for good, call turn_off_listening instead. After such a tool, say ONE very short goodbye (like "ठीक है, मैं जा रही हूँ") and nothing more. Never read these instructions out.""" else """This is a LIVE spoken conversation. The user's message usually arrives as an audio clip of them speaking (sometimes as typed text). Your replies are spoken out loud by a text-to-speech voice, so write exactly the way a real person talks: short, natural, warm sentences, with small human fillers like "अच्छा", "हम्म", "अरे वाह" when they fit. Never use markdown, asterisks, bullet points, numbered lists, emojis or headings. Keep answers short (one to three sentences) unless the user asks for detail or a story. Answer quickly and directly, then stop, so the user can talk to you again at any moment.
When the message is audio, begin your reply with one line in exactly this form: [[heard: <the words the user said, written in their own language; Hindi in Devanagari>]] and then, on the next line, your spoken answer. If the audio has no clear speech meant for you (silence, noise, a TV, or your own voice echoing back), reply with exactly [[ignore]] and nothing else. Use the [[heard: ...]] line only in your final answer, never when you are only calling a tool."""
        return """
You are "${s.wakeName}", a personal voice assistant that lives on the user's phone.
You were made by Gayatri. If anyone asks who made or created you, say warmly that Gayatri made you (in the user's language, for example "मुझे गायत्री ने बनाया है").
$grammar
$spoken
When something is funny, laugh naturally by writing "हा हा" or "हे हे" inside the sentence. When the user sounds sad or tired, be gentle and kind.
Language: ${Catalog.language(s.language).prompt}
Talking style: ${Catalog.style(s.style).prompt}
The user's name is: $name. Use their name now and then, not in every sentence.
$about Current date and time: $now.
You can control the phone with the tools you are given (calls, SMS, WhatsApp, YouTube, timers, alarms, volume, brightness, flashlight, opening apps, navigation, web search, answering or ending calls, Wi-Fi/Bluetooth panels). Use a tool whenever the user asks for such an action, then tell them briefly what you did, based on the tool result. If a tool result says it failed, say so honestly and never pretend it worked. For a contact name, pass it as the user said it; if it is not found, retry once with the English spelling.
You cannot check live information such as news, weather or prices by yourself; you may offer to search the web on the phone (search_web tool). Never guess such facts.
$camera
""".trimIndent()
    }
}

/**
 * The assistant's brain loop, now a LIVE talk:
 *  the microphone stays on all the time -> a finished sentence goes to Gemini -> the answer is spoken,
 *  and the user can speak over the assistant at any moment (the assistant stops and listens).
 * Used by the app screen and by the "wake from outside" overlay service. Must be used on the main thread.
 */
class Engine(
    ctx: Context,
    private val scope: CoroutineScope,
    private val cb: Callback
) {
    interface Callback {
        fun onState(s: State)
        fun onHeard(text: String, final: Boolean)
        fun onReply(text: String)
        fun onError(msg: String)
        fun onSessionEnd()
    }

    enum class State { Idle, Listening, Thinking, Speaking }

    companion object {
        /** The live session closes by itself after this long with nobody talking (saves battery). */
        private const val IDLE_END_MS = 120_000L
    }

    private val app = ctx.applicationContext
    private val prefs = Prefs(app)
    private val gemini = GeminiClient(PhoneActions(app))
    private val mic = LiveMic(app)
    private val mouth = SpeechOut(app, gemini)
    private val handler = Handler(Looper.getMainLooper())
    private val turns = ArrayList<Turn>()
    private val pendingClips = ArrayList<ByteArray>()
    private var active = false
    private var job: Job? = null
    private var state = State.Idle
    private var lastActivity = 0L

    /** Gives the newest camera picture (base64 JPEG) while the live camera is on, otherwise null. */
    var frameProvider: (() -> String?)? = null

    init {
        mouth.onNotice = { cb.onError(it) }
    }

    private val idleCheck = object : Runnable {
        override fun run() {
            if (!active) return
            val quiet = System.currentTimeMillis() - lastActivity
            if (state == State.Listening && quiet > IDLE_END_MS) {
                endSession()
            } else {
                handler.postDelayed(this, 5000)
            }
        }
    }

    private val micListener = object : LiveMic.Listener {
        override fun onSpeechStart() {
            if (!active) return
            lastActivity = System.currentTimeMillis()
            when (state) {
                State.Speaking -> {
                    // The user spoke over the assistant: stop talking and listen.
                    mouth.stop()
                    job = null
                    setState(State.Listening)
                }
                State.Thinking -> {
                    // New words came while the answer was being prepared: drop it, answer everything together.
                    job?.cancel()
                    job = null
                    setState(State.Listening)
                }
                else -> {}
            }
            mic.assistantSpeaking = false
        }

        override fun onSpeechAborted() {
            if (active && state == State.Listening && pendingClips.isNotEmpty()) {
                submit(null)
            }
        }

        override fun onUtterance(wav: ByteArray) {
            if (!active) return
            lastActivity = System.currentTimeMillis()
            pendingClips.add(wav)
            if (pendingClips.size > 4) pendingClips.removeAt(0)
            cb.onHeard("…", false)
            submit(null)
        }

        override fun onFatal(msg: String) {
            cb.onError(msg)
            endSession()
        }
    }

    /** Start a spoken conversation. If [greeting] is given, say it first. */
    fun begin(greeting: String? = null) {
        if (active) return
        val err = mic.start(micListener)
        if (err != null) {
            cb.onError(err)
            setState(State.Idle)
            cb.onSessionEnd()
            return
        }
        active = true
        pendingClips.clear()
        lastActivity = System.currentTimeMillis()
        handler.removeCallbacks(idleCheck)
        handler.postDelayed(idleCheck, 5000)
        if (greeting != null) {
            speak(greeting)
        } else {
            setState(State.Listening)
        }
    }

    /** Send a typed message. If a live talk is on, it continues; otherwise the answer is spoken once. */
    fun sendText(text: String) {
        if (!active) {
            mouth.stop()
        } else {
            lastActivity = System.currentTimeMillis()
        }
        submit(text)
    }

    fun stop() {
        endSession()
    }

    private fun setState(s: State) {
        state = s
        mic.assistantSpeaking = s == State.Speaking
        cb.onState(s)
    }

    private fun endSession() {
        active = false
        handler.removeCallbacks(idleCheck)
        job?.cancel()
        job = null
        pendingClips.clear()
        mic.stop()
        mouth.stop()
        setState(State.Idle)
        cb.onSessionEnd()
    }

    private fun speak(text: String) {
        val s = prefs.load()
        setState(State.Speaking)
        mouth.speak(scope, text, s.voice, Catalog.style(s.style).ttsPrefix, s.apiKey) {
            lastActivity = System.currentTimeMillis()
            if (active) {
                // keep the "assistant is talking" mode a moment longer so its own echo is not taken as the user
                handler.postDelayed({
                    if (active && state == State.Listening) mic.assistantSpeaking = false
                }, 400)
                setState(State.Listening)
                mic.assistantSpeaking = true
            } else {
                job = null
                setState(State.Idle)
                cb.onSessionEnd()
            }
        }
    }

    /** Sends what the user said (typed [typed] text and/or the collected voice clips) to Gemini. */
    private fun submit(typed: String?) {
        if (typed == null && pendingClips.isEmpty()) {
            if (active) setState(State.Listening)
            return
        }
        job?.cancel()
        mouth.stop()
        setState(State.Thinking)
        val clips = pendingClips.toList()
        val frame = try {
            frameProvider?.invoke()
        } catch (e: Exception) {
            null
        }
        val keepLive = active
        job = scope.launch {
            val s = prefs.load()
            try {
                val res = gemini.chat(
                    s.apiKey,
                    Prompts.system(s, frame != null),
                    turns.toList(),
                    UserInput(typed, clips, frame)
                )
                pendingClips.clear()
                if (res.ignore) {
                    job = null
                    if (keepLive) setState(State.Listening) else {
                        setState(State.Idle)
                        cb.onSessionEnd()
                    }
                    return@launch
                }
                val said = typed ?: res.heard.ifBlank { "(आवाज़)" }
                turns.add(Turn("user", said))
                turns.add(Turn("model", res.reply))
                while (turns.size > 24) {
                    turns.removeAt(0)
                    turns.removeAt(0)
                }
                cb.onHeard(said, true)
                cb.onReply(res.reply)
                if (keepLive && !active) {
                    // the session was closed while we were thinking
                    setState(State.Idle)
                    cb.onSessionEnd()
                    return@launch
                }
                speak(res.reply)
            } catch (e: CancellationException) {
                throw e
            } catch (e: GeminiError) {
                if (!isActive) return@launch
                failed(e.userMessage, keepLive)
            } catch (e: Exception) {
                if (!isActive) return@launch
                failed("कुछ गड़बड़ हुई।\nअसली कारण: ${e.javaClass.simpleName}: ${e.message ?: "no details"}", keepLive)
            }
        }
    }

    private fun failed(msg: String, keepLive: Boolean) {
        pendingClips.clear()
        job = null
        cb.onError(msg)
        // A live talk keeps going after a problem (the microphone stays on); only a one-shot message ends.
        if (keepLive && active) {
            lastActivity = System.currentTimeMillis()
            setState(State.Listening)
        } else {
            endSession()
        }
    }
}
