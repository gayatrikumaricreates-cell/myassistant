package com.gayatri.aiassistant.ai

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * The soft sound of the opening animation. It is made on the phone from simple tones (no sound file):
 * a gentle airy rise, a soft "bloom" when the ball forms, three quiet heartbeat pulses, tiny glass ticks
 * when the buttons arrive and a calm chime at the end. It follows the phone's own sound mode,
 * so it stays silent when the phone is on silent.
 */
object IntroSound {
    private const val RATE = 24000
    private const val SECONDS = 4.9f

    @Volatile private var pcm: ShortArray? = null
    @Volatile private var track: AudioTrack? = null

    /** Builds the sound in the background so it is ready the moment the animation starts. */
    fun prepare() {
        if (pcm != null) return
        Thread({ buildOnce() }, "IntroSoundPrep").start()
    }

    @Synchronized
    private fun buildOnce(): ShortArray {
        pcm?.let { return it }
        val made = build()
        pcm = made
        return made
    }

    fun play() {
        Thread({
            try {
                stop()
                val data = buildOnce()
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(data, 0, data.size)
                t.setVolume(0.85f)
                track = t
                t.play()
            } catch (e: Throwable) {
            }
        }, "IntroSoundPlay").start()
    }

    fun stop() {
        try {
            val t = track
            track = null
            if (t != null) {
                try { t.stop() } catch (e: Exception) { }
                t.release()
            }
        } catch (e: Throwable) {
        }
    }

    // ---------- sound design ----------

    private fun build(): ShortArray {
        val n = (RATE * SECONDS).toInt()
        val f = FloatArray(n)
        val rnd = java.util.Random(11)

        fun env(t: Float, atk: Float, dec: Float): Float =
            if (t < 0f) 0f else if (t < atk) t / atk else exp(-(t - atk) / dec)

        fun tone(start: Float, f0: Float, f1: Float, dur: Float, amp: Float, atk: Float, dec: Float) {
            val s0 = (start * RATE).toInt()
            val len = ((dur + dec * 4f) * RATE).toInt()
            var phase = 0.0
            for (k in 0 until len) {
                val idx = s0 + k
                if (idx >= n) break
                val t = k / RATE.toFloat()
                val freq = f0 + (f1 - f0) * min(1f, t / dur)
                phase += 2.0 * PI * freq / RATE
                f[idx] += (sin(phase).toFloat()) * amp * env(t, atk, dec)
            }
        }

        // 1. airy rise (soft filtered noise that opens up and swells)
        var lp = 0f
        val riseLen = (RATE * 1.5f).toInt()
        for (i in 0 until riseLen) {
            val x = (i / RATE.toFloat() / 1.4f).coerceIn(0f, 1f)
            val a = 0.02f + 0.28f * x * x
            lp += a * ((rnd.nextFloat() * 2f - 1f) - lp)
            val swell = sin(PI * x).toFloat().pow(2f)
            f[i] += lp * swell * 1.5f
        }

        // 2. bloom when the ball forms (about 1.3 s)
        tone(1.30f, 220f, 520f, 0.18f, 0.40f, 0.012f, 0.10f)
        tone(1.30f, 92f, 58f, 0.40f, 0.62f, 0.006f, 0.18f)
        tone(1.34f, 1318.5f, 1318.5f, 0.10f, 0.14f, 0.004f, 0.36f)
        tone(1.40f, 1975.5f, 1975.5f, 0.10f, 0.08f, 0.004f, 0.30f)

        // 3. three soft heartbeat pulses
        tone(2.20f, 150f, 86f, 0.22f, 0.52f, 0.006f, 0.09f)
        tone(2.70f, 150f, 86f, 0.22f, 0.40f, 0.006f, 0.09f)
        tone(3.20f, 150f, 86f, 0.22f, 0.30f, 0.006f, 0.09f)
        tone(2.20f, 880f, 880f, 0.05f, 0.05f, 0.004f, 0.16f)

        // 4. tiny glass ticks as the buttons arrive
        tone(3.40f, 2600f, 2600f, 0.03f, 0.10f, 0.001f, 0.012f)
        tone(3.60f, 2600f, 2600f, 0.03f, 0.10f, 0.001f, 0.012f)
        tone(3.80f, 2600f, 2600f, 0.03f, 0.10f, 0.001f, 0.012f)

        // 5. calm closing chime
        tone(4.15f, 784f, 784f, 0.40f, 0.10f, 0.010f, 0.22f)
        tone(4.18f, 988f, 988f, 0.40f, 0.08f, 0.010f, 0.22f)
        tone(4.21f, 1175f, 1175f, 0.40f, 0.06f, 0.010f, 0.22f)

        var peak = 0.0001f
        for (v in f) peak = maxOf(peak, abs(v))
        val gain = 0.55f / peak
        val fade = (RATE * 0.12f).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            var v = f[i] * gain
            val left = n - i
            if (left < fade) v *= left / fade.toFloat()
            out[i] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        return out
    }
}
