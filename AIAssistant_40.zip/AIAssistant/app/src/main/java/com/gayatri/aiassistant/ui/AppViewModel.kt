package com.gayatri.aiassistant.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.ai.LiveEngine
import com.gayatri.aiassistant.ai.GeminiClient
import com.gayatri.aiassistant.ai.PhoneActions
import com.gayatri.aiassistant.ai.Prompts
import com.gayatri.aiassistant.ai.SpeechOut
import com.gayatri.aiassistant.data.AppSettings
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.data.ChatEntry
import com.gayatri.aiassistant.data.SHOW_CHAT_HISTORY
import com.gayatri.aiassistant.data.Perms
import com.gayatri.aiassistant.data.Prefs
import com.gayatri.aiassistant.service.AppBridge
import com.gayatri.aiassistant.service.WakeService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

enum class Route { Home, Settings, Voice, Colors, Language, Style, Phone }

class AppViewModel(private val app: Application) : AndroidViewModel(app), Engine.Callback {

    private val prefs = Prefs(app)

    var settings by mutableStateOf(prefs.load().also { C.apply(orbColors(it).first, orbColors(it).second) })
        private set
    var history by mutableStateOf(prefs.history())
        private set
    var onboarded by mutableStateOf(prefs.onboarded)
    var route by mutableStateOf(Route.Home)

    /** Counts every time the app is opened; the home screen plays its opening animation once per count. */
    var introTick by mutableStateOf(0)
    var introShown = -1
    var state by mutableStateOf(Engine.State.Idle)
        private set
    var heard by mutableStateOf("")
        private set
    var reply by mutableStateOf("")
        private set
    var message by mutableStateOf<String?>(null)

    /** The real reason of the last problem (shown in a banner on the screen until the user closes it). */
    var error by mutableStateOf<String?>(null)
    var cameraOn by mutableStateOf(false)
        private set

    @Volatile
    private var latestFrame: String? = null
    var showProfile by mutableStateOf(false)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val engine = LiveEngine(app, scope, this)
    private val previewOut = SpeechOut(app, GeminiClient(PhoneActions(app)))

    init {
        if (!SHOW_CHAT_HISTORY) {
            prefs.clearHistory()
            history = emptyList()
        }
        previewOut.onNotice = { error = it }
        AppBridge.onWake = {
            if (state == Engine.State.Idle) startSession(Prompts.greeting(settings))
        }
    }

    // ---------- settings ----------

    fun update(block: (AppSettings) -> AppSettings) {
        settings = block(settings)
        prefs.save(settings)
        retheme()
    }

    /** Recolours the whole app from the chosen orb colours. */
    private fun retheme() {
        val (a, b) = orbColors(settings)
        C.apply(a, b)
    }

    private fun reload() {
        settings = prefs.load()
        retheme()
    }

    fun finishOnboarding() {
        prefs.onboarded = true
        onboarded = true
    }

    fun setHandsFree(on: Boolean) {
        if (on) {
            if (!Perms.micOk(app) || !Perms.overlayOk(app)) {
                message = "For hands-free, first allow the microphone and 'Display over other apps'. Opening Phone control."
                route = Route.Phone
                return
            }
            update { it.copy(handsFree = true) }
            WakeService.start(app)
        } else {
            update { it.copy(handsFree = false) }
            WakeService.stopIt(app)
        }
    }

    /** Start the background listener again after the app opens, if the user had switched it on. */
    fun ensureServiceIfNeeded() {
        reload() // the assistant may have switched hands-free off while the app was closed
        if (settings.handsFree && Perms.micOk(app) && WakeService.instance == null) {
            try {
                WakeService.start(app)
            } catch (e: Exception) {
            }
        }
    }

    fun deleteHistory(id: Long) {
        prefs.deleteHistory(id)
        history = prefs.history()
    }

    // ---------- conversation ----------

    private fun startSession(greeting: String?) {
        if (settings.apiKey.isBlank()) {
            message = "First add your Gemini API key in Profile."
            showProfile = true
            return
        }
        previewOut.stop()
        WakeService.pause()
        heard = ""
        reply = ""
        engine.begin(greeting)
    }

    fun toggleMic() {
        if (state != Engine.State.Idle) {
            engine.stop()
        } else {
            startSession(null)
        }
    }

    fun sendText(text: String) {
        if (settings.apiKey.isBlank()) {
            message = "First add your Gemini API key in Profile."
            showProfile = true
            return
        }
        WakeService.pause()
        previewOut.stop()
        heard = text
        reply = ""
        engine.sendText(text)
    }

    fun onFrame(b64: String) {
        latestFrame = b64
        if (cameraOn) engine.sendFrame(b64)
    }

    /** Turns the live camera on or off. The talk keeps going; with the camera on, the assistant sees what it sees. */
    fun setCamera(on: Boolean) {
        if (on) {
            if (settings.apiKey.isBlank()) {
                message = "First add your Gemini API key in Profile."
                showProfile = true
                return
            }
            latestFrame = null
            cameraOn = true
            if (state == Engine.State.Idle) startSession(null)
        } else {
            cameraOn = false
            latestFrame = null
            engine.cameraOff()
        }
    }

    fun previewVoice(id: String) {
        if (state != Engine.State.Idle) engine.stop()
        val s = settings
        val name = if (s.userName.isBlank()) "" else " ${s.userName.trim()}"
        previewOut.preview(scope, Catalog.voice(id).sample.replace("{user}", name), id, s.apiKey)
    }

    /** Status of "Teach the name" (empty when idle). */
    var teaching by mutableStateOf("")
        private set

    /** The user says the wake name a few times; we keep how this phone's listener wrote it, so any name works. */
    fun teachName() {
        if (!Perms.micOk(app)) {
            message = "Allow the microphone first (Settings > Phone control)."
            return
        }
        if (teaching.startsWith("Listening")) return
        val s = settings
        com.gayatri.aiassistant.service.WakeService.pause()
        teaching = "Listening for 9 seconds... say \"${s.wakeName}\" 3 times, clearly, with a short pause each time."
        com.gayatri.aiassistant.service.VoskWake(app).learn(9) { list, err ->
            val keep = list.map { it.trim().lowercase() }
                .filter { it != "[unk]" && it.length >= 3 && it.split(" ").size <= 3 && it.all { c -> c in 'a'..'z' || c == ' ' } }
                .distinct()
            if (keep.isNotEmpty()) prefs.setLearned(s.wakeName, keep)
            teaching = when {
                err != null -> "Could not listen: $err"
                keep.isEmpty() -> "I could not catch it. I heard: ${list.joinToString().ifBlank { "nothing" }}. Try again, a little closer to the phone."
                else -> "Learned how \"${s.wakeName}\" sounds: ${keep.joinToString(", ")}. Hands-free will use this."
            }
            com.gayatri.aiassistant.service.WakeService.resume()
        }
    }

    fun stopPreview() {
        previewOut.stop()
    }

    // ---------- Engine.Callback ----------

    override fun onState(s: Engine.State) {
        state = s
    }

    override fun onHeard(text: String, final: Boolean) {
        heard = text
        if (final && text.isNotBlank()) {
            reply = ""
            if (SHOW_CHAT_HISTORY) {
                prefs.addHistory(text)
                history = prefs.history()
            }
        }
    }

    override fun onReply(text: String) {
        reply = text
    }

    override fun onError(msg: String) {
        error = msg
    }

    override fun onSessionEnd() {
        reload()
        cameraOn = false
        latestFrame = null
        WakeService.resume()
    }

    override fun onCleared() {
        engine.stop()
        previewOut.stop()
        AppBridge.onWake = null
        scope.cancel()
        super.onCleared()
    }
}
