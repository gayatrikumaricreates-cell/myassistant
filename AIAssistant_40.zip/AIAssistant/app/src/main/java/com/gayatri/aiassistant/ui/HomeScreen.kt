package com.gayatri.aiassistant.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import com.gayatri.aiassistant.ai.IntroSound
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.gayatri.aiassistant.ai.Engine
import com.gayatri.aiassistant.data.Perms

@Composable
fun HomeScreen(vm: AppViewModel) {
    val s = vm.settings
    val (ca, cb) = orbColors(s)
    val active = vm.state != Engine.State.Idle
    var typing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }

    val ctx = LocalContext.current

    // Opening animation: plays each time the app is opened. A tap anywhere jumps straight to the finished screen.
    val needIntro = remember { vm.introShown != vm.introTick }
    val clock = remember { Animatable(if (needIntro) 0f else INTRO_MS.toFloat()) }
    var playing by remember { mutableStateOf(false) }
    var orbCenter by remember { mutableStateOf(Offset.Zero) }
    val orbR = with(LocalDensity.current) { 140.dp.toPx() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(vm.introTick) {
        if (vm.introShown != vm.introTick) {
            vm.introShown = vm.introTick
            playing = false
            clock.snapTo(0f)
            snapshotFlow { vm.showProfile }.first { !it }
            playing = true
            IntroSound.play()
            clock.animateTo(INTRO_MS.toFloat(), tween(INTRO_MS, easing = LinearEasing))
            playing = false
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.setCamera(true) else vm.error = "The camera cannot start because camera permission is not given. Tap Allow in Settings > Phone control."
    }

    Box(Modifier.fillMaxSize().background(ScreenBrush)) {
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    val x = seg(clock.value, 2900f, 3700f)
                    alpha = smooth(x)
                    translationY = -16.dp.toPx() * (1f - outCubic(x))
                }
                .padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CircleButton(Icons.Rounded.Person, 40.dp) { vm.showProfile = true }
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(C.scrim)
                    .border(1.dp, C.cardBorder, RoundedCornerShape(50))
                    .padding(horizontal = 18.dp, vertical = 7.dp)
            ) {
                Text(s.wakeName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            CircleButton(Icons.Rounded.Tune, 40.dp) { vm.route = Route.Settings }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
        if (vm.cameraOn) {
            LiveCameraPreview(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(width = 104.dp, height = 140.dp)
                    .padding(top = 4.dp),
                onFrame = { vm.onFrame(it) },
                onError = { vm.error = it; vm.setCamera(false) }
            )
        }
        Column(
            Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Orb(
                a = ca,
                b = cb,
                modifier = Modifier
                    .size(280.dp)
                    .onGloballyPositioned { orbCenter = it.boundsInRoot().center }
                    .graphicsLayer {
                        val x = clock.value
                        val pop = if (x < 1300f) 0f else outBack(seg(x, 1300f, 2100f))
                        val pulse = 0.05f * (bump(x, 2200f, 260f) + 0.8f * bump(x, 2700f, 260f) + 0.6f * bump(x, 3200f, 260f))
                        scaleX = pop * (1f + pulse)
                        scaleY = pop * (1f + pulse)
                        alpha = seg(x, 1300f, 1550f)
                    },
                level = when (vm.state) {
                    Engine.State.Speaking -> 1f
                    Engine.State.Listening -> 0.7f
                    Engine.State.Thinking -> 0.4f
                    Engine.State.Idle -> 0.1f
                },
                calm = s.mixSpeed == "Calm",
                speaking = vm.state == Engine.State.Speaking
            )

            if (!active && vm.heard.isEmpty() && vm.reply.isEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Tap the mic to talk live, or just say",
                    color = C.sub,
                    fontSize = 12.sp,
                    modifier = Modifier.graphicsLayer { alpha = smooth(seg(clock.value, 3300f, 4000f)) }
                )
                Text(
                    "“Hey ${s.wakeName}”",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.graphicsLayer { alpha = smooth(seg(clock.value, 3300f, 4000f)) }
                )
            } else {
                Waves(active = vm.state == Engine.State.Listening || vm.state == Engine.State.Speaking, color = ca)
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (vm.heard.isNotEmpty()) {
                        Box(
                            Modifier
                                .align(Alignment.End)
                                .clip(RoundedCornerShape(14.dp))
                                .background(C.chip)
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(vm.heard, color = C.sub, fontSize = 12.sp)
                        }
                    }
                    if (vm.reply.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            vm.reply,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Text(
                    when (vm.state) {
                        Engine.State.Listening -> "${s.wakeName} is listening..."
                        Engine.State.Thinking -> "${s.wakeName} is thinking..."
                        Engine.State.Speaking -> "${s.wakeName} is speaking..."
                        Engine.State.Idle -> ""
                    },
                    color = C.sub,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        }

        if (typing) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppField(
                    value = draft,
                    onChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = "Type here..."
                )
                CircleButton(Icons.Rounded.Send, 46.dp, tint = C.teal) {
                    val t = draft.trim()
                    if (t.isNotEmpty()) {
                        draft = ""
                        typing = false
                        vm.sendText(t)
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp, top = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleButton(
                Icons.Rounded.Keyboard,
                48.dp,
                modifier = Modifier.graphicsLayer { rise(clock.value, 3300f, 40.dp.toPx()) }
            ) { typing = !typing }

            Box(Modifier.graphicsLayer { rise(clock.value, 3500f, 40.dp.toPx()) }) {
            Box(
                Modifier
                    .size(72.dp)
                    .raisedButton(CircleShape, 6.dp) { vm.toggleMic() }
                    .border(2.dp, ca, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (active) Icons.Rounded.Stop else Icons.Rounded.Mic,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
            }

            CircleButton(
                if (vm.cameraOn) Icons.Rounded.Videocam else Icons.Rounded.PhotoCamera,
                48.dp,
                modifier = Modifier.graphicsLayer { rise(clock.value, 3700f, 40.dp.toPx()) },
                tint = if (vm.cameraOn) C.teal else Color.White
            ) {
                if (vm.cameraOn) {
                    vm.setCamera(false)
                } else if (Perms.cameraOk(ctx)) {
                    vm.setCamera(true)
                } else {
                    cameraPermission.launch(android.Manifest.permission.CAMERA)
                }
            }
        }
    }
    IntroCanvas(
        clock = { clock.value },
        center = { orbCenter },
        orbRadius = orbR,
        a = ca,
        b = cb,
        modifier = Modifier.fillMaxSize()
    )
    if (playing) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures {
                        IntroSound.stop()
                        playing = false
                        scope.launch { clock.snapTo(INTRO_MS.toFloat()) }
                    }
                }
        )
    }
    }
}
