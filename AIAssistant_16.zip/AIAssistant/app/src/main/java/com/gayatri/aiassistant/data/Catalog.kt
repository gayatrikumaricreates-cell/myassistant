package com.gayatri.aiassistant.data

data class VoiceOption(
    val id: String,
    val desc: String,
    val traits: String,
    val female: Boolean,
    val geminiVoice: String,
    val persona: String = "",
    val sample: String = ""
)

data class StyleOption(
    val key: String,
    val label: String,
    val prompt: String,
    val ttsPrefix: String
)

data class LanguageOption(
    val key: String,
    val label: String,
    val prompt: String
)

object Catalog {
    val voices = listOf(
        VoiceOption("Aria", "Warm & friendly", "Smiling · Medium pace", true, "Sulafat",
            "Speak with a warm, round, friendly woman's voice at a relaxed medium pace and a smile in the tone.",
            "हाय{user}, मैं Aria हूँ। बताइए, आज मैं आपकी क्या मदद करूँ? हा हा, मुझे तो आपसे बात करके मज़ा आता है।"),
        VoiceOption("Meera", "Soft & soothing", "Whispery · Slow", true, "Achernar",
            "Speak with a very soft, quiet, gentle woman's voice, slowly, almost whispering and soothing.",
            "नमस्ते{user}... मैं Meera हूँ। आराम से बात कीजिए, मैं यहीं हूँ, सब सुन रही हूँ।"),
        VoiceOption("Kavya", "Bubbly & cheerful", "Bright · Fast · Laughs", true, "Laomedeia",
            "Speak with a bright, bubbly, high-spirited young woman's voice, fast and excited, laughing often.",
            "अरे वाह{user}! मैं Kavya हूँ! हे हे, चलिए आज कुछ मज़ेदार करते हैं, बोलिए बोलिए!"),
        VoiceOption("Nova", "Mature & confident", "Low · Polished · Slow", true, "Gacrux",
            "Speak with a mature, low-pitched, composed and polished woman's voice, slow and authoritative.",
            "नमस्कार{user}। मैं Nova हूँ। आप जो भी काम बताएँगे, मैं उसे सलीक़े से कर दूँगी।"),
        VoiceOption("Siya", "Young & playful", "Light · Teasing · Quick", true, "Leda",
            "Speak with a youthful, light, high-pitched girl's voice, playful and teasing, quick and cheeky.",
            "हेलो हेलो{user}! मैं Siya हूँ। हम्म, आज क्या शरारत करनी है? हे हे हे!"),
        VoiceOption("Arjun", "Deep & powerful", "Gravelly · Slow · Strong", false, "Algenib",
            "Speak with a very deep, low, heavy, slightly gravelly man's voice at a slow, powerful pace.",
            "नमस्ते{user}। मैं Arjun हूँ। हुक्म कीजिए, काम हो जाएगा।"),
        VoiceOption("Dev", "Friendly & easygoing", "Casual · Chatty · Medium", false, "Achird",
            "Speak with a friendly, casual, medium-pitched man's voice at a relaxed, chatty pace.",
            "हाय{user}, मैं Dev हूँ। अरे यार, बताइए क्या चल रहा है? आराम से बात करते हैं।"),
        VoiceOption("Rohan", "Young & energetic", "Lively · Fast · Upbeat", false, "Puck",
            "Speak with a young, high-energy, fast-talking guy's voice, upbeat and lively.",
            "हे{user}! मैं Rohan हूँ! चलो चलो, जल्दी बताओ क्या करना है, मैं तैयार हूँ!"),
        VoiceOption("Kabir", "Calm storyteller", "Smooth · Thoughtful · Slow", false, "Charon",
            "Speak with a calm, smooth, slow storyteller's voice, thoughtful with soft pauses.",
            "नमस्ते{user}... मैं Kabir हूँ। बैठिए, आराम से बात करते हैं। हर बात की अपनी एक कहानी होती है।"),
        VoiceOption("Leo", "Funny & excitable", "Animated · Jokes · Laughs", false, "Fenrir",
            "Speak with an excitable, comedic, expressive man's voice, animated, with sudden bursts of laughter.",
            "ओए{user}! मैं Leo हूँ! हा हा हा, तैयार हो जाइए, आज तो हँसी का तूफ़ान आने वाला है!")
    )

    fun voice(id: String): VoiceOption = voices.firstOrNull { it.id == id } ?: voices[0]

    val languages = listOf(
        LanguageOption(
            "mix", "Hindi + English mix",
            "Reply in natural Hinglish: write Hindi in Devanagari script and keep common English words in English letters, the way people really talk. Match the language the user used."
        ),
        LanguageOption(
            "hindi", "Only Hindi",
            "Reply only in simple spoken Hindi written in Devanagari script."
        ),
        LanguageOption(
            "english", "Only English",
            "Reply only in simple spoken English."
        )
    )

    fun language(key: String): LanguageOption = languages.firstOrNull { it.key == key } ?: languages[0]

    val styles = listOf(
        StyleOption(
            "friendly", "Friendly, expressive, laughs",
            "Be like a warm, close friend: expressive, cheerful, show real emotion, and laugh naturally at funny things.",
            "Say in a warm, natural, expressive and friendly human way, like chatting with a close friend"
        ),
        StyleOption(
            "calm", "Calm & gentle",
            "Be calm, gentle and soothing. Speak softly and patiently.",
            "Say in a calm, gentle, soothing human voice"
        ),
        StyleOption(
            "playful", "Playful & funny",
            "Be playful, witty and funny. Make light jokes and laugh often.",
            "Say in a playful, cheerful, laughing human way"
        ),
        StyleOption(
            "crisp", "Short & to the point",
            "Be brief and direct: one or two short sentences, but still warm and human.",
            "Say in a clear, confident, natural human voice"
        )
    )

    fun style(key: String): StyleOption = styles.firstOrNull { it.key == key } ?: styles[0]
}
