package com.gayatri.aiassistant.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.gayatri.aiassistant.data.AppSettings

/**
 * Every colour of the app comes from the two orb colours. When the orb colours change,
 * [C.apply] recomputes the background, cards, buttons, fields and accents, and everything redraws.
 */
object C {
    var bgTop by mutableStateOf(Color(0xFF020C0E))
    var bgMid by mutableStateOf(Color(0xFF05191C))
    var bgBottom by mutableStateOf(Color(0xFF0A4A48))
    var cardTop by mutableStateOf(Color(0xFF0C2A2D))
    var cardBottom by mutableStateOf(Color(0xFF081D20))
    var cardBorder by mutableStateOf(Color(0x2E7FF5E4))
    var teal by mutableStateOf(Color(0xFF4FE3D0))
    var sub by mutableStateOf(Color(0xFFA9D8D2))
    var danger by mutableStateOf(Color(0xFFE0456A))
    var field by mutableStateOf(Color(0xFF071A1D))
    var sheet by mutableStateOf(Color(0xFF0B2427))
    var faceTop by mutableStateOf(Color(0xFF14393D))
    var faceBottom by mutableStateOf(Color(0xFF0B2327))
    var ledge by mutableStateOf(Color(0xFF031012))
    var onAccent by mutableStateOf(Color(0xFF03211F))
    var chip by mutableStateOf(Color(0x2EFFFFFF))
    var scrim by mutableStateOf(Color(0xB3000000))

    fun apply(a: Color, b: Color) {
        val mix = lerp(a, b, 0.5f)
        val k = Color.Black
        bgTop = lerp(k, a, 0.06f)
        bgMid = lerp(k, mix, 0.13f)
        bgBottom = lerp(k, a, 0.34f)
        cardTop = lerp(k, mix, 0.20f)
        cardBottom = lerp(k, mix, 0.11f)
        cardBorder = lerp(a, Color.White, 0.3f).copy(alpha = 0.20f)
        teal = lerp(a, Color.White, 0.22f)
        sub = lerp(a, Color.White, 0.72f).copy(alpha = 0.92f)
        field = lerp(k, mix, 0.09f)
        sheet = lerp(k, mix, 0.15f)
        faceTop = lerp(k, mix, 0.30f)
        faceBottom = lerp(k, mix, 0.16f)
        ledge = lerp(k, mix, 0.05f)
        onAccent = lerp(k, a, 0.10f)
        chip = lerp(a, Color.White, 0.5f).copy(alpha = 0.16f)
        scrim = lerp(k, a, 0.05f).copy(alpha = 0.72f)
    }
}

val ScreenBrush: Brush
    get() = Brush.verticalGradient(listOf(C.bgTop, C.bgMid, C.bgBottom))

val CardBrush: Brush
    get() = Brush.verticalGradient(listOf(C.cardTop, C.cardBottom))

data class OrbTheme(val name: String, val a: Color, val b: Color)

/** Eight hand-picked colour pairs. Choosing one recolours the orb, the background, the buttons and the cards. */
val OrbThemes = listOf(
    OrbTheme("Orbit", Color(0xFF2FD9C4), Color(0xFF2A7FDB)),
    OrbTheme("Ember", Color(0xFFFF5470), Color(0xFFFF9A5C)),
    OrbTheme("Orchid", Color(0xFFF06BDB), Color(0xFF8E6BFF)),
    OrbTheme("Glacier", Color(0xFF74C0FC), Color(0xFFB4A7FF)),
    OrbTheme("Emerald", Color(0xFF3DDC84), Color(0xFFC6F135)),
    OrbTheme("Rose Quartz", Color(0xFFFF7EB6), Color(0xFFFFB3A7)),
    OrbTheme("Sunbeam", Color(0xFFFFD23F), Color(0xFFFF8A3D)),
    OrbTheme("Nebula", Color(0xFF7B6CFF), Color(0xFF3FC8FF))
)

val Palette1 = listOf(
    Color(0xFF2FD9C4), Color(0xFFFFB84D), Color(0xFF3EC8F5),
    Color(0xFF9B6BFF), Color(0xFF4CD964), Color(0xFFFF4D5E)
)

val Palette2 = listOf(
    Color(0xFF2A7FDB), Color(0xFFFF6A3D), Color(0xFF3D6BFF),
    Color(0xFFFF5CAF), Color(0xFFC8F03C), Color(0xFFFF9A4D)
)

fun orbColors(s: AppSettings): Pair<Color, Color> =
    if (s.useMix) {
        Palette1[s.color1.coerceIn(0, Palette1.size - 1)] to Palette2[s.color2.coerceIn(0, Palette2.size - 1)]
    } else {
        val t = OrbThemes.firstOrNull { it.name == s.theme } ?: OrbThemes[0]
        t.a to t.b
    }
