package com.gayatri.aiassistant.ui

import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Base64
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * A small live camera window. While it is open the camera keeps running; about every 0.7 second the newest
 * picture is handed to [onFrame] (small JPEG as base64), so the assistant can always see what the camera sees.
 */
@Composable
fun LiveCameraPreview(
    modifier: Modifier = Modifier,
    onFrame: (String) -> Unit,
    onError: (String) -> Unit
) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var front by remember { mutableStateOf(false) }
    val frameSink by rememberUpdatedState(onFrame)
    val errorSink by rememberUpdatedState(onError)
    val executor = remember { Executors.newSingleThreadExecutor() }
    val previewView = remember {
        PreviewView(ctx).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
    }

    DisposableEffect(front) {
        val future = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                var last = 0L
                analysis.setAnalyzer(executor) { proxy ->
                    try {
                        val now = System.currentTimeMillis()
                        if (now - last >= 700) {
                            last = now
                            val raw = proxy.toBitmap()
                            val m = Matrix()
                            m.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                            val scale = 640f / max(raw.width, raw.height).toFloat()
                            if (scale < 1f) m.postScale(scale, scale)
                            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                            val out = ByteArrayOutputStream()
                            bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
                            frameSink(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
                        }
                    } catch (e: Exception) {
                        // one bad picture is skipped; the next one will work
                    } finally {
                        proxy.close()
                    }
                }
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                p.unbindAll()
                p.bindToLifecycle(owner, selector, preview, analysis)
            } catch (e: Exception) {
                errorSink("The camera could not start.\nReason: ${e.javaClass.simpleName}: ${e.message ?: "no details"}")
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            try {
                provider?.unbindAll()
            } catch (e: Exception) {
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { executor.shutdown() }
    }

    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, C.cardBorder, RoundedCornerShape(16.dp))
    ) {
        AndroidView(factory = { previewView }, modifier = Modifier.matchParentSize())
        CircleButton(
            Icons.Rounded.FlipCameraAndroid,
            30.dp,
            modifier = Modifier.align(Alignment.BottomEnd)
        ) { front = !front }
    }
}
