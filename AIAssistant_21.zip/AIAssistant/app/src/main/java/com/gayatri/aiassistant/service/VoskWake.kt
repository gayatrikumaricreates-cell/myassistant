package com.gayatri.aiassistant.service

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * "Smooth" wake-name listening. It reads the microphone directly and understands speech on the phone itself
 * (Vosk), so it does NOT take over the phone's audio: videos and music keep playing at full volume, and the
 * microphone dot stays steady instead of blinking. The small language file is downloaded once (about 40 MB).
 */
class VoskWake(private val ctx: Context) {

    companion object {
        private const val RATE = 16000
        private const val EN = "vosk-model-small-en-in-0.4"
        private const val HI = "vosk-model-small-hi-0.22"

        @Volatile
        private var model: Model? = null

        @Volatile
        private var modelName: String = ""
    }

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false
    private var thread: Thread? = null

    fun start(
        language: String,
        wakeName: String,
        onWake: () -> Unit,
        onStatus: (String) -> Unit,
        onFail: (String) -> Unit
    ) {
        if (running) return
        running = true
        val name = EN // one English model hears every name; the matcher compares by sound
        val t = Thread({
            var rec: AudioRecord? = null
            var recognizer: Recognizer? = null
            try {
                val m = loadModel(name, onStatus)
                if (!running) return@Thread
                recognizer = Recognizer(m, RATE.toFloat())
                val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuf <= 0) throw IllegalStateException("The microphone cannot run at 16 kHz")
                val size = maxOf(minBuf, 8192)
                rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size * 2
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("The microphone could not start")
                rec.startRecording()
                val buf = ByteArray(2048)
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) throw IllegalStateException("Problem reading the microphone (code $n)")
                    if (n == 0) continue
                    val text = if (recognizer.acceptWaveForm(buf, n)) {
                        JSONObject(recognizer.result).optString("text")
                    } else {
                        JSONObject(recognizer.partialResult).optString("partial")
                    }
                    if (text.isNotBlank() && WakeMatcher.matches(listOf(text), wakeName)) {
                        running = false
                        main.post { onWake() }
                    }
                }
            } catch (e: Throwable) {
                if (running) {
                    running = false
                    val msg = "The smooth name listener could not start, so the classic one is used.\nReason: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
                    main.post { onFail(msg) }
                }
            } finally {
                try { rec?.stop() } catch (e: Throwable) { }
                try { rec?.release() } catch (e: Throwable) { }
                try { recognizer?.close() } catch (e: Throwable) { }
            }
        }, "VoskWake")
        thread = t
        t.start()
    }

    /** Stops listening and frees the microphone. With full = true the language file is also dropped from memory. */
    fun stop(full: Boolean = false) {
        running = false
        val t = thread
        thread = null
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(800) } catch (e: Exception) { }
        }
        if (full) {
            try { model?.close() } catch (e: Throwable) { }
            model = null
            modelName = ""
        }
    }

    // ---------------------------------------------------------------- language file

    private fun loadModel(name: String, onStatus: (String) -> Unit): Model {
        val cached = model
        if (cached != null && modelName == name) return cached
        try { model?.close() } catch (e: Throwable) { }
        model = null
        val dir = File(File(ctx.filesDir, "vosk"), name)
        val ok = File(dir, ".ok")
        if (!ok.exists()) {
            val packed = try { ctx.assets.open("$name.zip") } catch (e: Exception) { null }
            if (packed != null) {
                // the language file is inside the app: just unpack it (a few seconds, only once)
                main.post { onStatus("Getting the wake-name listener ready (first time only)...") }
                val root = File(ctx.filesDir, "vosk")
                root.mkdirs()
                File(root, name).deleteRecursively()
                packed.use { unzip(it, root, name, false) }
            } else {
                main.post { onStatus("Downloading the wake-name language file (about 40 MB) for the first time. Keep the internet on.") }
                download(name)
            }
        }
        try { LibVosk.setLogLevel(LogLevel.WARNINGS) } catch (e: Throwable) { }
        val m = Model(dir.absolutePath)
        model = m
        modelName = name
        return m
    }

    private fun download(name: String) {
        val root = File(ctx.filesDir, "vosk")
        root.mkdirs()
        val target = File(root, name)
        if (target.exists()) target.deleteRecursively()
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode !in 200..299) throw IllegalStateException("Download failed (HTTP ${conn.responseCode})")
            unzip(conn.inputStream, root, name, true)
            File(target, ".ok").writeText("ok")
        } catch (e: Throwable) {
            try { target.deleteRecursively() } catch (x: Throwable) { }
            throw e
        } finally {
            conn.disconnect()
        }
    }

    /** Unpacks the model zip into [root] (never outside it) and marks it ready. */
    private fun unzip(input: java.io.InputStream, root: File, name: String, stoppable: Boolean) {
        val target = File(root, name)
        try {
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                val rootPath = root.canonicalPath + File.separator
                while (!stoppable || running) {
                    val e = zin.nextEntry ?: break
                    val out = File(root, e.name)
                    if (!out.canonicalPath.startsWith(rootPath)) continue
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { fo -> zin.copyTo(fo) }
                    }
                }
            }
            if (stoppable && !running) throw IllegalStateException("The download stopped midway")
            if (!File(target, "am").exists() && !File(target, "conf").exists()) {
                throw IllegalStateException("The language file was incomplete")
            }
            File(target, ".ok").writeText("ok")
        } catch (e: Throwable) {
            try { target.deleteRecursively() } catch (x: Throwable) { }
            throw e
        }
    }
}
