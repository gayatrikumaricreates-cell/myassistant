package com.gayatri.aiassistant.service

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * "Smooth" wake-name listening. It reads the microphone directly and understands speech on the phone itself
 * (Vosk), so it does NOT take over the phone's audio: videos and music keep playing at full volume, and the
 * microphone dot stays steady instead of blinking. The small language file is downloaded once (about 40 MB).
 */
class VoskWake(private val ctx: Context) {

    companion object {
        private const val RATE = 16000
        private const val EN = "vosk-model-small-en-in-0.4"
        private const val HI = "vosk-model-small-hi-0.22"

        @Volatile
        private var model: Model? = null

        @Volatile
        private var modelName: String = ""
    }

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false
    private var thread: Thread? = null
    private var lastHeard = ""

    fun start(
        language: String,
        wakeName: String,
        onWake: () -> Unit,
        onStatus: (String) -> Unit,
        onFail: (String) -> Unit,
        onHeard: (String) -> Unit = {},
        learned: Set<String> = emptySet()
    ) {
        if (running) return
        running = true
        val name = EN // one English model hears every name; the matcher compares by sound
        val t = Thread({
            var rec: AudioRecord? = null
            var recognizer: Recognizer? = null
            var narrow: Recognizer? = null
            try {
                val m = loadModel(name, onStatus)
                if (!running) return@Thread
                recognizer = Recognizer(m, RATE.toFloat())
                try { recognizer.setMaxAlternatives(5) } catch (e: Throwable) { }
                // A second listener that only chooses between words that sound like the wake name (or "unknown").
                // It is far more accurate than free listening, because it picks the name's sound-alikes from the
                // words this model actually knows (e.g. "orbit" may be known as "or bit").
                val base = (try { candidatesFor(name, wakeName) } catch (e: Throwable) { emptySet() }) + learned
                // the name alone, or after a greeting: "nova", "hey nova", "hi nova"
                val cands = LinkedHashSet<String>()
                for (c in base) {
                    cands.add(c)
                    for (g in listOf("hey", "hi", "hello", "ok")) cands.add("$g $c")
                }
                if (cands.isNotEmpty()) {
                    try {
                        val g = org.json.JSONArray()
                        cands.forEach { g.put(it) }
                        g.put("[unk]")
                        narrow = Recognizer(m, RATE.toFloat(), g.toString())
                    } catch (e: Throwable) {
                        narrow = null
                    }
                }
                val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuf <= 0) throw IllegalStateException("The microphone cannot run at 16 kHz")
                val size = maxOf(minBuf, 8192)
                rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size * 2
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("The microphone could not start")
                rec.startRecording()
                val buf = ByteArray(2048)
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) throw IllegalStateException("Problem reading the microphone (code $n)")
                    if (n == 0) continue
                    val heard = ArrayList<String>()
                    var narrowHit = false
                    val nr = narrow
                    if (nr != null) {
                        val t = try {
                            if (nr.acceptWaveForm(buf, n)) JSONObject(nr.result).optString("text")
                            else JSONObject(nr.partialResult).optString("partial")
                        } catch (e: Throwable) { "" }
                        if (t.isNotBlank() && t != "[unk]" && cands.contains(t.trim())) narrowHit = true
                    }
                    if (recognizer.acceptWaveForm(buf, n)) {
                        val j = JSONObject(recognizer.result)
                        j.optString("text").takeIf { it.isNotBlank() }?.let { heard.add(it) }
                        val alts = j.optJSONArray("alternatives")
                        if (alts != null) {
                            for (k in 0 until alts.length()) {
                                alts.optJSONObject(k)?.optString("text")?.takeIf { it.isNotBlank() }?.let { heard.add(it) }
                            }
                        }
                    } else {
                        JSONObject(recognizer.partialResult).optString("partial").takeIf { it.isNotBlank() }?.let { heard.add(it) }
                    }
                    if (heard.isNotEmpty()) {
                        val last = heard[0]
                        if (last != lastHeard) {
                            lastHeard = last
                            main.post { onHeard(last) }
                        }
                    }
                    if (narrowHit || (heard.isNotEmpty() && WakeMatcher.matches(heard, wakeName))) {
                        running = false
                        main.post { onWake() }
                    }
                }
            } catch (e: Throwable) {
                if (running) {
                    running = false
                    val msg = "The smooth name listener could not start, so the classic one is used.\nReason: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
                    main.post { onFail(msg) }
                }
            } finally {
                try { rec?.stop() } catch (e: Throwable) { }
                try { rec?.release() } catch (e: Throwable) { }
                try { recognizer?.close() } catch (e: Throwable) { }
                try { narrow?.close() } catch (e: Throwable) { }
            }
        }, "VoskWake")
        thread = t
        t.start()
    }

    /** Stops listening and frees the microphone. With full = true the language file is also dropped from memory. */
    fun stop(full: Boolean = false) {
        running = false
        val t = thread
        thread = null
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(800) } catch (e: Exception) { }
        }
        if (full) {
            try { model?.close() } catch (e: Throwable) { }
            model = null
            modelName = ""
        }
    }

    // ---------------------------------------------------------------- language file

    private fun loadModel(name: String, onStatus: (String) -> Unit): Model {
        val cached = model
        if (cached != null && modelName == name) return cached
        try { model?.close() } catch (e: Throwable) { }
        model = null
        val dir = File(File(ctx.filesDir, "vosk"), name)
        val ok = File(dir, ".ok")
        if (!ok.exists()) {
            val packed = try { ctx.assets.open("$name.zip") } catch (e: Exception) { null }
            if (packed != null) {
                // the language file is inside the app: just unpack it (a few seconds, only once)
                main.post { onStatus("Getting the wake-name listener ready (first time only)...") }
                val root = File(ctx.filesDir, "vosk")
                root.mkdirs()
                File(root, name).deleteRecursively()
                packed.use { unzip(it, root, name, false) }
            } else {
                main.post { onStatus("Downloading the wake-name language file (about 40 MB) for the first time. Keep the internet on.") }
                download(name)
            }
        }
        try { LibVosk.setLogLevel(LogLevel.WARNINGS) } catch (e: Throwable) { }
        val m = Model(dir.absolutePath)
        model = m
        modelName = name
        return m
    }

    private fun download(name: String) {
        val root = File(ctx.filesDir, "vosk")
        root.mkdirs()
        val target = File(root, name)
        if (target.exists()) target.deleteRecursively()
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode !in 200..299) throw IllegalStateException("Download failed (HTTP ${conn.responseCode})")
            unzip(conn.inputStream, root, name, true)
            File(target, ".ok").writeText("ok")
        } catch (e: Throwable) {
            try { target.deleteRecursively() } catch (x: Throwable) { }
            throw e
        } finally {
            conn.disconnect()
        }
    }

    /** Unpacks the model zip into [root] (never outside it) and marks it ready. */
    private fun unzip(input: java.io.InputStream, root: File, name: String, stoppable: Boolean) {
        val target = File(root, name)
        try {
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                val rootPath = root.canonicalPath + File.separator
                while (!stoppable || running) {
                    val e = zin.nextEntry ?: break
                    val out = File(root, e.name)
                    if (!out.canonicalPath.startsWith(rootPath)) continue
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { fo -> zin.copyTo(fo) }
                    }
                }
            }
            if (stoppable && !running) throw IllegalStateException("The download stopped midway")
            if (!File(target, "am").exists() && !File(target, "conf").exists()) {
                throw IllegalStateException("The language file was incomplete")
            }
            File(target, ".ok").writeText("ok")
        } catch (e: Throwable) {
            try { target.deleteRecursively() } catch (x: Throwable) { }
            throw e
        }
    }

    /**
     * Listens for [seconds] seconds and reports how this phone wrote down what the user said, so the wake name can
     * be matched to the user's own pronunciation. Works for any name.
     */
    fun learn(seconds: Int, onDone: (List<String>, String?) -> Unit) {
        running = true
        Thread({
            var rec: AudioRecord? = null
            var r: Recognizer? = null
            val out = LinkedHashSet<String>()
            var err: String? = null
            fun take(j: JSONObject) {
                j.optString("text").takeIf { it.isNotBlank() }?.let { out.add(it) }
                val alts = j.optJSONArray("alternatives")
                if (alts != null) for (k in 0 until alts.length()) {
                    alts.optJSONObject(k)?.optString("text")?.takeIf { it.isNotBlank() }?.let { out.add(it) }
                }
            }
            try {
                val m = loadModel(EN) { }
                r = Recognizer(m, RATE.toFloat())
                try { r.setMaxAlternatives(3) } catch (e: Throwable) { }
                val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuf <= 0) throw IllegalStateException("The microphone cannot run at 16 kHz")
                rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192) * 2
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("The microphone could not start. Another app may be using it.")
                rec.startRecording()
                val buf = ByteArray(2048)
                val end = android.os.SystemClock.elapsedRealtime() + seconds * 1000L
                while (android.os.SystemClock.elapsedRealtime() < end) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) throw IllegalStateException("Problem reading the microphone (code $n)")
                    if (n > 0 && r.acceptWaveForm(buf, n)) take(JSONObject(r.result))
                }
                take(JSONObject(r.finalResult))
            } catch (e: Throwable) {
                err = e.message ?: e.javaClass.simpleName
            } finally {
                try { rec?.stop() } catch (e: Throwable) { }
                try { rec?.release() } catch (e: Throwable) { }
                try { r?.close() } catch (e: Throwable) { }
                try { model?.close() } catch (e: Throwable) { }
                model = null
                modelName = ""
                running = false
            }
            main.post { onDone(out.toList(), err) }
        }, "VoskLearn").start()
    }

    private val candCache = HashMap<String, Set<String>>()

    /**
     * Words (and two-word phrases) from this model's own word list that sound like the wake name.
     * The model file lists every word it knows in graph/words.txt.
     */
    private fun candidatesFor(modelName: String, wakeName: String): Set<String> {
        val target = WakeMatcher.roman(wakeName).replace(" ", "")
        if (target.length < 2) return emptySet()
        val key = "$modelName|$target"
        candCache[key]?.let { return it }
        val f = File(File(File(ctx.filesDir, "vosk"), modelName), "graph/words.txt")
        if (!f.exists()) return emptySet()
        val words = ArrayList<Pair<String, String>>() // word, sound-alike form
        f.forEachLine { line ->
            val w = line.substringBefore(' ').trim().lowercase()
            if (w.length in 2..14 && w.all { it in 'a'..'z' }) words.add(w to WakeMatcher.skel(w))
        }
        val out = LinkedHashSet<String>()
        // single words that sound like the name
        words.map { it to WakeMatcher.dist(it.second, target) }
            .filter { it.second <= maxOf(1, target.length / 3) && kotlin.math.abs(it.first.second.length - target.length) <= 2 }
            .sortedBy { it.second }.take(6).forEach { out.add(it.first.first) }
        // two words said together ("or" + "bit")
        for (k in 2..(target.length - 2)) {
            val left = target.substring(0, k)
            val right = target.substring(k)
            val ls = words.map { it to WakeMatcher.dist(it.second, left) }.filter { it.second <= 1 }.sortedBy { it.second }.take(4)
            val rs = words.map { it to WakeMatcher.dist(it.second, right) }.filter { it.second <= 1 }.sortedBy { it.second }.take(4)
            for (l in ls) for (r in rs) {
                if (WakeMatcher.dist(l.first.second + r.first.second, target) <= 1) out.add(l.first.first + " " + r.first.first)
            }
        }
        val res = out.take(24).toSet()
        candCache[key] = res
        return res
    }
}
