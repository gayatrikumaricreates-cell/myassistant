package com.gayatri.aiassistant.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import androidx.core.content.ContextCompat
import com.gayatri.aiassistant.data.Catalog
import com.gayatri.aiassistant.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * A truly LIVE talk with Gemini (Live API over a WebSocket).
 *  - the microphone stays on all the time and its sound streams to Gemini,
 *  - Gemini answers with its own voice (streamed, so it starts speaking at once),
 *  - the user can speak over it at any moment (it stops and listens),
 *  - camera pictures can be streamed while the live camera is on,
 *  - phone actions (calls, WhatsApp, YouTube ...) are done through tool calls.
 * If the live connection cannot be made at all, the older "listen -> think -> speak" Engine takes over.
 * Used by the app screen and by the "wake from outside" service. Must be used on the main thread.
 */
class LiveEngine(
    ctx: Context,
    private val scope: CoroutineScope,
    private val cb: Engine.Callback
) {
    companion object {
        private const val IDLE_END_MS = 120_000L
        private const val MIC_RATE = 16000
        private const val OUT_RATE = 24000
        private const val MIC_FRAME = 640 // 40 ms: small pieces so Gemini hears you as early as possible
        private const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key="
        private val staticModels = listOf(
            "gemini-3.8-live",
            "gemini-3.1-flash-live-preview",
            "gemini-2.5-flash-native-audio-preview-12-2025",
            "gemini-live-2.5-flash-preview",
            "gemini-2.0-flash-live-001"
        )

        @Volatile
        private var goodModel: String? = null
        private const val KEY_GOOD = "goodLiveModel"
    }

    private val app = ctx.applicationContext
    private val prefs = Prefs(app)
    private val phone = PhoneActions(app)
    private val gemini = GeminiClient(phone)
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    // session state (main thread)
    private var active = false
    private var oneShot = false
    private var greeting: String? = null
    private var typedText: String? = null
    private var pendingText: String? = null
    private var state = Engine.State.Idle
    private var gen = 0
    private var models: List<String> = emptyList()
    private var modelIdx = 0
    private var currentModel = ""
    private var resumeHandle: String? = null
    private var reconnects = 0
    private var setupDone = false
    private var lastReason = ""
    private var discovered = false
    private val preBuf = java.util.ArrayDeque<String>() // sound spoken while the connection is still being made
    private var lastActivity = 0L
    private var turnDone = false
    private val inputBuf = StringBuilder()
    private val outputBuf = StringBuilder()
    private var classic: Engine? = null
    private var latestFrame: String? = null

    @Volatile
    private var ws: WebSocket? = null

    @Volatile
    private var ready = false

    // audio
    private var prevMode = AudioManager.MODE_NORMAL
    private var prevSpeaker = false
    private var audioModeSet = false

    @Volatile
    private var micOn = false
    private val queue = LinkedBlockingQueue<ByteArray>()

    @Volatile
    private var playRunning = false

    @Volatile
    private var flushReq = false

    @Volatile
    private var playEnd = 0L

    /** When true, the session never closes by itself; only the user (or the dismiss tool) ends it. */
    var keepAlive = false

    private var leaveMode: String? = null
    private var leaveSpoke = false
    private var lastSetupAt = 0L

    private val idleCheck = object : Runnable {
        override fun run() {
            if (!active) return
            val quiet = System.currentTimeMillis() - lastActivity
            if (!keepAlive && state == Engine.State.Listening && quiet > IDLE_END_MS) {
                endSession()
            } else {
                main.postDelayed(this, 5000)
            }
        }
    }

    // ------------------------------------------------------------------ public API

    fun begin(greeting: String? = null) {
        start(greeting, null, false)
    }

    /** A typed message: the answer is spoken, then the session ends. (During a live talk it just continues.) */
    fun sendText(text: String) {
        if (classic != null) {
            classic?.sendText(text)
            return
        }
        if (active) {
            lastActivity = System.currentTimeMillis()
            if (ready) sendRealtimeText(text) else pendingText = text
            return
        }
        start(null, text, true)
    }

    /** A new camera picture (base64 JPEG) while the live camera is on. */
    fun sendFrame(b64: String) {
        latestFrame = b64
        if (!ready) return
        val w = ws ?: return
        if (w.queueSize() > 600_000) return
        w.send("{\"realtimeInput\":{\"video\":{\"data\":\"$b64\",\"mimeType\":\"image/jpeg\"}}}")
    }

    fun cameraOff() {
        latestFrame = null
    }

    fun stop() {
        val c = classic
        if (c != null) {
            c.stop() // its callback ends the session
            return
        }
        teardown()
        setState(Engine.State.Idle)
        cb.onSessionEnd()
    }

    // ------------------------------------------------------------------ start / connect

    private fun start(g: String?, t: String?, one: Boolean) {
        if (active) return
        val s = prefs.load()
        active = true
        oneShot = one
        greeting = g
        typedText = t
        pendingText = t
        resumeHandle = null
        reconnects = 0
        setupDone = false
        turnDone = false
        inputBuf.setLength(0)
        outputBuf.setLength(0)
        lastActivity = System.currentTimeMillis()
        setState(Engine.State.Thinking)
        setAudioMode(true)
        startPlayback()
        main.removeCallbacks(idleCheck)
        main.postDelayed(idleCheck, 5000)
        synchronized(preBuf) { preBuf.clear() }
        discovered = false
        retriedSame = false
        if (!one && !micOn) startMic() // listen at once; any error is reported again after the connection is ready
        val saved = goodModel ?: app.getSharedPreferences("assistant", Context.MODE_PRIVATE).getString(KEY_GOOD, null)
        if (saved != null) {
            // we already know a model that works: connect straight away, no list lookup
            goodModel = saved
            models = (listOf(saved) + staticModels).distinct()
            modelIdx = 0
            connect()
        } else {
            discoverThenConnect()
        }
    }

    private var retriedSame = false

    private fun discoverThenConnect() {
        discovered = true
        val key = prefs.load().apiKey
        Thread {
            val list = candidates(key)
            main.post {
                if (active && classic == null) {
                    models = list
                    modelIdx = 0
                    connect()
                }
            }
        }.start()
    }

    private fun versionOf(name: String): Double =
        Regex("(\\d+\\.\\d+)").find(name)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

    /** Asks Google which models this key can use for a live talk; the fixed names are only a backup. */
    private fun candidates(key: String): List<String> {
        val found = ArrayList<String>()
        try {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                .openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 10000
                c.readTimeout = 15000
                c.setRequestProperty("x-goog-api-key", key)
                if (c.responseCode in 200..299) {
                    val arr = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                        .optJSONArray("models") ?: JSONArray()
                    for (i in 0 until arr.length()) {
                        val m = arr.getJSONObject(i)
                        val name = m.optString("name").removePrefix("models/")
                        val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                        var bidi = false
                        for (j in 0 until methods.length()) {
                            if (methods.getString(j).equals("bidiGenerateContent", ignoreCase = true)) bidi = true
                        }
                        if (bidi) found.add(name)
                    }
                }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
        }
        val bad = listOf("transcribe", "translate", "extended", "image", "tts")
        val good = found
            .filter { n -> n.startsWith("gemini") && bad.none { it in n } }
            .sortedWith(compareBy<String>({ "preview" in it || "exp" in it }, { -versionOf(it) }))
        val first = goodModel
        return (listOfNotNull(first) + good + staticModels).distinct().take(6)
    }

    private fun connect() {
        if (!active) return
        if (modelIdx >= models.size) {
            if (!discovered) {
                discoverThenConnect()
            } else {
                allFailed()
            }
            return
        }
        val model = models[modelIdx]
        currentModel = model
        val my = ++gen
        ready = false
        setupDone = false
        val s = prefs.load()
        val req = try {
            Request.Builder().url(WS_URL + s.apiKey).build()
        } catch (e: Exception) {
            lastReason = "Problem with the API key: ${e.message}"
            allFailed()
            return
        }
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (my != gen) return
                try {
                    webSocket.send(setupJson(model).toString())
                } catch (e: Exception) {
                    main.post { if (my == gen) lost("setup: ${e.message}") }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                main.post { if (my == gen) handle(text) }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val t = bytes.utf8()
                main.post { if (my == gen) handle(t) }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                main.post { if (my == gen) lost("closed ($code) $reason") }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val httpCode = response?.code?.let { " HTTP $it" } ?: ""
                main.post { if (my == gen) lost("${t.javaClass.simpleName}: ${t.message ?: "no details"}$httpCode") }
            }
        })
    }

    private fun setupJson(model: String): JSONObject {
        val s = prefs.load()
        val voice = Catalog.voice(s.voice).geminiVoice
        val setup = JSONObject()
            .put("model", "models/$model")
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                        )
                    )
            )
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Prompts.system(s, false, true))))
            )
            .put("tools", gemini.tools())
            .put(
                "realtimeInputConfig",
                JSONObject().put(
                    "automaticActivityDetection",
                    JSONObject()
                        .put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH")
                        .put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
                        .put("prefixPaddingMs", 100)
                        .put("silenceDurationMs", 320)
                )
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
        val h = resumeHandle
        setup.put("sessionResumption", if (h != null) JSONObject().put("handle", h) else JSONObject())
        return JSONObject().put("setup", setup)
    }

    /** The connection failed or ended. Before the setup finished: try the next model. Later: reconnect. */
    private fun lost(reason: String) {
        ready = false
        ws = null
        lastReason = "$currentModel • $reason"
        if (!active || classic != null) return
        if (setupDone) {
            if (reconnects < 4) {
                reconnects++
                main.postDelayed({ connect() }, 600)
            } else {
                cb.onError("The connection kept breaking.\n$lastReason")
                endSession()
            }
        } else {
            resumeHandle = null
            if (!retriedSame) {
                // one quick retry of the same model first, so a hiccup never switches to a model with a different voice
                retriedSame = true
                main.postDelayed({ connect() }, 500)
                return
            }
            if (!discovered) {
                discoverThenConnect() // the remembered model failed: ask Google which models work
            } else {
                modelIdx++
                connect()
            }
        }
    }

    private fun allFailed() {
        val reason = lastReason.ifBlank { "No live model was found" }
        cb.onError("The live connection could not be made, so the normal mode is used.\nReason: $reason")
        stopLiveParts()
        val classicCb = object : Engine.Callback {
            override fun onState(s: Engine.State) = cb.onState(s)
            override fun onHeard(text: String, final: Boolean) = cb.onHeard(text, final)
            override fun onReply(text: String) = cb.onReply(text)
            override fun onError(msg: String) = cb.onError(msg)
            override fun onSessionEnd() {
                classic = null
                active = false
                state = Engine.State.Idle
                cb.onSessionEnd()
            }
        }
        val c = Engine(app, scope, classicCb)
        c.frameProvider = { latestFrame }
        classic = c
        val t = typedText
        if (t != null) c.sendText(t) else c.begin(greeting)
    }

    // ------------------------------------------------------------------ messages from Gemini

    private fun handle(text: String) {
        val j = try {
            JSONObject(text)
        } catch (e: Exception) {
            return
        }
        if (j.has("setupComplete")) {
            onSetup()
            return
        }
        j.optJSONObject("sessionResumptionUpdate")?.let {
            val h = it.optString("newHandle")
            if (h.isNotEmpty() && it.optBoolean("resumable", true)) resumeHandle = h
        }
        j.optJSONObject("toolCall")?.let { onToolCall(it) }
        j.optJSONObject("serverContent")?.let { onContent(it) }
    }

    private fun onSetup() {
        setupDone = true
        goodModel = currentModel
        try {
            app.getSharedPreferences("assistant", Context.MODE_PRIVATE).edit().putString(KEY_GOOD, currentModel).apply()
        } catch (e: Exception) {
        }
        // send what the user already said while connecting, then go live
        synchronized(preBuf) {
            val w = ws
            while (preBuf.isNotEmpty()) {
                val m = preBuf.pollFirst() ?: break
                w?.send(m)
            }
            ready = true
        }
        if (System.currentTimeMillis() - lastSetupAt > 60_000) reconnects = 0
        lastSetupAt = System.currentTimeMillis()
        lastActivity = System.currentTimeMillis()
        if (!oneShot && !micOn) {
            val err = startMic()
            if (err != null) {
                cb.onError(err)
                endSession()
                return
            }
        }
        if (state == Engine.State.Thinking) setState(Engine.State.Listening)
        val g = greeting
        if (g != null) {
            greeting = null
            sendRealtimeText("Say only this short greeting out loud, warmly, in your own voice, and nothing more: \"$g\"")
        }
        val t = pendingText
        if (t != null) {
            pendingText = null
            sendRealtimeText(t)
        }
    }

    private fun sendRealtimeText(t: String) {
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString())
    }

    private fun commitHeard() {
        val t = inputBuf.toString().trim()
        inputBuf.setLength(0)
        if (t.isNotEmpty()) cb.onHeard(t, true)
    }

    private fun onContent(sc: JSONObject) {
        lastActivity = System.currentTimeMillis()
        sc.optJSONObject("inputTranscription")?.optString("text")?.let {
            if (it.isNotEmpty()) {
                inputBuf.append(it)
                cb.onHeard(inputBuf.toString().trim(), false)
            }
        }
        if (sc.optBoolean("interrupted")) {
            stopPlayback()
            commitHeard()
            outputBuf.setLength(0)
            if (state != Engine.State.Listening) setState(Engine.State.Listening)
        }
        sc.optJSONObject("outputTranscription")?.optString("text")?.let {
            if (it.isNotEmpty()) outputBuf.append(it)
        }
        val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
        if (parts != null) {
            var gotAudio = false
            for (i in 0 until parts.length()) {
                val d = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data").orEmpty()
                if (d.isNotEmpty()) {
                    try {
                        queue.add(Base64.decode(d, Base64.DEFAULT))
                        gotAudio = true
                    } catch (e: Exception) {
                    }
                }
            }
            if (gotAudio) {
                if (leaveMode != null) leaveSpoke = true
                turnDone = false
                commitHeard()
                if (state != Engine.State.Speaking) setState(Engine.State.Speaking)
            }
        }
        if (sc.optBoolean("turnComplete")) {
            commitHeard()
            val r = outputBuf.toString().trim()
            outputBuf.setLength(0)
            if (r.isNotEmpty()) cb.onReply(r)
            turnDone = true
            if (oneShot && state != Engine.State.Speaking) endSession()
            if (leaveMode != null && leaveSpoke && state != Engine.State.Speaking) leaveNow()
        }
    }

    private fun onToolCall(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        lastActivity = System.currentTimeMillis()
        setState(Engine.State.Thinking)
        val list = ArrayList<JSONObject>()
        for (i in 0 until calls.length()) list.add(calls.getJSONObject(i))
        val my = gen
        scope.launch(Dispatchers.IO) {
            val resp = JSONArray()
            for (c in list) {
                val name = c.optString("name")
                val result = try {
                    if (name == "dismiss" || name == "turn_off_listening") {
                        main.post {
                            leaveMode = name
                            leaveSpoke = false
                            // safety: leave even if the goodbye never comes
                            main.postDelayed({ if (leaveMode != null) leaveNow() }, 8000)
                        }
                        "Done. Now say ONE very short goodbye and nothing more."
                    } else {
                        phone.run(name, c.optJSONObject("args") ?: JSONObject())
                    }
                } catch (e: Exception) {
                    "Failed: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
                }
                resp.put(
                    JSONObject()
                        .put("id", c.optString("id"))
                        .put("name", name)
                        .put("response", JSONObject().put("result", result))
                )
            }
            if (my == gen) {
                ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", resp)).toString())
            }
        }
    }

    // ------------------------------------------------------------------ state / end

    private fun setState(s: Engine.State) {
        state = s
        cb.onState(s)
    }

    private fun endSession() {
        if (!active) return
        teardown()
        setState(Engine.State.Idle)
        cb.onSessionEnd()
    }

    private fun stopLiveParts() {
        gen++ // ignore anything that still arrives from the old connection
        ready = false
        main.removeCallbacks(idleCheck)
        try {
            ws?.close(1000, "bye")
        } catch (e: Exception) {
        }
        ws = null
        micOn = false
        playRunning = false
        queue.clear()
        setAudioMode(false)
    }

    private fun teardown() {
        active = false
        leaveMode = null
        leaveSpoke = false
        stopLiveParts()
        classic = null
        inputBuf.setLength(0)
        outputBuf.setLength(0)
    }

    // ------------------------------------------------------------------ audio

    private fun setAudioMode(on: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (on && !audioModeSet) {
                prevMode = am.mode
                prevSpeaker = am.isSpeakerphoneOn
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.isSpeakerphoneOn = true
                audioModeSet = true
            } else if (!on && audioModeSet) {
                am.isSpeakerphoneOn = prevSpeaker
                am.mode = prevMode
                audioModeSet = false
            }
        } catch (e: Exception) {
        }
    }

    /** Returns null when the microphone started, otherwise the real reason why it did not. */
    private fun startMic(): String? {
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "Microphone permission is missing. Tap Allow in Settings > Phone control."
        }
        val minBuf = AudioRecord.getMinBufferSize(MIC_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return "This phone's microphone cannot run at 16 kHz (getMinBufferSize=$minBuf)."
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MIC_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, MIC_FRAME * 2 * 4)
            )
        } catch (e: Exception) {
            return "The microphone could not open.\nReason: ${e.javaClass.simpleName}: ${e.message}"
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return "The microphone could not start. Another app may be using it."
        }
        var aec: AcousticEchoCanceler? = null
        var ns: NoiseSuppressor? = null
        var agc: AutomaticGainControl? = null
        try {
            if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.setEnabled(true) }
        } catch (e: Exception) {
        }
        try {
            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.setEnabled(true) }
        } catch (e: Exception) {
        }
        try {
            if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(rec.audioSessionId)?.also { it.setEnabled(true) }
        } catch (e: Exception) {
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            return "The microphone could not turn on.\nReason: ${e.javaClass.simpleName}: ${e.message}"
        }
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            rec.release()
            return "Another app (for example a call) is holding the microphone, so it cannot start now."
        }
        micOn = true
        Thread({
            val buf = ShortArray(MIC_FRAME)
            try {
                while (micOn) {
                    var got = 0
                    while (got < MIC_FRAME && micOn) {
                        val n = rec.read(buf, got, MIC_FRAME - got)
                        if (n < 0) {
                            micOn = false
                            main.post { cb.onError("Problem reading sound from the microphone (code $n)."); endSession() }
                            return@Thread
                        }
                        if (n == 0) Thread.sleep(4)
                        got += n
                    }
                    if (!micOn) break
                    val bytes = ByteArray(MIC_FRAME * 2)
                    for (i in 0 until MIC_FRAME) {
                        bytes[i * 2] = (buf[i].toInt() and 0xFF).toByte()
                        bytes[i * 2 + 1] = ((buf[i].toInt() shr 8) and 0xFF).toByte()
                    }
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    val msg = "{\"realtimeInput\":{\"audio\":{\"data\":\"$b64\",\"mimeType\":\"audio/pcm;rate=16000\"}}}"
                    var live = false
                    synchronized(preBuf) {
                        if (ready) {
                            live = true
                        } else {
                            preBuf.addLast(msg)
                            while (preBuf.size > 200) preBuf.pollFirst() // keep the last ~8 seconds
                        }
                    }
                    if (live) {
                        val w = ws
                        if (w != null && w.queueSize() < 600_000) w.send(msg)
                    }
                }
            } catch (e: Exception) {
                if (micOn) {
                    micOn = false
                    main.post { cb.onError("The microphone recording stopped.\nReason: ${e.javaClass.simpleName}: ${e.message}"); endSession() }
                }
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                try { rec.release() } catch (e: Exception) { }
                try { aec?.release() } catch (e: Exception) { }
                try { ns?.release() } catch (e: Exception) { }
                try { agc?.release() } catch (e: Exception) { }
            }
        }, "LiveMicSend").start()
        return null
    }

    private fun startPlayback() {
        val minBuf = AudioTrack.getMinBufferSize(OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val buf = max(minBuf, OUT_RATE * 2 * 3 / 10)
        val t = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(OUT_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            cb.onError("The speaker part could not start.\nReason: ${e.javaClass.simpleName}: ${e.message}")
            return
        }
        queue.clear()
        flushReq = false
        playEnd = 0L
        playRunning = true
        t.play()
        Thread({
            var wasPlaying = false
            try {
                while (playRunning) {
                    if (flushReq) {
                        flushReq = false
                        t.pause()
                        t.flush()
                        t.play()
                        playEnd = 0L
                        wasPlaying = false
                        VoiceLevel.v = 0f
                    }
                    val chunk = queue.poll(60, TimeUnit.MILLISECONDS)
                    if (chunk != null) {
                        val now = SystemClock.elapsedRealtime()
                        playEnd = max(playEnd, now) + (chunk.size / 2) * 1000L / OUT_RATE
                        wasPlaying = true
                        var off = 0
                        while (off < chunk.size && playRunning && !flushReq) {
                            val part = min(1920, chunk.size - off)
                            VoiceLevel.fromPcm(chunk, off, part)
                            val n = t.write(chunk, off, part)
                            if (n <= 0) break
                            off += n
                        }
                    } else if (wasPlaying && SystemClock.elapsedRealtime() >= playEnd + 150) {
                        wasPlaying = false
                        VoiceLevel.v = 0f
                        main.post { playbackFinished() }
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { t.stop() } catch (e: Exception) { }
                try { t.release() } catch (e: Exception) { }
            }
        }, "LiveSpeaker").start()
    }

    /** Throws away any speech still waiting to be played (the user spoke over the assistant). */
    private fun stopPlayback() {
        queue.clear()
        flushReq = true
    }

    private fun playbackFinished() {
        if (!active) return
        if (state == Engine.State.Speaking && queue.isEmpty()) {
            setState(Engine.State.Listening)
            if (oneShot && turnDone) endSession()
            if (leaveMode != null && leaveSpoke && turnDone) leaveNow()
        }
    }

    /** The user sent the assistant away. "turn_off_listening" also switches the call-by-name option off. */
    private fun leaveNow() {
        val mode = leaveMode ?: return
        leaveMode = null
        leaveSpoke = false
        if (mode == "turn_off_listening") {
            try {
                prefs.save(prefs.load().copy(handsFree = false))
            } catch (e: Exception) {
            }
        }
        endSession()
    }
}
