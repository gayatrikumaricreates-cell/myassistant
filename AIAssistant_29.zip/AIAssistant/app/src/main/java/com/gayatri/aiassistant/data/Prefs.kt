package com.gayatri.aiassistant.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AppSettings(
    val apiKey: String = "",
    val userName: String = "",
    val about: String = "",
    val wakeName: String = "Jarvis",
    val handsFree: Boolean = false,
    val voice: String = "Aria",
    val theme: String = "Orbit",
    val useMix: Boolean = false,
    val color1: Int = 0,
    val color2: Int = 0,
    val mixSpeed: String = "Lively",
    val language: String = "mix",
    val style: String = "friendly",
    val wakeMethod: String = "smooth"
)

private val THEME_NAMES = listOf("Orbit", "Ember", "Orchid", "Glacier", "Emerald", "Rose Quartz", "Sunbeam", "Nebula")

/** Chat history inside Profile is switched off (the user does not want chats kept). Set to true to bring it back. */
const val SHOW_CHAT_HISTORY = false

data class ChatEntry(val id: Long, val title: String, val time: Long)

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("assistant", Context.MODE_PRIVATE)

    init {
        // One time only: the older default names become "Jarvis". A name chosen later is never touched.
        if (!sp.getBoolean("jarvisMigrated", false)) {
            val e = sp.edit().putBoolean("jarvisMigrated", true)
            val old = sp.getString("wakeName", null)
            if (old == null || old.equals("Priya", ignoreCase = true) || old.equals("Orbit", ignoreCase = true) || old.equals("Atlas", ignoreCase = true) || old.equals("Nova", ignoreCase = true) || old.equals("Buddy", ignoreCase = true) || old.equals("Max", ignoreCase = true)) e.putString("wakeName", "Jarvis")
            e.apply()
        }
    }

    fun load(): AppSettings = AppSettings(
        apiKey = sp.getString("apiKey", "") ?: "",
        userName = sp.getString("userName", "") ?: "",
        about = sp.getString("about", "") ?: "",
        wakeName = (sp.getString("wakeName", "Jarvis") ?: "Jarvis").ifBlank { "Jarvis" },
        handsFree = sp.getBoolean("handsFree", false),
        voice = sp.getString("voice", "Aria") ?: "Aria",
        theme = (sp.getString("theme", "Orbit") ?: "Orbit").let { if (it in THEME_NAMES) it else "Orbit" },
        useMix = sp.getBoolean("useMix", false),
        color1 = sp.getInt("color1", 0),
        color2 = sp.getInt("color2", 0),
        mixSpeed = sp.getString("mixSpeed", "Lively") ?: "Lively",
        language = sp.getString("language", "mix") ?: "mix",
        style = sp.getString("style", "friendly") ?: "friendly",
        wakeMethod = "smooth"
    )

    /** How the phone's own listener wrote the wake name when this user said it (taught in Settings). */
    fun learned(name: String): Set<String> = try {
        val a = JSONObject(sp.getString("learned", "{}") ?: "{}").optJSONArray(name.trim().lowercase())
        if (a == null) emptySet() else (0 until a.length()).map { a.getString(it) }.toSet()
    } catch (e: Exception) {
        emptySet()
    }

    fun setLearned(name: String, list: List<String>) {
        try {
            val o = JSONObject(sp.getString("learned", "{}") ?: "{}")
            o.put(name.trim().lowercase(), org.json.JSONArray(list))
            sp.edit().putString("learned", o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun save(s: AppSettings) {
        sp.edit()
            .putString("apiKey", s.apiKey.trim())
            .putString("userName", s.userName)
            .putString("about", s.about)
            .putString("wakeName", s.wakeName)
            .putBoolean("handsFree", s.handsFree)
            .putString("voice", s.voice)
            .putString("theme", s.theme)
            .putBoolean("useMix", s.useMix)
            .putInt("color1", s.color1)
            .putInt("color2", s.color2)
            .putString("mixSpeed", s.mixSpeed)
            .putString("language", s.language)
            .putString("style", s.style)
            .putString("wakeMethod", s.wakeMethod)
            .apply()
    }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) {
            sp.edit().putBoolean("onboarded", v).apply()
        }

    fun history(): List<ChatEntry> {
        val arr = try {
            JSONArray(sp.getString("history", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<ChatEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(ChatEntry(o.optLong("id"), o.optString("title"), o.optLong("time")))
        }
        return out
    }

    private fun saveHistory(list: List<ChatEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("time", it.time))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun addHistory(title: String) {
        val now = System.currentTimeMillis()
        val list = history().toMutableList()
        list.add(0, ChatEntry(now, title.take(120), now))
        saveHistory(list.take(60))
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    fun deleteHistory(id: Long) {
        saveHistory(history().filter { it.id != id })
    }
}
